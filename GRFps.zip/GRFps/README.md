# GR FPS

แอป Android (Kotlin + Jetpack Compose) สำหรับลดภาระระบบให้เครื่องลื่นขึ้นตอนเล่นเกม ธีมเขียวนีออน

## วิธีสร้างแอป
1. ติดตั้ง Android Studio (Ladybug หรือใหม่กว่า)
2. File > Open > เลือกโฟลเดอร์ `GRFps` แล้วรอ Gradle Sync (ต้องมีอินเทอร์เน็ต)
3. กด Run บนมือถือจริง หรือ Build > Build APK(s)

## ฟีเจอร์
- Auto Mode 5 ระดับ: Very Low / Low / Medium / High / Very High
- Manual Options: ความเร็วแอนิเมชัน, เคลียร์ RAM, ล้างแคช, รีเฟรชเรตสูงสุด, Game Mode: Performance (Genshin / Honkai: Star Rail / Wuthering Waves), ปิดการสแกน Wi-Fi/BT เบื้องหลัง, Fixed performance mode, dexopt
- กด **APPLY** แล้วจะมีหน้าต่างยืนยันก่อนทุกครั้ง
- **RESET** คืนค่าที่แอปเคยเปลี่ยนกลับเป็นค่าเดิมก่อนปรับ (แอปเก็บค่าเดิมไว้ตอน Apply ครั้งแรก)
- ขอสิทธิ์: Shizuku, ยกเว้น Battery optimization, การแจ้งเตือน

## ใช้ร่วมกับ Shizuku
1. ติดตั้งแอป Shizuku (github.com/RikkaApps/Shizuku/releases) แล้วสตาร์ท (Wireless debugging หรือ ADB)
2. เปิด GR FPS > การ์ด "Permissions & Shizuku" > กด ALLOW
3. สถานะขึ้น Connected แล้วจึงปรับค่าระบบได้เต็มที่

ถ้าไม่มี Shizuku แอปจะล้างแคชของตัวเองได้เท่านั้น

## ข้อจำกัด (ตรงไปตรงมา)
- บางคำสั่ง (เช่น fixed performance mode, Game Mode, 120Hz) ไม่รองรับทุกรุ่น แอปจะแสดง ✘ ในผลลัพธ์
- Reset คืนค่า Settings ได้ แต่แอปที่ถูกปิดและแคชที่ล้างไปแล้วคืนไม่ได้
- แอปลดภาระระบบ ไม่ได้เพิ่มพลังชิป เครื่องอ่อนมากยังต้องลดกราฟิกในเกมด้วย

## Game Space (new)
Turn it on in the GR FPS app (Game Space card). A small neon tab appears on the left edge of the screen:
tap it or slide it right to open the Game Space window over any game. Drag the tab up/down to move it.
Buttons work at once (no APPLY); tap again to turn off. Screenshots are saved in Pictures/GRFPS (needs Shizuku).
What is ON is remembered (ActiveStore), so the app and Game Space always show the same state.

package com.gr.fps

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale

/** Detailed FPS meter: FPS, average, 1% low, stutter count and a frame-time graph. */
class FpsDetailService : BaseOverlayService() {

    companion object {
        val running = MutableStateFlow(false)
    }

    override val notifId = 3
    override val channelId = "gr_fps_pro"
    override val title = "GR FPS Pro meter is running"
    override val scaleKey = "detail"
    override val stopAction = "com.gr.fps.STOP_PRO"
    override val startY = 300
    override val tickMs = 500L

    private var box: LinearLayout? = null
    private var l1: TextView? = null
    private var l2: TextView? = null
    private var l3: TextView? = null
    private var graph: FrameGraphView? = null

    override fun createContent(ctx: Context): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xAA000000.toInt())
        }
        val a = overlayText(ctx, true)
        val b = overlayText(ctx, true)
        val c = overlayText(ctx, true)
        val g = FrameGraphView(ctx)
        a.text = "FPS --"
        root.addView(a)
        root.addView(b)
        root.addView(c)
        root.addView(g)
        box = root
        l1 = a
        l2 = b
        l3 = c
        graph = g
        return root
    }

    override fun applyScale(scale: Float) {
        val r = box ?: return
        val p = dpOf(this, 8f * scale).toInt()
        r.setPadding(p, p, p, p)
        l1?.textSize = 16f * scale
        l2?.textSize = 13f * scale
        l3?.textSize = 13f * scale
        graph?.scale = scale
        r.requestLayout()
    }

    override fun onStarted() = FpsHub.acquire()
    override fun onStopped() = FpsHub.release()
    override fun setRunning(v: Boolean) {
        running.value = v
    }

    override suspend fun onTick() {
        val ready = ShizukuHelper.state.value == ShizukuState.READY
        val s = FpsHub.stats.value
        withContext(Dispatchers.Main) {
            if (!ready) {
                l1?.text = "Shizuku?"
                l2?.text = ""
                l3?.text = ""
                graph?.setData(emptyList(), 0f)
            } else if (s == null) {
                l1?.text = "FPS --"
                l2?.text = ""
                l3?.text = ""
                graph?.setData(emptyList(), 0f)
            } else {
                l1?.text = "FPS ${s.fps}   AVG ${s.avg}"
                l2?.text = "1% LOW ${s.low1}   STUTTER ${s.stutters}"
                l3?.text = "FRAME " + String.format(Locale.US, "%.1f", s.avgMs) + " ms"
                l1?.setTextColor(
                    when {
                        s.fps >= 50 -> 0xFF39FF14.toInt()
                        s.fps >= 30 -> 0xFFFFEB3B.toInt()
                        else -> 0xFFFF5252.toInt()
                    }
                )
                graph?.setData(s.frameMs, s.avgMs)
            }
        }
    }
}

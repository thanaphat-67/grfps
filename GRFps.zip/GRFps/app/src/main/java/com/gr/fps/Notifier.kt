package com.gr.fps

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build

object Notifier {
    fun show(ctx: Context, text: String) {
        if (Build.VERSION.SDK_INT >= 33 &&
            ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gr_fps", "GR FPS", NotificationManager.IMPORTANCE_DEFAULT))
        val n = Notification.Builder(ctx, "gr_fps")
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("GR FPS")
            .setContentText(text)
            .setAutoCancel(true)
            .build()
        nm.notify(1, n)
    }
}

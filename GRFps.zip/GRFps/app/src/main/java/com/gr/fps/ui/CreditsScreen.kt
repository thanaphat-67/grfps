package com.gr.fps.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.annotation.DrawableRes
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Favorite
import androidx.compose.material.icons.rounded.Star
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gr.fps.R

const val DONATE_URL = "https://sociabuzz.com/grfps_05/tribe"

fun openDonate(ctx: Context) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(DONATE_URL)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (_: Throwable) {
        Toast.makeText(ctx, "Couldn't open the link", Toast.LENGTH_LONG).show()
    }
}

/** The two eye-catching buttons in the top-right corner of the home screen. */
@Composable
fun HeaderActions(onCredits: () -> Unit, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Column(modifier, verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.End) {
        Row(
            Modifier
                .clip(TechShape)
                .background(Brush.horizontalGradient(listOf(Neon, NeonDim)))
                .clickable { openDonate(ctx) }
                .padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Favorite, null, tint = Color.Black, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("DONATE", color = Color.Black, fontWeight = FontWeight.Black, fontSize = 14.sp, letterSpacing = 1.sp)
        }
        Row(
            Modifier
                .clip(TechShape)
                .border(1.5.dp, Neon, TechShape)
                .clickable { onCredits() }
                .padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Rounded.Star, null, tint = Neon, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(6.dp))
            Text("CREDITS", color = Neon, fontWeight = FontWeight.Black, fontSize = 14.sp, letterSpacing = 1.sp)
        }
    }
}

@Composable
fun CreditsScreen(onBack: () -> Unit) {
    BackHandler { onBack() }
    Column(
        Modifier
            .fillMaxSize()
            .background(Bg)
            .statusBarsPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(40.dp)
                    .clip(CircleShape)
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Neon, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(10.dp))
            Text("Credits", color = Neon, fontSize = 26.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic)
        }
        Spacer(Modifier.height(22.dp))
        Section("MAIN DEVELOPER")
        PersonCard(R.drawable.avatar_atra, "ATら", "Main Developer")
        Spacer(Modifier.height(22.dp))
        Section("CO-DEVELOPER")
        PersonCard(R.drawable.avatar_jonestar, "JoneStar^", "Co-Developer")
        Spacer(Modifier.height(26.dp))
        val ctx = LocalContext.current
        NeonButton("DONATE", Icons.Rounded.Favorite, { openDonate(ctx) }, Modifier.fillMaxWidth())
    }
}

@Composable
private fun Section(text: String) {
    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(bottom = 10.dp)) {
        Box(Modifier.width(4.dp).height(20.dp).clip(RoundedCornerShape(2.dp)).background(Neon))
        Spacer(Modifier.width(8.dp))
        Text(text, color = Neon, fontSize = 14.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 1.sp)
    }
}

@Composable
private fun PersonCard(@DrawableRes img: Int, name: String, role: String) {
    NeonCard(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Image(
                painterResource(img), name,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .border(3.dp, Neon, CircleShape)
            )
            Spacer(Modifier.width(18.dp))
            Column {
                Text(name, color = TextMain, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))
                Text(
                    role, color = Neon, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier
                        .clip(RoundedCornerShape(50))
                        .background(Neon.copy(alpha = 0.15f))
                        .border(1.dp, Neon.copy(alpha = 0.5f), RoundedCornerShape(50))
                        .padding(horizontal = 12.dp, vertical = 5.dp)
                )
            }
        }
    }
}

package com.gr.fps

import android.content.Context
import android.content.SharedPreferences

/** Small things the user picked in the UI (overlay sizes, selected game). */
object UiPrefs {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("gr_ui", Context.MODE_PRIVATE)

    fun scale(c: Context, key: String): Float = prefs(c).getFloat("scale_$key", 1f)

    fun setScale(c: Context, key: String, v: Float) {
        prefs(c).edit().putFloat("scale_$key", v).apply()
    }

    fun appPkg(c: Context): String? = prefs(c).getString("app_pkg", null)
    fun appLabel(c: Context): String? = prefs(c).getString("app_label", null)
    fun appIsGame(c: Context): Boolean = prefs(c).getBoolean("app_game", false)

    fun setApp(c: Context, pkg: String?, label: String?, game: Boolean) {
        val e = prefs(c).edit()
        if (pkg == null) {
            e.remove("app_pkg").remove("app_label").remove("app_game")
        } else {
            e.putString("app_pkg", pkg).putString("app_label", label ?: pkg).putBoolean("app_game", game)
        }
        e.apply()
    }

    fun launchAfter(c: Context): Boolean = prefs(c).getBoolean("launch_after", true)

    fun setLaunchAfter(c: Context, v: Boolean) {
        prefs(c).edit().putBoolean("launch_after", v).apply()
    }

    /** Frame generation quality: 0 = fast blend, 1 = balanced, 2 = best motion matching. */
    fun fgQuality(c: Context): Int = prefs(c).getInt("fg_quality", 1)

    fun setFgQuality(c: Context, v: Int) {
        prefs(c).edit().putInt("fg_quality", v).apply()
    }
}

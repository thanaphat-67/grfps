package com.gr.fps.ui

import android.os.Build
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DoNotDisturbOn
import androidx.compose.material.icons.rounded.NotificationsOff
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.WbSunny
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.graphics.drawable.toBitmap
import com.gr.fps.AppEntry
import com.gr.fps.DnsChoice
import com.gr.fps.MainViewModel
import com.gr.fps.RecState
import java.util.Locale

// ---------------------------------------------------------------------- overlays (FPS / Pro / Monitor)

@Composable
fun OverlayCard(
    title: String,
    icon: ImageVector,
    name: String,
    desc: String,
    running: Boolean,
    scale: Float,
    note: String,
    onToggle: (Boolean) -> Unit,
    onScale: (Float) -> Unit
) {
    NeonCard {
        SectionTitle(title)
        SettingRow(icon, name, desc, running, onToggle)
        Text(
            "Size  " + String.format(Locale.US, "%.1f", scale) + "x",
            color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold
        )
        SizeSlider(scale, onScale)
        Text(note, color = TextDim, fontSize = 11.sp, lineHeight = 14.sp)
    }
}

// ---------------------------------------------------------------------- game / app picker

@Composable
fun AppIcon(pkg: String, size: Dp) {
    val ctx = LocalContext.current
    val bmp = remember(pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(96, 96).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) {
        Image(
            bitmap = bmp, contentDescription = null,
            modifier = Modifier.size(size).clip(RoundedCornerShape(10.dp))
        )
    } else {
        Box(Modifier.size(size))
    }
}

@Composable
fun GamePickerCard(vm: MainViewModel) {
    var showPicker by remember { mutableStateOf(false) }
    NeonCard {
        SectionTitle("Game / App")
        val sel = vm.selectedApp
        if (sel == null) {
            NeonButton(
                "CHOOSE GAME / APP", Icons.Rounded.SportsEsports,
                { vm.loadApps(); showPicker = true },
                Modifier.fillMaxWidth(), filled = false
            )
        } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
                AppIcon(sel.pkg, 44.dp)
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text(sel.label, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 15.sp, maxLines = 1)
                    Text(sel.pkg, color = TextDim, fontSize = 10.sp, maxLines = 1)
                }
                IconButton(onClick = { vm.selectApp(null) }) {
                    Icon(Icons.Rounded.Close, contentDescription = "Remove", tint = TextDim)
                }
            }
            Spacer(Modifier.height(10.dp))
            ChipRow(
                options = listOf(false, true),
                selected = vm.launchAfter,
                label = { if (it) "Boost & play" else "Boost only" }
            ) { vm.changeLaunchAfter(it) }
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Pick the game you're going to play, set up the options below, then tap APPLY. " +
                "\"Boost & play\" also opens the game for you. Everything applies to the whole phone, " +
                "not just this game. To undo it, open GR FPS and tap RESET.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
    }
    if (showPicker) {
        AppPickerDialog(vm, onPick = { vm.selectApp(it); showPicker = false }, onDismiss = { showPicker = false })
    }
}

@Composable
private fun AppPickerDialog(vm: MainViewModel, onPick: (AppEntry) -> Unit, onDismiss: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = remember(vm.apps, q) {
        if (q.isBlank()) vm.apps else vm.apps.filter { it.label.contains(q, ignoreCase = true) }
    }
    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .padding(16.dp)
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .clip(TechShape)
                .background(CardTop)
                .border(1.dp, Neon.copy(alpha = 0.6f), TechShape)
                .padding(14.dp)
        ) {
            SectionTitle("Choose game / app")
            OutlinedTextField(
                value = q,
                onValueChange = { q = it },
                singleLine = true,
                placeholder = { Text("Search…", color = TextDim) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Neon,
                    unfocusedBorderColor = Neon.copy(alpha = 0.4f),
                    cursorColor = Neon,
                    focusedTextColor = TextMain,
                    unfocusedTextColor = TextMain
                )
            )
            Spacer(Modifier.height(8.dp))
            if (vm.appsLoading && vm.apps.isEmpty()) {
                Text("Loading…", color = TextDim, fontSize = 12.sp)
            }
            LazyColumn(Modifier.weight(1f)) {
                items(list, key = { it.pkg }) { e ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clickable { onPick(e) }
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppIcon(e.pkg, 40.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(e.label, color = TextMain, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                            if (e.isGame) Text("GAME", color = Neon, fontSize = 10.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    HorizontalDivider(color = Divider)
                }
            }
        }
    }
}

// ---------------------------------------------------------------------- low ping

@Composable
fun LowPingCard(vm: MainViewModel) {
    val cfg = vm.config
    NeonCard {
        SectionTitle("Low Ping")
        ChipRow(
            options = listOf<DnsChoice?>(null) + DnsChoice.values().toList(),
            selected = cfg.dns,
            label = { it?.label ?: "Default" }
        ) { vm.edit(cfg.copy(dns = it)) }
        Spacer(Modifier.height(10.dp))
        NeonButton(
            if (vm.pingBusy) "TESTING…" else "TEST SPEED & PICK FASTEST",
            Icons.Rounded.Speed,
            { vm.testPing() },
            Modifier.fillMaxWidth(), filled = false, enabled = !vm.pingBusy
        )
        if (vm.pings.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            Text(
                DnsChoice.values().joinToString("   •   ") { d ->
                    d.label + " " + (vm.pings[d]?.let { "$it ms" } ?: "blocked")
                },
                color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "Switches Android's Private DNS to a faster server, so game servers, logins and downloads connect quicker. " +
                "It can't lower the ping inside a match (that depends on your network and the game server). " +
                "If the internet stops working after APPLY, GR FPS puts the old DNS back by itself.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
    }
}

// ---------------------------------------------------------------------- screen recorder

@Composable
fun RecorderCard(vm: MainViewModel, recState: RecState, onStart: () -> Unit, onStop: () -> Unit) {
    val caps = vm.recCaps
    NeonCard {
        SectionTitle("Screen Recorder")
        SettingRow(
            Icons.Rounded.Videocam, "Recorder in notification",
            "Adds Record / Pause / Stop buttons to your notification bar",
            vm.recEnabled
        ) { vm.changeRecEnabled(it) }
        HorizontalDivider(color = Divider)

        Spacer(Modifier.height(8.dp))
        Text("Resolution", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        ChipRow(
            options = listOf(360, 480, 720, 1080, 1280, 1440, 2160),
            selected = vm.recRes,
            label = { "${it}p" },
            perRow = 4,
            enabled = { r -> caps == null || (r <= caps.nativeShort && caps.sizeOk(r, vm.recLandscape)) }
        ) { vm.changeRecRes(it) }

        Spacer(Modifier.height(10.dp))
        Text("Frame rate", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        ChipRow(
            options = listOf(30, 60, 90, 120),
            selected = vm.recFps,
            label = { "$it fps" },
            enabled = { f ->
                caps == null || caps.fpsOk(vm.recRes.coerceAtMost(caps.nativeShort), f, vm.recLandscape)
            }
        ) { vm.changeRecFps(it) }

        Spacer(Modifier.height(10.dp))
        Text("Video direction", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        ChipRow(
            options = listOf(true, false),
            selected = vm.recLandscape,
            label = { if (it) "Landscape (games)" else "Portrait" }
        ) { vm.changeRecLandscape(it) }

        Spacer(Modifier.height(10.dp))
        Text("Sound", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        SettingRow(
            Icons.Rounded.VolumeUp, "Phone / game sound",
            "Records what the phone plays (game, music)", vm.recInternal
        ) { vm.changeRecInternal(it) }
        HorizontalDivider(color = Divider)
        SettingRow(
            Icons.Rounded.Mic, "Microphone",
            "Records your voice. Turn both off for a silent video", vm.recMic
        ) { vm.changeRecMic(it) }

        Spacer(Modifier.height(10.dp))
        if (recState == RecState.IDLE) {
            NeonButton("START RECORDING", Icons.Rounded.Videocam, onStart, Modifier.fillMaxWidth())
        } else {
            NeonButton("STOP RECORDING", Icons.Rounded.Stop, onStop, Modifier.fillMaxWidth())
            Spacer(Modifier.height(4.dp))
            Text(
                if (recState == RecState.PAUSED) "Paused — resume or stop from the notification"
                else "Recording… pause or stop from the notification",
                color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold
            )
        }

        Spacer(Modifier.height(8.dp))
        Text(
            "Built to lag as little as possible: the screen goes straight into the phone's hardware video encoder, " +
                "with no extra copying by the CPU. Every recording still costs a little power, so on weak phones pick " +
                "a lower resolution / fps. Greyed-out options aren't supported by your phone's encoder or screen.\n" +
                "Android asks \"Start recording?\" every time (it can't be skipped). Some games block game-sound " +
                "capture; then only the microphone is recorded. Videos are saved in Movies/GR FPS.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
    }
}

// ---------------------------------------------------------------------- thermal guard

@Composable
fun ThermalGuardCard(vm: MainViewModel, running: Boolean, status: String) {
    val (socLim, batLim) = com.gr.fps.GuardPrefs.limits(vm.guardSens)
    NeonCard {
        SectionTitle("Thermal Guard")
        SettingRow(
            Icons.Rounded.Thermostat, "Thermal Guard",
            "Watches temperature while you play and cools the phone down before Android throttles it",
            vm.guardOn
        ) { vm.changeGuardOn(it) }
        if (vm.guardOn && status.isNotEmpty()) {
            Text(status, color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(8.dp))
        Text("Sensitivity", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        ChipRow(
            options = listOf(0, 1, 2),
            selected = vm.guardSens,
            label = { listOf("Early", "Normal", "Late")[it] }
        ) { vm.changeGuardSens(it) }
        Spacer(Modifier.height(4.dp))
        Text(
            "Counts as hot at: battery $batLim°C or chip $socLim°C, or as soon as Android itself starts throttling.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
        Spacer(Modifier.height(8.dp))
        Text("When it's hot", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("Always: send a \"phone is hot\" notification.", color = TextDim, fontSize = 11.sp)
        SettingRow(
            Icons.Rounded.Thermostat, "Drop screen to 60 Hz",
            "Smooth for the game and cooler. Only if the screen is above 60 Hz now", vm.guardHz
        ) { vm.changeGuardHz(it) }
        HorizontalDivider(color = Divider)
        SettingRow(
            Icons.Rounded.Thermostat, "Lower the resolution a step",
            "Up to 2 steps if it stays hot. Some games flicker or restart when the screen size changes", vm.guardReso
        ) { vm.changeGuardReso(it) }
        Spacer(Modifier.height(6.dp))
        Text(
            "Everything goes back to how it was after the phone has stayed cool for 45 seconds, when you turn Thermal Guard off, " +
                "or when you tap RESET. The actions need Shizuku; without it you only get the notifications. " +
                "Readings come from the phone's sensors and some phones don't show chip temperature. " +
                "It can't cool a phone that's in a hot place or charging at full speed.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
    }
}

// ---------------------------------------------------------------------- focus mode

@Composable
fun FocusCard(vm: MainViewModel) {
    val cfg = vm.config
    NeonCard {
        SectionTitle("Focus Mode")
        SettingRow(
            Icons.Rounded.DoNotDisturbOn, "Do Not Disturb",
            "Silences calls/notifications except what you allowed in Android's \"priority\" list", cfg.focusDnd
        ) { vm.edit(cfg.copy(focusDnd = it)) }
        HorizontalDivider(color = Divider)
        SettingRow(
            Icons.Rounded.NotificationsOff, "Hide pop-up banners",
            "No notification banners dropping over the game", cfg.focusHeadsUp
        ) { vm.edit(cfg.copy(focusHeadsUp = it)) }
        HorizontalDivider(color = Divider)
        SettingRow(
            Icons.Rounded.WbSunny, "Keep screen on",
            "Screen won't time out for 30 minutes", cfg.focusAwake
        ) { vm.edit(cfg.copy(focusAwake = it)) }
        HorizontalDivider(color = Divider)
        SettingRow(
            Icons.Rounded.BatteryChargingFull, "Battery Saver off",
            "Battery Saver slows the CPU. Turned off while you play", cfg.focusBatterySaver
        ) { vm.edit(cfg.copy(focusBatterySaver = it)) }
        Spacer(Modifier.height(6.dp))
        Text(
            "These apply with APPLY (same as the other options) and RESET puts every one back to how it was. " +
                "They don't switch back by themselves when you leave the game. " +
                "Calls from allowed contacts can still ring. Android may turn Battery Saver on again by itself when the battery gets low. " +
                "The \"Boost successful\" notification may be hidden while Do Not Disturb is on.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
    }
}

// ---------------------------------------------------------------------- ping meter

@Composable
fun PingMeterCard(
    vm: MainViewModel,
    running: Boolean,
    onToggle: (Boolean) -> Unit
) {
    NeonCard {
        SectionTitle("Ping Meter")
        SettingRow(
            Icons.Rounded.Speed, "Show ping overlay",
            "Live ping, average, jitter and lost replies. Drag the box to move it.", running, onToggle
        )
        Text(
            "Size  " + String.format(Locale.US, "%.1f", vm.scalePing) + "x",
            color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold
        )
        SizeSlider(vm.scalePing) { vm.setScale("ping", it) }
        Spacer(Modifier.height(6.dp))
        Text("Measure to", color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(6.dp))
        ChipRow(
            options = listOf(0, 1, 2),
            selected = vm.pmTarget,
            label = { listOf("Cloudflare", "Google", "My server")[it] }
        ) { vm.changePmTarget(it) }
        if (vm.pmTarget == 2) {
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = vm.pmHost,
                onValueChange = { vm.changePmHost(it) },
                singleLine = true,
                placeholder = { Text("game.server.com or 1.2.3.4:443", color = TextDim) },
                modifier = Modifier.fillMaxWidth(),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = Neon,
                    unfocusedBorderColor = Neon.copy(alpha = 0.4f),
                    cursorColor = Neon,
                    focusedTextColor = TextMain,
                    unfocusedTextColor = TextMain
                )
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            "How it works: every second GR FPS connects to the server and times the reply (TCP, port 443 unless you write another port). " +
                "That is the real network delay to that server over your current Wi-Fi / mobile data, but it isn't the game's own ping: " +
                "I can't see which server your game uses, and many games talk over UDP, which this can't test. " +
                "For a custom server, use one that accepts TCP on that port. Green is under 60 ms, yellow under 120 ms, red above. " +
                "High JITTER or LOSS means the connection is unstable even if the ping looks fine. " +
                "Cloudflare / Google show how good your internet is in general.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
    }
}

package com.gr.fps.ui

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.display.DisplayManager
import android.os.BatteryManager
import android.view.Display
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInHorizontally
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.CleaningServices
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DoNotDisturbOn
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.QueryStats
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SignalCellularAlt
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Videocam
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material.icons.rounded.Wifi
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gr.fps.Active
import com.gr.fps.ActiveStore
import com.gr.fps.BoostConfig
import com.gr.fps.DnsChoice
import com.gr.fps.FpsDetailService
import com.gr.fps.FpsHub
import com.gr.fps.FpsOverlayService
import com.gr.fps.GsHost
import com.gr.fps.GsOps
import com.gr.fps.GuardPrefs
import com.gr.fps.PingMeterService
import com.gr.fps.RecCaps
import com.gr.fps.RecPrefs
import com.gr.fps.RecState
import com.gr.fps.RecorderService
import com.gr.fps.ShizukuHelper
import com.gr.fps.ShizukuState
import com.gr.fps.SysProbe
import com.gr.fps.SysStats
import com.gr.fps.ThermalGuardService
import com.gr.fps.ThermalOverlayService
import com.gr.fps.UiPrefs
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max
import kotlin.math.roundToInt

private val PanelShape = CutCornerShape(topStart = 22.dp, bottomEnd = 22.dp)
private val TileShape = CutCornerShape(topStart = 12.dp, bottomEnd = 12.dp)
private val Bad = Color(0xFFFF5C5C)

private class Tile(
    val key: String,
    val label: String,
    val icon: ImageVector,
    val on: Boolean,
    val sub: String = "",
    val busy: Boolean = false,
    val hasPage: Boolean = false,
    val onClick: () -> Unit
)

private fun supportedHz(ctx: Context): List<Int> = try {
    val dm = ctx.getSystemService(DisplayManager::class.java)
    dm.getDisplay(Display.DEFAULT_DISPLAY).supportedModes
        .map { it.refreshRate.roundToInt() }.filter { it in 20..300 }.distinct().sorted()
} catch (_: Throwable) {
    emptyList()
}

// =========================================================================================== panel

@Composable
fun GameSpacePanel(host: GsHost) {
    val ctx = host.ctx
    val act by ActiveStore.state.collectAsState()
    val fps by FpsHub.stats.collectAsState()
    val shizuku by ShizukuHelper.state.collectAsState()
    val fpsRun by FpsOverlayService.running.collectAsState()
    val proRun by FpsDetailService.running.collectAsState()
    val tempRun by ThermalOverlayService.running.collectAsState()
    val pingRun by PingMeterService.running.collectAsState()
    val guardRun by ThermalGuardService.running.collectAsState()
    val recState by RecorderService.state.collectAsState()

    var sys by remember { mutableStateOf<SysStats?>(null) }
    var clock by remember { mutableStateOf("") }
    var battery by remember { mutableIntStateOf(-1) }
    var charging by remember { mutableStateOf(false) }
    var page by remember { mutableStateOf<String?>(null) }
    var shown by remember { mutableStateOf(false) }
    val hzList = remember { supportedHz(ctx) }

    LaunchedEffect(Unit) {
        shown = true
        FpsHub.acquire()
        try {
            val fmt = SimpleDateFormat("HH:mm", Locale.getDefault())
            while (true) {
                clock = fmt.format(Date())
                val b = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                if (b != null) {
                    val lvl = b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
                    val sc = b.getIntExtra(BatteryManager.EXTRA_SCALE, 100)
                    if (lvl >= 0 && sc > 0) battery = lvl * 100 / sc
                    val st = b.getIntExtra(BatteryManager.EXTRA_STATUS, -1)
                    charging = st == BatteryManager.BATTERY_STATUS_CHARGING || st == BatteryManager.BATTERY_STATUS_FULL
                }
                sys = withContext(Dispatchers.Default) { runCatching { SysProbe.sample(ctx) }.getOrNull() }
                delay(1000)
            }
        } finally {
            FpsHub.release()
        }
    }

    val busy = GsOps.busy
    val focusBusy = busy == "dnd" || busy == "headsUp" || busy == "awake" || busy == "saver"
    val focusCount = listOf(act.dnd, act.headsUp, act.awake, act.saver).count { it }

    val tiles = listOf(
        Tile("hz", "FPS Lock", Icons.Rounded.Lock, act.hz > 0, if (act.hz > 0) "${act.hz} Hz" else "", busy == "hz", true) { page = "hz" },
        Tile("dns", "Low Ping", Icons.Rounded.Wifi, act.dns.isNotEmpty(),
            DnsChoice.values().firstOrNull { it.name == act.dns }?.label ?: "", busy == "dns", true) { page = "dns" },
        Tile("focus", "Focus Mode", Icons.Rounded.DoNotDisturbOn, act.focusAny,
            if (focusCount > 0) "$focusCount on" else "", focusBusy, true) { page = "focus" },
        Tile("ram", "Free RAM", Icons.Rounded.Memory, false, "", busy == "ram") { GsOps.freeRam(ctx) },
        Tile("trim", "Trim Caches", Icons.Rounded.CleaningServices, false, "", busy == "trim") { GsOps.trimCaches(ctx) },
        Tile("gameMode", "Game Mode", Icons.Rounded.SportsEsports, act.gameMode, "Performance", busy == "gameMode") {
            GsOps.toggle(ctx, "gameMode", BoostConfig(gameMode = true))
        },
        Tile("scans", "Stop Scans", Icons.Rounded.WifiOff, act.scans, "", busy == "scans") {
            GsOps.toggle(ctx, "scans", BoostConfig(disableScans = true))
        },
        Tile("fixedPerf", "Fixed Perf", Icons.Rounded.Bolt, act.fixedPerf, "", busy == "fixedPerf") {
            GsOps.toggle(ctx, "fixedPerf", BoostConfig(fixedPerf = true))
        },
        Tile("fpsMeter", "FPS Meter", Icons.Rounded.Speed, fpsRun, hasPage = true) { page = "fpsMeter" },
        Tile("fpsPro", "FPS Meter Pro", Icons.Rounded.QueryStats, proRun, hasPage = true) { page = "fpsPro" },
        Tile("temp", "Temp & Bottleneck", Icons.Rounded.Thermostat, tempRun, hasPage = true) { page = "temp" },
        Tile("guard", "Thermal Guard", Icons.Rounded.Shield, guardRun, hasPage = true) { page = "guard" },
        Tile("ping", "Ping Meter", Icons.Rounded.SignalCellularAlt, pingRun, hasPage = true) { page = "ping" },
        Tile("rec", "Screen Recorder", Icons.Rounded.Videocam, recState != RecState.IDLE,
            when (recState) { RecState.RECORDING -> "REC"; RecState.PAUSED -> "Paused"; else -> "" }, hasPage = true) { page = "rec" },
        Tile("shot", "Screenshot", Icons.Rounded.PhotoCamera, false) { host.screenshot() }
    )

    BoxWithConstraints(
        Modifier
            .fillMaxSize()
            .background(Color(0x77000000))
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { host.close() }
    ) {
        val wide = maxWidth > maxHeight
        val panelMod = if (wide) {
            Modifier
                .align(Alignment.CenterStart)
                .padding(start = 10.dp)
                .width(minOf(maxWidth - 20.dp, 740.dp))
                .height(maxHeight - 20.dp)
        } else {
            Modifier
                .align(Alignment.Center)
                .width(maxWidth - 20.dp)
                .height(minOf(maxHeight - 40.dp, 640.dp))
        }
        AnimatedVisibility(
            visible = shown,
            enter = slideInHorizontally { -it } + fadeIn(),
            modifier = panelMod
        ) {
            Column(
                Modifier
                    .fillMaxSize()
                    .clip(PanelShape)
                    .background(Brush.verticalGradient(listOf(Color(0xF2102418), Color(0xF4050B07))))
                    .border(1.5.dp, Brush.linearGradient(listOf(Neon, Neon.copy(alpha = 0.15f))), PanelShape)
                    .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { }
                    .padding(12.dp)
            ) {
                HeaderBar(clock, battery, charging) { host.close() }
                if (busy != null) {
                    LinearProgressIndicator(
                        color = Neon, trackColor = Divider,
                        modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                    )
                } else {
                    Spacer(Modifier.height(8.dp))
                }
                if (shizuku != ShizukuState.READY) {
                    Text(
                        "Shizuku isn't connected: FPS, GPU and most buttons need it. Open GRFlow to connect.",
                        color = Bad, fontSize = 11.sp, lineHeight = 14.sp,
                        modifier = Modifier.padding(bottom = 6.dp)
                    )
                }
                if (page == null) {
                    if (wide) {
                        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            StatsBlock(fps?.fps, sys, maxHz(hzList), Modifier.width(210.dp).fillMaxHeight())
                            TileGrid(tiles, 4, Modifier.weight(1f).fillMaxHeight())
                        }
                    } else {
                        StatsBlock(fps?.fps, sys, maxHz(hzList), Modifier.fillMaxWidth())
                        Spacer(Modifier.height(10.dp))
                        TileGrid(tiles, 3, Modifier.weight(1f).fillMaxWidth())
                    }
                } else {
                    Box(Modifier.weight(1f).fillMaxWidth()) {
                        PageHost(page!!, host, act, hzList, recState) { page = null }
                    }
                }
                StatusLine()
            }
        }
    }
}

private fun maxHz(l: List<Int>) = max(60, l.maxOrNull() ?: 60)

// =========================================================================================== header / stats

@Composable
private fun HeaderBar(clock: String, battery: Int, charging: Boolean, onClose: () -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Bolt, null, tint = Neon, modifier = Modifier.size(24.dp))
        Spacer(Modifier.width(4.dp))
        Text(
            "GAME SPACE", color = Neon, fontSize = 18.sp,
            fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic, letterSpacing = 1.sp
        )
        Spacer(Modifier.weight(1f))
        Text(clock, color = TextMain, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.width(12.dp))
        BatteryChip(battery, charging)
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier
                .size(32.dp)
                .clip(RoundedCornerShape(50))
                .border(1.dp, Neon.copy(alpha = 0.6f), RoundedCornerShape(50))
                .clickable { onClose() },
            contentAlignment = Alignment.Center
        ) {
            Icon(Icons.Rounded.Close, "Close", tint = Neon, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
private fun BatteryChip(pct: Int, charging: Boolean) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
            Modifier
                .width(24.dp).height(12.dp)
                .border(1.5.dp, TextMain, RoundedCornerShape(3.dp))
                .padding(2.dp)
        ) {
            val f = if (pct < 0) 0f else pct / 100f
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(f.coerceIn(0f, 1f))
                    .background(if (pct in 0..15 && !charging) Bad else Neon)
            )
        }
        Spacer(Modifier.width(4.dp))
        Text(
            (if (pct >= 0) "$pct%" else "--") + if (charging) " ⚡" else "",
            color = TextMain, fontSize = 13.sp, fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun StatsBlock(fps: Int?, sys: SysStats?, maxFps: Int, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            FpsRing(fps, maxFps, 96.dp)
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                StatBar("CPU", sys?.cpuTotal)
                StatBar("GPU", sys?.gpu)
                val ramPct = sys?.let {
                    if (it.ramTotalMb > 0) (100 - it.ramFreeMb * 100 / it.ramTotalMb).toInt() else null
                }
                StatBar("RAM", ramPct)
            }
        }
        Spacer(Modifier.height(6.dp))
        val temp = sys?.let { listOfNotNull(it.cpuTemp, it.gpuTemp, it.batTemp).maxOrNull() }
        Text(
            buildString {
                append(if (temp != null) "Temp ${temp.roundToInt()}°C" else "Temp --")
                if (sys != null && sys.verdict.isNotEmpty()) append("  •  ").append(sys.verdict)
            },
            color = if ((sys?.level ?: 0) >= 2) Bad else TextDim,
            fontSize = 11.sp, lineHeight = 14.sp, textAlign = TextAlign.Center, maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
        if (fps == null) {
            Text(
                "FPS shows the app on screen; needs Shizuku", color = TextDim, fontSize = 10.sp,
                textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}

@Composable
private fun FpsRing(fps: Int?, maxFps: Int, dim: Dp) {
    val frac = if (fps == null) 0f else (fps / maxFps.toFloat()).coerceIn(0f, 1f)
    val anim by animateFloatAsState(frac, label = "fps")
    Box(Modifier.size(dim), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val sw = this.size.minDimension * 0.11f
            val inset = sw / 2
            val arcSize = Size(this.size.width - sw, this.size.height - sw)
            drawArc(
                color = Divider, startAngle = 135f, sweepAngle = 270f, useCenter = false,
                topLeft = Offset(inset, inset), size = arcSize, style = Stroke(sw, cap = StrokeCap.Round)
            )
            if (anim > 0f) {
                drawArc(
                    color = Neon, startAngle = 135f, sweepAngle = 270f * anim, useCenter = false,
                    topLeft = Offset(inset, inset), size = arcSize, style = Stroke(sw, cap = StrokeCap.Round)
                )
            }
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(fps?.toString() ?: "--", color = Neon, fontSize = 28.sp, fontWeight = FontWeight.Black)
            Text("FPS", color = TextDim, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun StatBar(label: String, pct: Int?) {
    Column {
        Row(Modifier.fillMaxWidth()) {
            Text(label, color = TextDim, fontSize = 11.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.weight(1f))
            Text(if (pct != null) "$pct%" else "--", color = TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold)
        }
        Spacer(Modifier.height(3.dp))
        Box(
            Modifier
                .fillMaxWidth().height(6.dp)
                .clip(RoundedCornerShape(3.dp))
                .background(Divider)
        ) {
            val f = ((pct ?: 0) / 100f).coerceIn(0f, 1f)
            Box(
                Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(f)
                    .background(
                        Brush.horizontalGradient(
                            listOf(NeonDim, if ((pct ?: 0) >= 90) Bad else Neon)
                        )
                    )
            )
        }
    }
}

// =========================================================================================== tiles

@Composable
private fun TileGrid(tiles: List<Tile>, cols: Int, modifier: Modifier) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(cols),
        modifier = modifier,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(tiles, key = { it.key }) { t -> TileView(t) }
    }
}

@Composable
private fun TileView(t: Tile) {
    val bg = if (t.on) Brush.verticalGradient(listOf(Neon.copy(alpha = 0.30f), Neon.copy(alpha = 0.08f)))
    else Brush.verticalGradient(listOf(CardTop, CardBottom))
    Box(
        Modifier
            .fillMaxWidth()
            .height(82.dp)
            .clip(TileShape)
            .background(bg)
            .border(
                if (t.on) 1.6.dp else 1.dp,
                if (t.on) Neon else Neon.copy(alpha = 0.25f), TileShape
            )
            .clickable { t.onClick() }
            .padding(6.dp)
    ) {
        Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(t.icon, null, tint = if (t.on) Neon else TextMain, modifier = Modifier.size(26.dp))
            Spacer(Modifier.height(4.dp))
            Text(
                t.label, color = if (t.on) Neon else TextMain, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center, maxLines = 2, lineHeight = 12.sp
            )
            if (t.sub.isNotEmpty()) {
                Text(t.sub, color = Neon, fontSize = 9.sp, fontWeight = FontWeight.Black, maxLines = 1)
            }
        }
        if (t.busy) {
            CircularProgressIndicator(
                color = Neon, strokeWidth = 2.dp,
                modifier = Modifier.align(Alignment.TopStart).size(14.dp)
            )
        }
        if (t.hasPage) {
            Text("›", color = Neon, fontSize = 16.sp, fontWeight = FontWeight.Black, modifier = Modifier.align(Alignment.TopEnd))
        } else if (t.on) {
            Box(
                Modifier
                    .align(Alignment.TopEnd)
                    .size(7.dp)
                    .clip(RoundedCornerShape(50))
                    .background(Neon)
            )
        }
    }
}

@Composable
private fun StatusLine() {
    val s = GsOps.status
    if (s.isEmpty()) return
    Column(Modifier.fillMaxWidth().padding(top = 6.dp)) {
        s.lines().take(4).forEach { l ->
            Text(
                l, color = if (l.startsWith("✘")) Bad else Neon, fontSize = 11.sp, lineHeight = 13.sp,
                maxLines = 3, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

// =========================================================================================== detail pages

@Composable
private fun PageHost(
    page: String, host: GsHost, act: Active, hzList: List<Int>, recState: RecState, onBack: () -> Unit
) {
    val title = when (page) {
        "hz" -> "FPS Lock"
        "dns" -> "Low Ping"
        "focus" -> "Focus Mode"
        "guard" -> "Thermal Guard"
        "ping" -> "Ping Meter"
        "fpsMeter" -> "FPS Meter"
        "fpsPro" -> "FPS Meter Pro"
        "temp" -> "Temp & Bottleneck"
        else -> "Screen Recorder"
    }
    Column(Modifier.fillMaxSize()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier
                    .size(34.dp)
                    .clip(RoundedCornerShape(50))
                    .border(1.dp, Neon.copy(alpha = 0.6f), RoundedCornerShape(50))
                    .clickable { onBack() },
                contentAlignment = Alignment.Center
            ) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Back", tint = Neon, modifier = Modifier.size(20.dp)) }
            Spacer(Modifier.width(10.dp))
            Text(title, color = Neon, fontSize = 17.sp, fontWeight = FontWeight.Black)
        }
        Spacer(Modifier.height(8.dp))
        Column(
            Modifier
                .weight(1f)
                .fillMaxWidth()
                .verticalScroll(rememberScrollState())
        ) {
            when (page) {
                "hz" -> HzPage(host, act, hzList)
                "dns" -> DnsPage(host, act)
                "focus" -> FocusPage(host, act)
                "guard" -> GuardPage(host)
                "ping" -> PingPage(host)
                "fpsMeter" -> OverlayPage(host, "fps", FpsOverlayService::class.java, true,
                    "Shows the real FPS of the app on screen. Drag the meter to move it.")
                "fpsPro" -> OverlayPage(host, "detail", FpsDetailService::class.java, true,
                    "FPS with average, 1% low, stutters and a frame-time graph. Drag it to move it.")
                "temp" -> OverlayPage(host, "thermal", ThermalOverlayService::class.java, false,
                    "CPU/GPU load, temperatures and what is holding the phone back. Drag it to move it.")
                else -> RecPage(host, recState)
            }
        }
    }
}

@Composable
private fun Note(text: String) {
    Text(text, color = TextDim, fontSize = 11.sp, lineHeight = 14.sp, modifier = Modifier.padding(top = 8.dp))
}

@Composable
private fun Label(text: String) {
    Text(text, color = TextMain, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 10.dp, bottom = 6.dp))
}

@Composable
private fun HzPage(host: GsHost, act: Active, hzList: List<Int>) {
    val ctx = host.ctx
    val options = if (hzList.isEmpty()) listOf(60, 90, 120) else hzList
    var sel by remember {
        mutableIntStateOf(
            when {
                act.hz > 0 -> act.hz
                ActiveStore.lastHz(ctx) in options -> ActiveStore.lastHz(ctx)
                else -> options.last()
            }
        )
    }
    Label("Lock the screen refresh rate")
    ChipRow(options = options, selected = sel, label = { "$it Hz" }, perRow = 4) { sel = it }
    Spacer(Modifier.height(12.dp))
    val isOff = act.hz > 0 && act.hz == sel
    NeonButton(
        if (isOff) "TURN OFF" else "TURN ON ${sel} Hz", Icons.Rounded.Bolt,
        { GsOps.lockHz(ctx, sel) }, Modifier.fillMaxWidth(), filled = !isOff, enabled = GsOps.busy == null
    )
    if (act.hz > 0) Text("Now locked to ${act.hz} Hz", color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
    Note("Locks the screen's refresh rate (not the game's own frame rate). Only the rates your screen supports are shown. " +
        "If the phone's own Display settings override apps, it says so and undoes the change.")
}

private fun tcpPing(ip: String): Int? {
    val times = ArrayList<Long>()
    repeat(3) {
        val t0 = System.nanoTime()
        try {
            Socket().use { s ->
                s.connect(InetSocketAddress(ip, 853), 1500)
                times.add((System.nanoTime() - t0) / 1_000_000)
            }
        } catch (_: Throwable) {
        }
    }
    return if (times.isEmpty()) null else times.average().roundToInt()
}

@Composable
private fun DnsPage(host: GsHost, act: Active) {
    val ctx = host.ctx
    val scope = rememberCoroutineScope()
    var pings by remember { mutableStateOf<Map<DnsChoice, Int?>>(emptyMap()) }
    var testing by remember { mutableStateOf(false) }
    val all = DnsChoice.values().toList()
    var sel by remember {
        mutableStateOf(
            all.firstOrNull { it.name == act.dns }
                ?: all.firstOrNull { it.name == ActiveStore.lastDns(ctx) } ?: DnsChoice.CLOUDFLARE
        )
    }
    Label("Private DNS server")
    ChipRow(
        options = all, selected = sel, perRow = 3,
        label = { d -> if (pings.containsKey(d)) "${d.label}\n${pings[d]?.let { "$it ms" } ?: "no reply"}" else d.label }
    ) { sel = it }
    Spacer(Modifier.height(8.dp))
    Row(verticalAlignment = Alignment.CenterVertically) {
        SmallButton(if (testing) "TESTING…" else "TEST SPEED") {
            if (!testing) {
                testing = true
                scope.launch {
                    val r = withContext(Dispatchers.IO) { all.associateWith { tcpPing(it.ip) } }
                    pings = r
                    r.filterValues { it != null }.minByOrNull { it.value ?: Int.MAX_VALUE }?.key?.let { sel = it }
                    testing = false
                }
            }
        }
        Spacer(Modifier.width(8.dp))
        Text("picks the fastest", color = TextDim, fontSize = 11.sp)
    }
    Spacer(Modifier.height(12.dp))
    val isOff = act.dns == sel.name
    NeonButton(
        if (isOff) "TURN OFF" else "TURN ON ${sel.label}", Icons.Rounded.Wifi,
        { GsOps.lowPing(ctx, sel) }, Modifier.fillMaxWidth(), filled = !isOff, enabled = GsOps.busy == null
    )
    if (act.dns.isNotEmpty()) Text("Active: ${DnsChoice.values().firstOrNull { it.name == act.dns }?.label ?: act.dns}", color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
    Note("Switches the phone's Private DNS to a faster server. It checks the internet still works and reverts by itself if not. It does not change the game's server distance.")
}

@Composable
private fun FocusPage(host: GsHost, act: Active) {
    val ctx = host.ctx
    val b = GsOps.busy == null
    Note("Each switch works at once. Turn it off to put the phone setting back.")
    SettingRow(Icons.Rounded.DoNotDisturbOn, "Do Not Disturb", "Priority only: calls and alerts stay quiet", act.dnd) {
        if (b) GsOps.toggle(ctx, "dnd", BoostConfig(focusDnd = true))
    }
    HorizontalDivider(color = Divider)
    SettingRow(Icons.Rounded.Shield, "Hide pop-up banners", "No notification banners over the game", act.headsUp) {
        if (b) GsOps.toggle(ctx, "headsUp", BoostConfig(focusHeadsUp = true))
    }
    HorizontalDivider(color = Divider)
    SettingRow(Icons.Rounded.Speed, "Keep screen on 30 min", "The screen won't dim or sleep while you play", act.awake) {
        if (b) GsOps.toggle(ctx, "awake", BoostConfig(focusAwake = true))
    }
    HorizontalDivider(color = Divider)
    SettingRow(Icons.Rounded.Bolt, "Battery Saver off", "So the phone doesn't slow itself down", act.saver) {
        if (b) GsOps.toggle(ctx, "saver", BoostConfig(focusBatterySaver = true))
    }
}

@Composable
private fun GuardPage(host: GsHost) {
    val ctx = host.ctx
    val running by ThermalGuardService.running.collectAsState()
    val status by ThermalGuardService.status.collectAsState()
    var sens by remember { mutableIntStateOf(GuardPrefs.sens(ctx)) }
    var hz by remember { mutableStateOf(GuardPrefs.hz(ctx)) }
    var reso by remember { mutableStateOf(GuardPrefs.reso(ctx)) }
    val (soc, bat) = GuardPrefs.limits(sens)
    Label("Sensitivity")
    ChipRow(options = listOf(0, 1, 2), selected = sens, label = { listOf("Early", "Normal", "Late")[it] }) {
        sens = it
        GuardPrefs.setSens(ctx, it)
        ActiveStore.events.tryEmit("guard")
    }
    Text("Hot at: battery $bat°C or chip $soc°C, or when Android starts throttling.", color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp))
    SettingRow(Icons.Rounded.Thermostat, "Drop screen to 60 Hz", "Only if the screen is above 60 Hz now", hz) {
        hz = it; GuardPrefs.setHz(ctx, it); ActiveStore.events.tryEmit("guard")
    }
    HorizontalDivider(color = Divider)
    SettingRow(Icons.Rounded.Thermostat, "Lower the resolution a step", "Some games flicker when the screen size changes", reso) {
        reso = it; GuardPrefs.setReso(ctx, it); ActiveStore.events.tryEmit("guard")
    }
    Spacer(Modifier.height(10.dp))
    NeonButton(
        if (running) "TURN OFF" else "TURN ON", Icons.Rounded.Shield,
        { GsOps.guard(ctx, !running) }, Modifier.fillMaxWidth(), filled = !running
    )
    if (running && status.isNotEmpty()) Text(status, color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
    Note("Everything is put back after the phone stays cool for 45 seconds, or when you turn it off.")
}

@Composable
private fun OverlayPage(host: GsHost, key: String, cls: Class<*>, needShizuku: Boolean, note: String) {
    val ctx = host.ctx
    val running by when (key) {
        "fps" -> FpsOverlayService.running
        "detail" -> FpsDetailService.running
        else -> ThermalOverlayService.running
    }.collectAsState()
    var scale by remember { mutableFloatStateOf(UiPrefs.scale(ctx, key)) }
    Label("Size  " + String.format(Locale.US, "%.1f", scale) + "x")
    SizeSlider(scale) {
        val s = (it * 10).roundToInt() / 10f
        scale = s
        UiPrefs.setScale(ctx, key, s)
        ActiveStore.events.tryEmit("scale")
    }
    Spacer(Modifier.height(6.dp))
    NeonButton(
        if (running) "HIDE" else "SHOW", Icons.Rounded.Speed,
        { GsOps.overlay(ctx, cls, running, needShizuku) }, Modifier.fillMaxWidth(), filled = !running
    )
    Note(note)
}

@Composable
private fun PingPage(host: GsHost) {
    val ctx = host.ctx
    val running by PingMeterService.running.collectAsState()
    var target by remember { mutableIntStateOf(UiPrefs.pmTarget(ctx)) }
    var scale by remember { mutableFloatStateOf(UiPrefs.scale(ctx, "ping")) }
    Label("Measure to")
    ChipRow(options = listOf(0, 1, 2), selected = target, label = { listOf("Cloudflare", "Google", "My server")[it] }) {
        target = it
        UiPrefs.setPmTarget(ctx, it)
        ActiveStore.events.tryEmit("ping")
    }
    if (target == 2) {
        val h = UiPrefs.pmHost(ctx)
        Text(
            if (h.isBlank()) "Type your server address in the GRFlow app (Ping Meter card)." else "Server: $h",
            color = TextDim, fontSize = 11.sp, modifier = Modifier.padding(top = 4.dp)
        )
    }
    Label("Size  " + String.format(Locale.US, "%.1f", scale) + "x")
    SizeSlider(scale) {
        val s = (it * 10).roundToInt() / 10f
        scale = s
        UiPrefs.setScale(ctx, "ping", s)
        ActiveStore.events.tryEmit("scale")
    }
    Spacer(Modifier.height(6.dp))
    NeonButton(
        if (running) "HIDE PING METER" else "SHOW PING METER", Icons.Rounded.SignalCellularAlt,
        { GsOps.overlay(ctx, PingMeterService::class.java, running, false) },
        Modifier.fillMaxWidth(), filled = !running
    )
    Note("Real network delay to that server, measured every second. Drag the meter on screen to move it.")
}

@Composable
private fun RecPage(host: GsHost, state: RecState) {
    val ctx = host.ctx
    var caps by remember { mutableStateOf<RecCaps?>(null) }
    var res by remember { mutableIntStateOf(RecPrefs.res(ctx)) }
    var fps by remember { mutableIntStateOf(RecPrefs.fps(ctx)) }
    var mic by remember { mutableStateOf(RecPrefs.mic(ctx)) }
    var internal by remember { mutableStateOf(RecPrefs.internal(ctx)) }
    val landscape = RecPrefs.landscape(ctx)
    LaunchedEffect(Unit) {
        caps = withContext(Dispatchers.Default) { runCatching { RecCaps.probe(ctx) }.getOrNull() }
    }
    fun changed() {
        RecorderService.refreshReady(ctx)
        ActiveStore.events.tryEmit("rec")
    }
    val c = caps
    Label("Resolution")
    ChipRow(
        options = listOf(360, 480, 720, 1080, 1280, 1440, 2160), selected = res, label = { "${it}p" }, perRow = 4,
        enabled = { r -> c == null || (r <= c.nativeShort && c.sizeOk(r, landscape)) }
    ) { res = it; RecPrefs.setRes(ctx, it); changed() }
    Label("Frame rate")
    ChipRow(
        options = listOf(30, 60, 90, 120), selected = fps, label = { "$it fps" },
        enabled = { f -> c == null || c.fpsOk(res.coerceAtMost(c.nativeShort), f, landscape) }
    ) { fps = it; RecPrefs.setFps(ctx, it); changed() }
    SettingRow(Icons.Rounded.VolumeUp, "Phone / game sound", "Records what the phone plays", internal) {
        internal = it; RecPrefs.setInternal(ctx, it); changed()
    }
    HorizontalDivider(color = Divider)
    SettingRow(Icons.Rounded.Mic, "Microphone", "Records your voice", mic) {
        mic = it; RecPrefs.setMic(ctx, it); changed()
    }
    Spacer(Modifier.height(10.dp))
    when (state) {
        RecState.IDLE -> NeonButton("START RECORDING", Icons.Rounded.Videocam, { host.startRecording() }, Modifier.fillMaxWidth())
        RecState.RECORDING -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("PAUSE", Icons.Rounded.Pause, { GsOps.recorder(ctx, RecorderService.ACTION_PAUSE) }, Modifier.weight(1f), filled = false)
            NeonButton("STOP", Icons.Rounded.Stop, { GsOps.recorder(ctx, RecorderService.ACTION_STOP) }, Modifier.weight(1f))
        }
        RecState.PAUSED -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            NeonButton("RESUME", Icons.Rounded.PlayArrow, { GsOps.recorder(ctx, RecorderService.ACTION_RESUME) }, Modifier.weight(1f), filled = false)
            NeonButton("STOP", Icons.Rounded.Stop, { GsOps.recorder(ctx, RecorderService.ACTION_STOP) }, Modifier.weight(1f))
        }
    }
    Note("Android shows its own \"Start recording?\" popup every time; tap Start now there. Videos are saved in Movies/GRFlow.")
}

// =========================================================================================== main-app card

@Composable
fun GameSpaceCard(on: Boolean, onToggle: (Boolean) -> Unit) {
    NeonCard {
        SectionTitle("Game Space")
        SettingRow(
            Icons.Rounded.SportsEsports, "Game Space",
            "A small green tab on the left edge of the screen. Tap it (or slide it right) to open your game tools on top of any game",
            on, onToggle
        )
        Text(
            "Inside Game Space every button works at once, no APPLY needed, and tapping a button again turns it off. " +
                "What you switch on there shows as on here, and what you APPLY here shows as on there.",
            color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
        )
    }
}

package com.gr.fps.ui

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.gr.fps.Level
import kotlin.math.cos
import kotlin.math.sin

val TechShape = CutCornerShape(topStart = 18.dp, bottomEnd = 18.dp)
private val ChipShape = CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)

private val cardBrush get() = Brush.verticalGradient(listOf(CardTop, CardBottom))
private val borderBrush get() = Brush.linearGradient(listOf(Neon.copy(alpha = 0.9f), Neon.copy(alpha = 0.12f)))

@Composable
fun NeonCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(TechShape)
            .background(cardBrush)
            .border(1.2.dp, borderBrush, TechShape)
            .padding(16.dp),
        content = content
    )
}

@Composable
fun SectionTitle(text: String) {
    Text(
        text.uppercase(),
        color = Neon,
        fontSize = 13.sp,
        fontWeight = FontWeight.Black,
        letterSpacing = 1.5.sp,
        modifier = Modifier.padding(bottom = 10.dp)
    )
}

@Composable
fun NeonButton(
    text: String,
    icon: ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = true,
    enabled: Boolean = true
) {
    val fg = if (filled) Color.Black else Neon
    Row(
        modifier
            .height(54.dp)
            .alpha(if (enabled) 1f else 0.4f)
            .clip(TechShape)
            .background(
                if (filled) Brush.horizontalGradient(listOf(Neon, NeonDim))
                else Brush.horizontalGradient(listOf(Color.Transparent, Color.Transparent))
            )
            .border(1.5.dp, if (filled) Color.Transparent else Neon, TechShape)
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = fg, modifier = Modifier.size(22.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, color = fg, fontWeight = FontWeight.Black, fontSize = 16.sp, letterSpacing = 1.sp)
    }
}

@Composable
fun SmallButton(text: String, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(ChipShape)
            .background(Brush.horizontalGradient(listOf(Neon, NeonDim)))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(text, color = Color.Black, fontWeight = FontWeight.Black, fontSize = 12.sp)
    }
}

@Composable
fun ActionTile(label: String, icon: ImageVector, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier
            .height(100.dp)
            .clip(TechShape)
            .background(cardBrush)
            .border(1.dp, Neon.copy(alpha = 0.6f), TechShape)
            .clickable(onClick = onClick)
            .padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(icon, null, tint = Neon, modifier = Modifier.size(30.dp))
        Spacer(Modifier.height(6.dp))
        Text(
            label,
            color = TextMain,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            lineHeight = 13.sp,
            maxLines = 2
        )
    }
}

@Composable
fun LevelSelector(selected: Level?, onSelect: (Level) -> Unit) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Level.values().forEach { l ->
            val on = l == selected
            Box(
                Modifier
                    .weight(1f)
                    .height(46.dp)
                    .clip(ChipShape)
                    .background(if (on) Brush.horizontalGradient(listOf(Neon, NeonDim)) else Brush.horizontalGradient(listOf(CardBottom, CardBottom)))
                    .border(1.dp, if (on) Neon else Neon.copy(alpha = 0.3f), ChipShape)
                    .clickable { onSelect(l) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    l.label,
                    color = if (on) Color.Black else TextMain,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Black,
                    textAlign = TextAlign.Center,
                    lineHeight = 12.sp,
                    maxLines = 2
                )
            }
        }
    }
}

@Composable
fun SettingRow(
    icon: ImageVector,
    title: String,
    desc: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Neon, modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(desc, color = TextDim, fontSize = 11.sp, lineHeight = 14.sp)
        }
        Switch(
            checked = checked,
            onCheckedChange = onChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.Black,
                checkedTrackColor = Neon,
                uncheckedThumbColor = TextDim,
                uncheckedTrackColor = Color(0xFF16231B),
                uncheckedBorderColor = Color(0xFF2A3F32)
            )
        )
    }
}

@Composable
fun NeonSlider(value: Float, onChange: (Float) -> Unit) {
    Slider(
        value = value,
        onValueChange = onChange,
        valueRange = 0.25f..1f,
        steps = 14,
        colors = SliderDefaults.colors(
            thumbColor = Neon,
            activeTrackColor = Neon,
            inactiveTrackColor = Color(0xFF1C2B22),
            activeTickColor = Color.Transparent,
            inactiveTickColor = Color.Transparent
        )
    )
}

@Composable
fun PermissionRow(
    icon: ImageVector,
    title: String,
    desc: String,
    granted: Boolean,
    actionLabel: String,
    onClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (granted) Neon else Color(0xFFFFB300), modifier = Modifier.size(26.dp))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = TextMain, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text(desc, color = TextDim, fontSize = 11.sp, lineHeight = 14.sp)
        }
        Spacer(Modifier.width(8.dp))
        if (granted) {
            Text("ON", color = Neon, fontWeight = FontWeight.Black, fontSize = 13.sp)
        } else {
            SmallButton(actionLabel, onClick)
        }
    }
}

/** Half-circle gauge: 5 colour segments light up with the boost level. */
@Composable
fun BoostGauge(score: Int, modifier: Modifier = Modifier) {
    val anim by animateFloatAsState(score.toFloat(), label = "gauge")
    val colors = listOf(
        Color(0xFF1FBF3A), Color(0xFF7CFF3A), Color(0xFFE6F02A), Color(0xFFFFA000), Color(0xFFFF3D00)
    )
    Canvas(modifier.fillMaxSize()) {
        val stroke = 22.dp.toPx()
        val d = size.width - stroke
        val topLeft = Offset(stroke / 2, stroke / 2)
        val seg = 180f / colors.size
        colors.forEachIndexed { i, c ->
            val active = anim > i * (100f / colors.size)
            drawArc(
                color = c.copy(alpha = if (active) 1f else 0.18f),
                startAngle = 180f + i * seg + 1.5f,
                sweepAngle = seg - 3f,
                useCenter = false,
                topLeft = topLeft,
                size = Size(d, d),
                style = Stroke(width = stroke)
            )
        }
        val cx = size.width / 2
        val cy = stroke / 2 + d / 2
        val rad = Math.toRadians((180.0 + 180.0 * anim / 100.0))
        val len = d / 2 - stroke * 1.3f
        drawLine(
            color = Color.White,
            start = Offset(cx, cy),
            end = Offset(cx + len * cos(rad).toFloat(), cy + len * sin(rad).toFloat()),
            strokeWidth = 5.dp.toPx(),
            cap = StrokeCap.Round
        )
        drawCircle(Color.White, radius = 8.dp.toPx(), center = Offset(cx, cy))
        drawCircle(Bg, radius = 3.dp.toPx(), center = Offset(cx, cy))
    }
}

/** FPS lock presets. null = "Default" (don't touch). Rates the panel doesn't have are greyed out. */
@Composable
fun RatePicker(selected: Int?, supported: Set<Int>, onSelect: (Int?) -> Unit) {
    val options = listOf<Int?>(null, 30, 60, 90, 120, 144, 165, 185)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { p ->
                    val on = p == selected
                    val enabled = p == null || supported.isEmpty() || p in supported
                    Box(
                        Modifier
                            .weight(1f)
                            .height(44.dp)
                            .alpha(if (enabled) 1f else 0.3f)
                            .clip(ChipShape)
                            .background(
                                if (on) Brush.horizontalGradient(listOf(Neon, NeonDim))
                                else Brush.horizontalGradient(listOf(CardBottom, CardBottom))
                            )
                            .border(1.dp, if (on) Neon else Neon.copy(alpha = 0.3f), ChipShape)
                            .clickable(enabled = enabled) { onSelect(p) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (p == null) "Default" else "$p",
                            color = if (on) Color.Black else TextMain,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}

/** Graphics driver chips: Default / OpenGL ES / Vulkan (Vulkan greyed out when unsupported). */
@Composable
fun GfxPicker(selected: com.gr.fps.GfxApi?, vulkanOk: Boolean, onSelect: (com.gr.fps.GfxApi?) -> Unit) {
    val options = listOf<com.gr.fps.GfxApi?>(null, com.gr.fps.GfxApi.GLES, com.gr.fps.GfxApi.VULKAN)
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        options.forEach { p ->
            val on = p == selected
            val enabled = p != com.gr.fps.GfxApi.VULKAN || vulkanOk
            Box(
                Modifier
                    .weight(1f)
                    .height(44.dp)
                    .alpha(if (enabled) 1f else 0.3f)
                    .clip(ChipShape)
                    .background(
                        if (on) Brush.horizontalGradient(listOf(Neon, NeonDim))
                        else Brush.horizontalGradient(listOf(CardBottom, CardBottom))
                    )
                    .border(1.dp, if (on) Neon else Neon.copy(alpha = 0.3f), ChipShape)
                    .clickable(enabled = enabled) { onSelect(p) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    p?.label ?: "Default",
                    color = if (on) Color.Black else TextMain,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Black
                )
            }
        }
    }
}

/** Resolution presets. null = "Default" (don't touch). Presets above the real panel are greyed out. */
@Composable
fun ResolutionPicker(selected: Int?, nativeShort: Int, onSelect: (Int?) -> Unit) {
    val options = listOf<Int?>(null, 360, 480, 720, 900, 1080, 1440, 2160)
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        options.chunked(4).forEach { row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { p ->
                    val on = p == selected
                    val enabled = p == null || nativeShort == 0 || p <= nativeShort
                    Box(
                        Modifier
                            .weight(1f)
                            .height(44.dp)
                            .alpha(if (enabled) 1f else 0.3f)
                            .clip(ChipShape)
                            .background(
                                if (on) Brush.horizontalGradient(listOf(Neon, NeonDim))
                                else Brush.horizontalGradient(listOf(CardBottom, CardBottom))
                            )
                            .border(1.dp, if (on) Neon else Neon.copy(alpha = 0.3f), ChipShape)
                            .clickable(enabled = enabled) { onSelect(p) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            if (p == null) "Default" else "${p}p",
                            color = if (on) Color.Black else TextMain,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Black
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun BigScore(score: Int) {
    Text(
        "$score%",
        color = Neon,
        fontSize = 44.sp,
        fontWeight = FontWeight.Black,
        fontStyle = FontStyle.Italic
    )
}

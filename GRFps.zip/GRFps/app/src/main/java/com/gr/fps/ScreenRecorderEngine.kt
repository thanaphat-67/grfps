package com.gr.fps

import android.content.ContentValues
import android.content.Context
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import android.media.MediaMuxer
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.HandlerThread
import android.os.ParcelFileDescriptor
import android.os.Process
import android.provider.MediaStore
import android.view.Surface
import java.io.File
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread

/**
 * Low-overhead screen recorder.
 *
 * Why it is light on the phone: the screen is rendered straight into the hardware video encoder's input
 * surface (no copying through the CPU), the encoder runs on its own dedicated chip block, and audio is
 * mixed in a tiny separate thread. Lower resolution / fps lowers the load further.
 */
class ScreenRecorderEngine(
    private val ctx: Context,
    private val projection: MediaProjection,
    private val width: Int,
    private val height: Int,
    private val dpi: Int,
    private val fps: Int,
    private val bitrate: Int,
    private val encoderName: String?,
    private val wantMic: Boolean,
    private val wantInternal: Boolean,
    private val onProjectionStop: () -> Unit
) {
    var audioDescription: String = "no audio"
        private set
    var outputUri: Uri? = null
        private set

    @Volatile private var running = false
    @Volatile private var paused = false
    @Volatile private var needKey = false
    private var started = false

    private var baseSet = false
    private var basePts = 0L
    private var lastPts = 0L
    private var pauseOffset = 0L
    private val frameDurUs = 1_000_000L / fps.coerceAtLeast(1)

    private var vEnc: MediaCodec? = null
    private var surface: Surface? = null
    private var vd: VirtualDisplay? = null
    private var aEnc: MediaCodec? = null
    private var micRec: AudioRecord? = null
    private var intRec: AudioRecord? = null
    private var muxer: SyncMuxer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var outFile: File? = null
    private var vThread: Thread? = null
    private var aThread: Thread? = null
    @Volatile private var videoTrack = -1
    @Volatile private var audioTrack = -1

    private val bg = HandlerThread("gr-rec-cb").also { it.start() }
    private val callback = object : MediaProjection.Callback() {
        override fun onStop() {
            onProjectionStop()
        }
    }

    private val sampleRate = 44100

    // ------------------------------------------------------------------ start

    fun start() {
        try {
            openOutput()
            setupAudio()

            val fmt = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, width, height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE, fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 2)
                setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
                setInteger(MediaFormat.KEY_PRIORITY, 0)
                if (Build.VERSION.SDK_INT >= 30) setInteger(MediaFormat.KEY_LATENCY, 1)
            }
            val enc = if (encoderName != null) MediaCodec.createByCodecName(encoderName)
            else MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
            enc.configure(fmt, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            surface = enc.createInputSurface()
            vEnc = enc

            muxer = SyncMuxer(
                MediaMuxer(pfd!!.fileDescriptor, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4),
                if (aEnc != null) 2 else 1
            )

            enc.start()
            running = true

            vThread = thread(name = "gr-rec-video") {
                Process.setThreadPriority(Process.THREAD_PRIORITY_DISPLAY)
                videoLoop()
            }
            if (aEnc != null) {
                aThread = thread(name = "gr-rec-audio") {
                    Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO)
                    audioLoop()
                }
            }

            // Must be registered before the virtual display is created (Android 14+)
            projection.registerCallback(callback, Handler(bg.looper))
            vd = projection.createVirtualDisplay(
                "GRFpsRec", width, height, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null
            )
            started = true
        } catch (t: Throwable) {
            running = false
            cleanup(deleteOutput = true)
            throw t
        }
    }

    // ------------------------------------------------------------------ pause / resume

    fun pause() {
        if (!running || paused) return
        paused = true
        try {
            vd?.surface = null   // the screen stops being copied while paused
        } catch (_: Throwable) {
        }
    }

    fun resume() {
        if (!running || !paused) return
        needKey = true          // after a pause we only continue from a fresh key frame
        paused = false
        try {
            vd?.surface = surface
            vEnc?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ stop

    /** Finishes the file. Returns its Uri, or null when nothing was recorded. */
    fun stop(): Uri? {
        if (!started) {
            cleanup(deleteOutput = true)
            return null
        }
        running = false
        paused = false
        try {
            vd?.release()
        } catch (_: Throwable) {
        }
        vd = null
        try {
            vEnc?.signalEndOfInputStream()
        } catch (_: Throwable) {
        }
        vThread?.join(4000)
        aThread?.join(4000)
        return cleanup(deleteOutput = false)
    }

    private fun cleanup(deleteOutput: Boolean): Uri? {
        try { vd?.release() } catch (_: Throwable) {}
        vd = null
        try { vEnc?.stop() } catch (_: Throwable) {}
        try { vEnc?.release() } catch (_: Throwable) {}
        vEnc = null
        try { surface?.release() } catch (_: Throwable) {}
        surface = null
        try { aEnc?.stop() } catch (_: Throwable) {}
        try { aEnc?.release() } catch (_: Throwable) {}
        aEnc = null
        try { micRec?.release() } catch (_: Throwable) {}
        try { intRec?.release() } catch (_: Throwable) {}
        micRec = null
        intRec = null

        val samples = muxer?.finish() ?: 0
        muxer = null
        val keep = !deleteOutput && samples > 0
        closeOutput(keep)

        try { projection.unregisterCallback(callback) } catch (_: Throwable) {}
        try { projection.stop() } catch (_: Throwable) {}
        bg.quitSafely()
        return if (keep) outputUri else null
    }

    // ------------------------------------------------------------------ output file

    private fun openOutput() {
        val name = "GRFPS_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".mp4"
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, name)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/GRFlow")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                ?: throw IOException("Can't create the video file")
            outputUri = uri
            pfd = ctx.contentResolver.openFileDescriptor(uri, "rw")
                ?: throw IOException("Can't open the video file")
        } else {
            val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_MOVIES) ?: ctx.filesDir
            dir.mkdirs()
            val f = File(dir, name)
            outFile = f
            outputUri = Uri.fromFile(f)
            pfd = ParcelFileDescriptor.open(
                f,
                ParcelFileDescriptor.MODE_READ_WRITE or ParcelFileDescriptor.MODE_CREATE or ParcelFileDescriptor.MODE_TRUNCATE
            )
        }
    }

    private fun closeOutput(keep: Boolean) {
        try { pfd?.close() } catch (_: Throwable) {}
        pfd = null
        val uri = outputUri ?: return
        if (Build.VERSION.SDK_INT >= 29) {
            try {
                if (keep) {
                    val v = ContentValues().apply { put(MediaStore.Video.Media.IS_PENDING, 0) }
                    ctx.contentResolver.update(uri, v, null, null)
                } else {
                    ctx.contentResolver.delete(uri, null, null)
                }
            } catch (_: Throwable) {
            }
        } else if (!keep) {
            outFile?.delete()
        }
        if (!keep) outputUri = null
    }

    // ------------------------------------------------------------------ video

    private fun videoLoop() {
        val enc = vEnc ?: return
        val info = MediaCodec.BufferInfo()
        var eos = false
        while (!eos) {
            val idx = try {
                enc.dequeueOutputBuffer(info, 10_000)
            } catch (_: Exception) {
                break
            }
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {}
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    videoTrack = muxer?.addTrack(enc.outputFormat) ?: -1
                }
                idx >= 0 -> {
                    val buf = enc.getOutputBuffer(idx)
                    val isConfig = (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0
                    if (buf != null && info.size > 0 && !isConfig && videoTrack >= 0) {
                        val key = (info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME) != 0
                        var write = !paused
                        if (write && needKey) {
                            if (key) {
                                // close the time gap left by the pause so playback doesn't freeze
                                val gap = (info.presentationTimeUs - lastPts) - frameDurUs
                                if (gap > 0) pauseOffset += gap
                                needKey = false
                            } else {
                                write = false
                            }
                        }
                        if (write) {
                            if (!baseSet) {
                                basePts = info.presentationTimeUs
                                baseSet = true
                            }
                            lastPts = info.presentationTimeUs
                            val out = MediaCodec.BufferInfo()
                            out.set(
                                info.offset, info.size,
                                (info.presentationTimeUs - basePts - pauseOffset).coerceAtLeast(0), info.flags
                            )
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            muxer?.write(videoTrack, buf, out)
                        }
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) eos = true
                }
            }
        }
    }

    // ------------------------------------------------------------------ audio

    private fun setupAudio() {
        val rate = sampleRate
        if (wantInternal && Build.VERSION.SDK_INT >= 29) {
            try {
                val cfg = AudioPlaybackCaptureConfiguration.Builder(projection)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
                val af = AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(rate)
                    .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                    .build()
                val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord.Builder()
                    .setAudioPlaybackCaptureConfig(cfg)
                    .setAudioFormat(af)
                    .setBufferSizeInBytes(min * 4)
                    .build()
                if (rec.state == AudioRecord.STATE_INITIALIZED) intRec = rec else rec.release()
            } catch (_: Throwable) {
            }
        }
        if (wantMic) {
            try {
                val min = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
                val rec = AudioRecord(
                    MediaRecorder.AudioSource.MIC, rate,
                    AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, min * 4
                )
                if (rec.state == AudioRecord.STATE_INITIALIZED) micRec = rec else rec.release()
            } catch (_: Throwable) {
            }
        }

        if (intRec == null && micRec == null) {
            audioDescription = if (wantMic || wantInternal) "audio unavailable" else "no audio"
            return
        }
        audioDescription = listOfNotNull(
            if (intRec != null) "game audio" else null,
            if (micRec != null) "mic" else null
        ).joinToString(" + ")

        val f = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, rate, 2).apply {
            setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            setInteger(MediaFormat.KEY_BIT_RATE, 128_000)
            setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
        }
        val enc = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
        enc.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        enc.start()
        aEnc = enc
    }

    private fun audioLoop() {
        val enc = aEnc ?: return
        val frames = 1024
        val stereo = ShortArray(frames * 2)
        val mono = ShortArray(frames)
        val mixBytes = ByteArray(frames * 4)
        val mixShorts = ByteBuffer.wrap(mixBytes).order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
        val info = MediaCodec.BufferInfo()
        var samples = 0L

        try { intRec?.startRecording() } catch (_: Throwable) { intRec = null }
        try { micRec?.startRecording() } catch (_: Throwable) { micRec = null }
        val both = intRec != null && micRec != null
        val gain = if (both) 0.75f else 1f

        while (running) {
            var haveInt = false
            var haveMic = false
            intRec?.let {
                val n = it.read(stereo, 0, stereo.size, AudioRecord.READ_BLOCKING)
                if (n > 0) {
                    haveInt = true
                    for (i in n until stereo.size) stereo[i] = 0
                }
            }
            micRec?.let {
                val n = it.read(mono, 0, mono.size, AudioRecord.READ_BLOCKING)
                if (n > 0) {
                    haveMic = true
                    for (i in n until mono.size) mono[i] = 0
                }
            }
            if (!haveInt && !haveMic) continue
            if (paused) continue   // keep draining the microphone, but don't record while paused

            mixShorts.clear()
            for (i in 0 until frames) {
                val m = if (haveMic) mono[i] * gain else 0f
                val l = (if (haveInt) stereo[i * 2] * gain else 0f) + m
                val r = (if (haveInt) stereo[i * 2 + 1] * gain else 0f) + m
                mixShorts.put(l.toInt().coerceIn(-32768, 32767).toShort())
                mixShorts.put(r.toInt().coerceIn(-32768, 32767).toShort())
            }

            val pts = samples * 1_000_000L / sampleRate
            samples += frames
            val inIdx = try { enc.dequeueInputBuffer(10_000) } catch (_: Exception) { -1 }
            if (inIdx >= 0) {
                val ib = enc.getInputBuffer(inIdx)
                if (ib != null) {
                    ib.clear()
                    ib.put(mixBytes, 0, mixBytes.size)
                    enc.queueInputBuffer(inIdx, 0, mixBytes.size, pts, 0)
                }
            }
            drainAudio(enc, info, false)
        }

        // end of stream
        val pts = samples * 1_000_000L / sampleRate
        val inIdx = try { enc.dequeueInputBuffer(10_000) } catch (_: Exception) { -1 }
        if (inIdx >= 0) {
            try { enc.queueInputBuffer(inIdx, 0, 0, pts, MediaCodec.BUFFER_FLAG_END_OF_STREAM) } catch (_: Exception) {}
        }
        drainAudio(enc, info, true)
        try { intRec?.stop() } catch (_: Throwable) {}
        try { micRec?.stop() } catch (_: Throwable) {}
    }

    private fun drainAudio(enc: MediaCodec, info: MediaCodec.BufferInfo, eos: Boolean) {
        var spins = 0
        while (true) {
            val idx = try {
                enc.dequeueOutputBuffer(info, if (eos) 10_000 else 0)
            } catch (_: Exception) {
                return
            }
            when {
                idx == MediaCodec.INFO_TRY_AGAIN_LATER -> {
                    if (!eos || ++spins > 200) return
                }
                idx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                    audioTrack = muxer?.addTrack(enc.outputFormat) ?: -1
                }
                idx >= 0 -> {
                    val buf = enc.getOutputBuffer(idx)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG) != 0) info.size = 0
                    if (buf != null && info.size > 0 && audioTrack >= 0) {
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        muxer?.write(audioTrack, buf, info)
                    }
                    enc.releaseOutputBuffer(idx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) return
                }
            }
        }
    }
}

package com.gr.fps

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Screen recorder service + its notifications.
 *  - "Ready" notification (while the recorder is switched on): Record / Settings
 *  - "Recording" notification: timer, Pause / Resume, Stop, Settings
 */
class RecorderService : Service() {

    companion object {
        const val ACTION_START = "com.gr.fps.REC_START"
        const val ACTION_PAUSE = "com.gr.fps.REC_PAUSE"
        const val ACTION_RESUME = "com.gr.fps.REC_RESUME"
        const val ACTION_STOP = "com.gr.fps.REC_STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_AUDIO_OK = "audio_ok"

        private const val CH_READY = "gr_rec_ready"
        private const val CH_REC = "gr_rec"
        private const val ID_READY = 10
        private const val ID_REC = 11
        private const val ID_DONE = 12

        val state = MutableStateFlow(RecState.IDLE)

        private fun channels(ctx: Context) {
            val nm = ctx.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CH_READY, "Recorder ready", NotificationManager.IMPORTANCE_LOW))
            nm.createNotificationChannel(NotificationChannel(CH_REC, "Recording", NotificationManager.IMPORTANCE_LOW))
        }

        private fun canNotify(ctx: Context) =
            Build.VERSION.SDK_INT < 33 ||
                ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

        private fun action(ctx: Context, icon: Int, title: String, pi: PendingIntent) =
            Notification.Action.Builder(Icon.createWithResource(ctx, icon), title, pi).build()

        private fun flags() = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT

        private fun openApp(ctx: Context): PendingIntent = PendingIntent.getActivity(
            ctx, 101,
            Intent(ctx, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags()
        )

        private fun serviceAction(ctx: Context, a: String, code: Int): PendingIntent = PendingIntent.getService(
            ctx, code, Intent(ctx, RecorderService::class.java).setAction(a), flags()
        )

        fun summary(ctx: Context): String {
            val audio = listOfNotNull(
                if (RecPrefs.internal(ctx)) "game audio" else null,
                if (RecPrefs.mic(ctx)) "mic" else null
            ).joinToString(" + ").ifEmpty { "no audio" }
            return "${RecPrefs.res(ctx)}p • ${RecPrefs.fps(ctx)} fps • $audio"
        }

        fun showReady(ctx: Context) {
            if (!canNotify(ctx)) return
            channels(ctx)
            val record = PendingIntent.getActivity(
                ctx, 100,
                Intent(ctx, CaptureRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
                flags()
            )
            val n = Notification.Builder(ctx, CH_READY)
                .setSmallIcon(R.drawable.ic_rec)
                .setContentTitle("GRFlow Recorder")
                .setContentText("Ready • " + summary(ctx))
                .setOngoing(true)
                .setShowWhen(false)
                .setContentIntent(openApp(ctx))
                .addAction(action(ctx, R.drawable.ic_rec, "● Record", record))
                .addAction(action(ctx, R.drawable.ic_bolt, "Settings", openApp(ctx)))
                .build()
            ctx.getSystemService(NotificationManager::class.java).notify(ID_READY, n)
        }

        fun hideReady(ctx: Context) {
            ctx.getSystemService(NotificationManager::class.java).cancel(ID_READY)
        }

        /** Re-posts or removes the "ready" notification to match the current settings. */
        fun refreshReady(ctx: Context) {
            if (RecPrefs.enabled(ctx) && state.value == RecState.IDLE) showReady(ctx) else if (!RecPrefs.enabled(ctx)) hideReady(ctx)
        }
    }

    private val main = Handler(Looper.getMainLooper())
    private var engine: ScreenRecorderEngine? = null
    private var projection: MediaProjection? = null
    private var stopping = false
    private var baseElapsed = 0L
    private var segStart = 0L
    private var infoLine = ""

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_PAUSE -> pause()
            ACTION_RESUME -> resume()
            ACTION_STOP -> stopRecording()
            else -> if (engine == null) stopSelf()
        }
        return START_NOT_STICKY
    }

    // ------------------------------------------------------------------ start

    private fun handleStart(intent: Intent) {
        channels(this)
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        val audioOk = intent.getBooleanExtra(EXTRA_AUDIO_OK, false)

        val wantMic = RecPrefs.mic(this) && audioOk
        val wantInternal = RecPrefs.internal(this) && audioOk && Build.VERSION.SDK_INT >= 29
        infoLine = "starting…"

        // Must go to the foreground first, before anything else
        var type = ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        var micType = false
        if (wantMic && Build.VERSION.SDK_INT >= 30 &&
            checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
        ) {
            type = type or ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
            micType = true
        }
        try {
            ServiceCompat.startForeground(this, ID_REC, recNotification(false), type)
        } catch (e: Exception) {
            micType = false
            try {
                ServiceCompat.startForeground(
                    this, ID_REC, recNotification(false), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
                )
            } catch (e2: Exception) {
                fail("Couldn't start the recorder: ${e2.message}")
                return
            }
        }

        if (engine != null) return   // already recording
        if (data == null) {
            fail("Screen recording wasn't allowed")
            return
        }
        hideReady(this)

        val mp: MediaProjection? = try {
            getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (mp == null) {
            fail("Couldn't start screen capture")
            return
        }
        projection = mp

        val caps = RecCaps.probe(this)
        val landscape = RecPrefs.landscape(this)
        val res = RecPrefs.res(this).coerceAtMost(caps.nativeShort)
        var fps = RecPrefs.fps(this)
        if (!caps.fpsOk(res, fps, landscape)) fps = caps.maxFps(res, landscape)
        val (w, h) = caps.dims(res, landscape)
        val bitrate = caps.bitrate(w, h, fps)
        val dpi = resources.displayMetrics.densityDpi

        val eng = ScreenRecorderEngine(
            this, mp, w, h, dpi, fps, bitrate, caps.encoderName,
            wantMic && (micType || Build.VERSION.SDK_INT < 30),
            wantInternal
        ) { main.post { stopRecording() } }
        engine = eng

        Thread {
            try {
                eng.start()
                main.post {
                    baseElapsed = 0L
                    segStart = System.currentTimeMillis()
                    infoLine = "${h.coerceAtMost(w)}p • $fps fps • ${eng.audioDescription}"
                    state.value = RecState.RECORDING
                    updateNotification()
                    if (eng.audioDescription == "audio unavailable") {
                        toast("Audio isn't available on this phone/app, recording video only")
                    }
                }
            } catch (t: Throwable) {
                main.post { fail("Couldn't start recording: ${t.message ?: t.javaClass.simpleName}") }
            }
        }.start()
    }

    // ------------------------------------------------------------------ pause / resume / stop

    private fun pause() {
        val e = engine ?: return
        if (state.value != RecState.RECORDING) return
        e.pause()
        baseElapsed += System.currentTimeMillis() - segStart
        state.value = RecState.PAUSED
        updateNotification()
    }

    private fun resume() {
        val e = engine ?: return
        if (state.value != RecState.PAUSED) return
        e.resume()
        segStart = System.currentTimeMillis()
        state.value = RecState.RECORDING
        updateNotification()
    }

    private fun stopRecording() {
        val e = engine
        if (e == null) {
            finishService()
            return
        }
        if (stopping) return
        stopping = true
        engine = null
        Thread {
            val uri = try {
                e.stop()
            } catch (_: Throwable) {
                null
            }
            main.post {
                if (uri != null) saved(uri) else toast("Nothing was recorded")
                finishService()
            }
        }.start()
    }

    private fun finishService() {
        state.value = RecState.IDLE
        stopping = false
        engine = null
        projection = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        refreshReady(this)
        stopSelf()
    }

    private fun fail(msg: String) {
        toast(msg)
        try {
            engine?.stop()
        } catch (_: Throwable) {
        }
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        finishService()
    }

    // ------------------------------------------------------------------ notifications

    private fun recNotification(paused: Boolean): Notification {
        val elapsed = baseElapsed + if (state.value == RecState.RECORDING) System.currentTimeMillis() - segStart else 0L
        val b = Notification.Builder(this, CH_REC)
            .setSmallIcon(R.drawable.ic_rec)
            .setContentTitle(if (paused) "⏸ Recording paused" else "● Recording")
            .setContentText(infoLine)
            .setOngoing(true)
            .setContentIntent(openApp(this))
        if (paused) {
            b.setShowWhen(false)
            b.addAction(action(this, R.drawable.ic_play, "Resume", serviceAction(this, ACTION_RESUME, 202)))
        } else {
            b.setUsesChronometer(true).setWhen(System.currentTimeMillis() - elapsed)
            b.addAction(action(this, R.drawable.ic_pause, "Pause", serviceAction(this, ACTION_PAUSE, 201)))
        }
        b.addAction(action(this, R.drawable.ic_stop, "Stop", serviceAction(this, ACTION_STOP, 203)))
        b.addAction(action(this, R.drawable.ic_bolt, "Settings", openApp(this)))
        return b.build()
    }

    private fun updateNotification() {
        getSystemService(NotificationManager::class.java)
            .notify(ID_REC, recNotification(state.value == RecState.PAUSED))
    }

    private fun saved(uri: Uri) {
        if (!canNotify(this)) {
            toast("Video saved in Movies/GRFlow")
            return
        }
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, "video/mp4")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(this, 102, view, flags())
        val n = Notification.Builder(this, CH_REC)
            .setSmallIcon(R.drawable.ic_rec)
            .setContentTitle("Recording saved")
            .setContentText("Movies/GRFlow • tap to watch")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ID_DONE, n)
    }

    private fun toast(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
    }

    override fun onDestroy() {
        val e = engine
        engine = null
        if (e != null) {
            Thread {
                try { e.stop() } catch (_: Throwable) {}
            }.start()
        }
        state.value = RecState.IDLE
        super.onDestroy()
    }
}

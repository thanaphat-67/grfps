package com.gr.fps

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_RUNNING, NO_PERMISSION, CONNECTING, READY }

/**
 * Runs shell commands through Shizuku.
 * v1.2: no longer uses a Shizuku "user service" (it never answered on some phones);
 * commands go straight through Shizuku's remote process instead.
 */
object ShizukuHelper {

    private const val REQUEST_CODE = 1001
    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    val state = MutableStateFlow(ShizukuState.NOT_RUNNING)

    /** Text shown under the Shizuku row (kept for diagnostics). */
    val detail = MutableStateFlow("")

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener { refresh() }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    fun init() {
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refresh()
    }

    fun destroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
    }

    fun refresh() {
        state.value = when {
            !Shizuku.pingBinder() -> ShizukuState.NOT_RUNNING
            Shizuku.isPreV11() ||
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> ShizukuState.NO_PERMISSION
            else -> ShizukuState.READY
        }
    }

    fun retry() {
        detail.value = ""
        refresh()
    }

    /** Ask for Shizuku permission, or open the Shizuku app if the user previously chose "deny". */
    fun requestPermission(ctx: Context) {
        if (!Shizuku.pingBinder()) {
            openShizuku(ctx)
            return
        }
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            openShizuku(ctx)
        } else {
            Shizuku.requestPermission(REQUEST_CODE)
        }
    }

    fun openShizuku(ctx: Context) {
        val launch = ctx.packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
        val intent = launch ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        if (state.value != ShizukuState.READY) return@withContext "ERR: Shizuku not ready"
        try {
            val m = Shizuku::class.java.getDeclaredMethod(
                "newProcess",
                Array<String>::class.java,
                Array<String>::class.java,
                String::class.java
            )
            m.isAccessible = true
            val p = m.invoke(null, arrayOf("sh", "-c", cmd), null, null) as Process
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim()
        } catch (e: Throwable) {
            val msg = e.cause?.message ?: e.message
            detail.value = "Shell error: $msg"
            "ERR: $msg"
        }
    }
}

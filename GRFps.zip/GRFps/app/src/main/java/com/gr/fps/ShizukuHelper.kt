package com.gr.fps

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.net.Uri
import android.os.IBinder
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class ShizukuState { NOT_RUNNING, NO_PERMISSION, CONNECTING, READY }

object ShizukuHelper {

    private const val REQUEST_CODE = 1001
    private const val SHIZUKU_PKG = "moe.shizuku.privileged.api"

    val state = MutableStateFlow(ShizukuState.NOT_RUNNING)

    private var shell: IShellService? = null
    private var binding = false

    private val args by lazy {
        Shizuku.UserServiceArgs(ComponentName(BuildConfig.APPLICATION_ID, ShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("shell")
            .debuggable(BuildConfig.DEBUG)
            .version(BuildConfig.VERSION_CODE)
    }

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, binder: IBinder?) {
            binding = false
            shell = if (binder != null && binder.pingBinder()) IShellService.Stub.asInterface(binder) else null
            refresh()
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            shell = null
            binding = false
            refresh()
        }
    }

    private val binderReceived = Shizuku.OnBinderReceivedListener { refresh() }
    private val binderDead = Shizuku.OnBinderDeadListener {
        shell = null
        binding = false
        refresh()
    }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ -> refresh() }

    fun init() {
        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
        refresh()
    }

    fun destroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
    }

    fun refresh() {
        state.value = when {
            !Shizuku.pingBinder() -> ShizukuState.NOT_RUNNING
            Shizuku.isPreV11() ||
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED -> ShizukuState.NO_PERMISSION
            shell != null -> ShizukuState.READY
            else -> {
                if (!binding) {
                    binding = true
                    try {
                        Shizuku.bindUserService(args, connection)
                    } catch (e: Throwable) {
                        binding = false
                    }
                }
                ShizukuState.CONNECTING
            }
        }
    }

    /** Ask for Shizuku permission, or open the Shizuku app if the user previously chose "deny". */
    fun requestPermission(ctx: Context) {
        if (!Shizuku.pingBinder()) {
            openShizuku(ctx)
            return
        }
        if (Shizuku.shouldShowRequestPermissionRationale()) {
            openShizuku(ctx) // permanently denied -> allow it manually inside Shizuku
        } else {
            Shizuku.requestPermission(REQUEST_CODE)
        }
    }

    fun openShizuku(ctx: Context) {
        val launch = ctx.packageManager.getLaunchIntentForPackage(SHIZUKU_PKG)
        val intent = launch ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/RikkaApps/Shizuku/releases"))
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(intent)
    }

    suspend fun exec(cmd: String): String = withContext(Dispatchers.IO) {
        shell?.exec(cmd) ?: "ERR: Shizuku not ready"
    }
}

package com.gr.fps

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.gr.fps.ui.GrFpsTheme
import com.gr.fps.ui.HomeScreen

class MainActivity : ComponentActivity() {

    private val vm: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        ShizukuHelper.init()
        setContent {
            GrFpsTheme {
                HomeScreen(vm)
            }
        }
    }

    override fun onDestroy() {
        ShizukuHelper.destroy()
        super.onDestroy()
    }
}

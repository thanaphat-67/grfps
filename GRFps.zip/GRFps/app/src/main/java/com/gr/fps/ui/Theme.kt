package com.gr.fps.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val Bg = Color(0xFF040906)
val CardTop = Color(0xFF10201A)
val CardBottom = Color(0xFF08110D)
val Neon = Color(0xFF39FF14)
val NeonDim = Color(0xFF1FBF3A)
val TextMain = Color(0xFFF2FFF5)
val TextDim = Color(0xFF8FA597)
val Divider = Color(0xFF1C2B22)

private val scheme = darkColorScheme(
    primary = Neon,
    onPrimary = Color.Black,
    secondary = NeonDim,
    background = Bg,
    surface = CardTop,
    onSurface = TextMain,
    onBackground = TextMain
)

@Composable
fun GrFpsTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}

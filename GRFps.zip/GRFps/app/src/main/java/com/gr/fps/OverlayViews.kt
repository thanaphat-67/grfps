package com.gr.fps

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import android.widget.TextView
import kotlin.math.min

fun dpOf(ctx: Context, v: Float): Float = v * ctx.resources.displayMetrics.density

fun overlayText(ctx: Context, mono: Boolean = false): TextView = TextView(ctx).apply {
    setTextColor(0xFF39FF14.toInt())
    typeface = if (mono) Typeface.MONOSPACE else Typeface.DEFAULT_BOLD
    setTypeface(typeface, Typeface.BOLD)
    includeFontPadding = false
}

/** Bar graph of the last frame times. Green = steady, yellow = slow, red = stutter. */
class FrameGraphView(ctx: Context) : View(ctx) {
    private val bars = 60
    private val paint = Paint()
    private var data: List<Float> = emptyList()
    private var refMs = 16.7f
    var scale = 1f
        set(v) {
            field = v
            requestLayout()
            invalidate()
        }

    fun setData(frames: List<Float>, avgMs: Float) {
        data = frames
        refMs = if (avgMs > 0f) avgMs else 16.7f
        invalidate()
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        setMeasuredDimension(
            (dpOf(context, 3f) * bars * scale).toInt(),
            (dpOf(context, 40f) * scale).toInt()
        )
    }

    override fun onDraw(canvas: Canvas) {
        val barW = width / bars.toFloat()
        val maxMs = 50f
        val offset = bars - data.size
        data.forEachIndexed { i, ms ->
            val h = min(ms, maxMs) / maxMs * height
            paint.color = when {
                ms <= refMs * 1.25f -> 0xFF39FF14.toInt()
                ms <= refMs * 2f -> 0xFFFFEB3B.toInt()
                else -> 0xFFFF5252.toInt()
            }
            val x = (offset + i) * barW
            canvas.drawRect(x, height - h, x + barW - 1f, height.toFloat(), paint)
        }
    }
}

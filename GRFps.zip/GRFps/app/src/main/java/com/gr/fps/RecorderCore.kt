package com.gr.fps

import android.content.Context
import android.graphics.Point
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaMuxer
import android.os.Build
import android.view.WindowManager
import java.nio.ByteBuffer
import kotlin.math.min
import kotlin.math.roundToInt

enum class RecState { IDLE, RECORDING, PAUSED }

/** Recorder settings, shared by the app screen, the notification and the service. */
object RecPrefs {
    private fun p(c: Context) = c.getSharedPreferences("gr_rec", Context.MODE_PRIVATE)

    fun res(c: Context) = p(c).getInt("res", 720)
    fun fps(c: Context) = p(c).getInt("fps", 60)
    fun mic(c: Context) = p(c).getBoolean("mic", false)
    fun internal(c: Context) = p(c).getBoolean("internal", true)
    fun landscape(c: Context) = p(c).getBoolean("landscape", true)
    fun enabled(c: Context) = p(c).getBoolean("enabled", false)

    fun setRes(c: Context, v: Int) = p(c).edit().putInt("res", v).apply()
    fun setFps(c: Context, v: Int) = p(c).edit().putInt("fps", v).apply()
    fun setMic(c: Context, v: Boolean) = p(c).edit().putBoolean("mic", v).apply()
    fun setInternal(c: Context, v: Boolean) = p(c).edit().putBoolean("internal", v).apply()
    fun setLandscape(c: Context, v: Boolean) = p(c).edit().putBoolean("landscape", v).apply()
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("enabled", v).apply()
}

/** What the phone's hardware video encoder can really do. */
class RecCaps(val nativeShort: Int, val nativeLong: Int, private val info: MediaCodecInfo?) {

    private val vc: MediaCodecInfo.VideoCapabilities? = try {
        info?.getCapabilitiesForType("video/avc")?.videoCapabilities
    } catch (_: Exception) {
        null
    }

    val encoderName: String? get() = info?.name

    /** Output size for a given short edge. Never larger than the real screen. */
    fun dims(res: Int, landscape: Boolean): Pair<Int, Int> {
        val nShort = nativeShort.coerceAtLeast(1)
        val shortSide = min(res, nShort)
        val r = shortSide.toFloat() / nShort
        val longSide = (nativeLong * r).roundToInt()
        val wa = (vc?.widthAlignment ?: 2).coerceAtLeast(2)
        val ha = (vc?.heightAlignment ?: 2).coerceAtLeast(2)
        var w = if (landscape) longSide else shortSide
        var h = if (landscape) shortSide else longSide
        w -= w % wa
        h -= h % ha
        return w to h
    }

    fun sizeOk(res: Int, landscape: Boolean): Boolean {
        val (w, h) = dims(res, landscape)
        return try {
            vc?.isSizeSupported(w, h) ?: false
        } catch (_: Exception) {
            false
        }
    }

    fun fpsOk(res: Int, fps: Int, landscape: Boolean): Boolean {
        val (w, h) = dims(res, landscape)
        return try {
            val upper = vc?.getSupportedFrameRatesFor(w, h)?.upper
            upper != null && upper + 0.5 >= fps
        } catch (_: Exception) {
            false
        }
    }

    fun maxFps(res: Int, landscape: Boolean): Int =
        listOf(120, 90, 60, 30).firstOrNull { fpsOk(res, it, landscape) } ?: 30

    fun bitrate(w: Int, h: Int, fps: Int): Int {
        val bpp = when {
            fps >= 90 -> 0.07
            fps >= 60 -> 0.085
            else -> 0.11
        }
        var b = (w.toLong() * h * fps * bpp).toLong().coerceIn(1_500_000L, 80_000_000L).toInt()
        vc?.bitrateRange?.let { b = it.clamp(b) }
        return b
    }

    companion object {
        fun probe(ctx: Context): RecCaps {
            val wm = ctx.getSystemService(WindowManager::class.java)
            val w: Int
            val h: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                w = b.width()
                h = b.height()
            } else {
                val p = Point()
                @Suppress("DEPRECATION")
                wm.defaultDisplay.getRealSize(p)
                w = p.x
                h = p.y
            }

            val all = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { ci ->
                ci.isEncoder && ci.supportedTypes.any { it.equals("video/avc", ignoreCase = true) }
            }
            val hw = all.firstOrNull { ci ->
                Build.VERSION.SDK_INT >= 29 && ci.isHardwareAccelerated && !ci.isSoftwareOnly
            } ?: all.firstOrNull { ci ->
                !ci.name.startsWith("OMX.google") && !ci.name.startsWith("c2.android")
            } ?: all.firstOrNull()
            return RecCaps(min(w, h), maxOf(w, h), hw)
        }
    }
}

/** MediaMuxer wrapper: thread-safe, waits until every track is known before starting. */
class SyncMuxer(private val muxer: MediaMuxer, private val expectedTracks: Int) {
    private class Pending(val track: Int, val data: ByteArray, val info: MediaCodec.BufferInfo)

    private var added = 0
    private var started = false
    private var samples = 0
    private val pending = ArrayList<Pending>()

    @Synchronized
    fun addTrack(format: android.media.MediaFormat): Int {
        val idx = muxer.addTrack(format)
        added++
        if (added == expectedTracks) {
            muxer.start()
            started = true
            for (p in pending) {
                muxer.writeSampleData(p.track, ByteBuffer.wrap(p.data), p.info)
                samples++
            }
            pending.clear()
        }
        return idx
    }

    @Synchronized
    fun write(track: Int, buf: ByteBuffer, info: MediaCodec.BufferInfo) {
        if (started) {
            muxer.writeSampleData(track, buf, info)
            samples++
        } else {
            val bytes = ByteArray(info.size)
            buf.position(info.offset)
            buf.get(bytes)
            val copy = MediaCodec.BufferInfo()
            copy.set(0, info.size, info.presentationTimeUs, info.flags)
            pending.add(Pending(track, bytes, copy))
        }
    }

    /** Closes the file. Returns how many samples were written. */
    @Synchronized
    fun finish(): Int {
        if (started) {
            try {
                muxer.stop()
            } catch (_: Exception) {
            }
        }
        try {
            muxer.release()
        } catch (_: Exception) {
        }
        return samples
    }
}

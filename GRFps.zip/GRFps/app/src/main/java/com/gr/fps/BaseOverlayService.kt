package com.gr.fps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

fun startOverlay(ctx: Context, cls: Class<*>) {
    ContextCompat.startForegroundService(ctx, Intent(ctx, cls))
}

fun stopOverlay(ctx: Context, cls: Class<*>) {
    ctx.stopService(Intent(ctx, cls))
}

/** Floating box drawn on top of any app. Drag it to move it. Subclasses supply the content. */
abstract class BaseOverlayService : Service() {

    protected abstract val notifId: Int
    protected abstract val channelId: String
    protected abstract val title: String
    protected abstract val scaleKey: String
    protected abstract val stopAction: String
    protected abstract val startY: Int
    protected open val tickMs: Long = 1000L

    protected abstract fun createContent(ctx: Context): View
    protected abstract fun applyScale(scale: Float)
    protected abstract suspend fun onTick()
    protected abstract fun setRunning(v: Boolean)
    protected open fun onStarted() {}
    protected open fun onStopped() {}

    protected val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var wm: WindowManager? = null
    private var root: View? = null
    private var prefListener: SharedPreferences.OnSharedPreferenceChangeListener? = null
    private val main = Handler(Looper.getMainLooper())

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == stopAction) {
            stopSelf()
            return START_NOT_STICKY
        }
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, notifId, buildNotification(), type)
        if (root == null) addOverlay()
        if (job == null) {
            onStarted()
            job = scope.launch {
                while (isActive) {
                    try {
                        onTick()
                    } catch (_: Throwable) {
                    }
                    delay(tickMs)
                }
            }
        }
        setRunning(true)
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val manager = getSystemService(WindowManager::class.java)
        val v = createContent(this)
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = startY
        }

        var startX = 0
        var startPosY = 0
        var touchX = 0f
        var touchY = 0f
        v.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x
                    startPosY = lp.y
                    touchX = e.rawX
                    touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startPosY + (e.rawY - touchY).toInt()
                    manager.updateViewLayout(v, lp)
                    true
                }
                else -> false
            }
        }
        manager.addView(v, lp)
        wm = manager
        root = v
        applyScale(UiPrefs.scale(this, scaleKey))

        val listener = SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "scale_$scaleKey") {
                main.post { applyScale(UiPrefs.scale(this, scaleKey)) }
            }
        }
        prefListener = listener
        UiPrefs.prefs(this).registerOnSharedPreferenceChangeListener(listener)
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(channelId, title, NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, notifId,
            Intent(this, this::class.java).setAction(stopAction),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopBtn = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_bolt), "Stop", stopIntent
        ).build()
        return Notification.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle(title)
            .setContentText("Tap Stop to hide it")
            .addAction(stopBtn)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        prefListener?.let { UiPrefs.prefs(this).unregisterOnSharedPreferenceChangeListener(it) }
        try {
            root?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        root = null
        onStopped()
        setRunning(false)
        super.onDestroy()
    }
}

package com.gr.fps

import android.content.Context

/**
 * Remembers the phone's ORIGINAL values the first time we change anything,
 * so Reset can put everything back exactly as it was.
 */
object BackupStore {
    private fun prefs(c: Context) = c.getSharedPreferences("gr_backup", Context.MODE_PRIVATE)

    fun has(c: Context) = prefs(c).getBoolean("has", false)

    fun save(c: Context, values: Map<String, String>) {
        prefs(c).edit().apply {
            values.forEach { (k, v) -> putString("s:$k", v) }
            putBoolean("has", true)
        }.apply()
    }

    fun load(c: Context): Map<String, String> =
        prefs(c).all
            .filterKeys { it.startsWith("s:") }
            .mapKeys { it.key.removePrefix("s:") }
            .mapValues { it.value as String }

    fun setFlag(c: Context, name: String) = prefs(c).edit().putBoolean("f:$name", true).apply()
    fun flag(c: Context, name: String) = prefs(c).getBoolean("f:$name", false)

    fun clear(c: Context) = prefs(c).edit().clear().apply()
}

package com.gr.fps

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

/** Temperature + bottleneck monitor: tells you what is holding your phone back. */
class ThermalOverlayService : BaseOverlayService() {

    companion object {
        val running = MutableStateFlow(false)
    }

    override val notifId = 4
    override val channelId = "gr_thermal"
    override val title = "GRFlow monitor is running"
    override val scaleKey = "thermal"
    override val stopAction = "com.gr.fps.STOP_THERMAL"
    override val startY = 520
    override val tickMs = 1000L

    private var box: LinearLayout? = null
    private var info: TextView? = null
    private var verdict: TextView? = null

    override fun createContent(ctx: Context): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xAA000000.toInt())
        }
        val a = overlayText(ctx, true)
        val b = overlayText(ctx, true)
        a.text = "CPU --"
        root.addView(a)
        root.addView(b)
        box = root
        info = a
        verdict = b
        return root
    }

    override fun applyScale(scale: Float) {
        val r = box ?: return
        val p = dpOf(this, 8f * scale).toInt()
        r.setPadding(p, p, p, p)
        info?.textSize = 12f * scale
        verdict?.textSize = 13f * scale
        r.requestLayout()
    }

    override fun onStopped() = SysProbe.reset()
    override fun setRunning(v: Boolean) {
        running.value = v
    }

    private fun temp(v: Float?) = v?.let { "${it.roundToInt()}°" } ?: "--"

    override suspend fun onTick() {
        val st = SysProbe.sample(this)
        val sb = StringBuilder()
        sb.append("CPU ").append(st.cpuTotal?.let { "$it%" } ?: "--")
        st.cpuMaxCore?.let { sb.append("  top core $it%") }
        sb.append('\n')
        sb.append("CLOCK ")
        sb.append(st.curMhz?.let { "$it MHz" } ?: "--")
        st.clockPct?.let { sb.append(" ($it% of max)") }
        sb.append('\n')
        sb.append("GPU ").append(st.gpu?.let { "$it%" } ?: "n/a").append('\n')
        sb.append("TEMP CPU ").append(temp(st.cpuTemp))
        sb.append("  GPU ").append(temp(st.gpuTemp))
        sb.append("  BAT ").append(temp(st.batTemp)).append('\n')
        sb.append("RAM ").append(st.ramFreeMb).append(" MB free")

        val color = when (st.level) {
            2 -> 0xFFFF5252.toInt()
            1 -> 0xFFFFEB3B.toInt()
            else -> 0xFF39FF14.toInt()
        }
        withContext(Dispatchers.Main) {
            info?.text = sb.toString()
            verdict?.text = "▶ " + st.verdict
            verdict?.setTextColor(color)
        }
    }
}

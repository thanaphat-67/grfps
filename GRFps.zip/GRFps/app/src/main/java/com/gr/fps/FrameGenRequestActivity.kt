package com.gr.fps

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/** Invisible helper: checks the requirements, then shows Android's screen-capture popup for frame generation. */
class FrameGenRequestActivity : ComponentActivity() {

    private val launcher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                ContextCompat.startForegroundService(
                    this,
                    Intent(this, FrameGenService::class.java)
                        .setAction(FrameGenService.ACTION_START)
                        .putExtra(FrameGenService.EXTRA_CODE, r.resultCode)
                        .putExtra(FrameGenService.EXTRA_DATA, data)
                )
            }
            finish()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (FrameGenService.running.value) {
            finish()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow \"Display over other apps\" first", Toast.LENGTH_LONG).show()
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            finish()
            return
        }
        if (ShizukuHelper.state.value != ShizukuState.READY) {
            Toast.makeText(this, "Connect Shizuku first", Toast.LENGTH_LONG).show()
            finish()
            return
        }
        Toast.makeText(this, "Choose \"A single app\" and pick your game", Toast.LENGTH_LONG).show()
        launcher.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}

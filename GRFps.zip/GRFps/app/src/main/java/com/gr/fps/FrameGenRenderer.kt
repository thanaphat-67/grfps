package com.gr.fps

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLContext
import android.opengl.EGLDisplay
import android.opengl.EGLSurface
import android.opengl.GLES11Ext
import android.opengl.GLES30
import android.opengl.Matrix
import android.view.Surface
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import kotlin.math.ceil

/**
 * Frame generation on the GPU.
 *
 *  captured screen frames --> [input surface] --> OES texture --> 2 full-size textures (previous / current)
 *  quality 0 : the in-between frame is a 50/50 blend
 *  quality 1/2: block matching on a 1/8-size luma image finds how things moved between the two frames,
 *               then the in-between frame is built by moving pixels half-way (falls back to the plain frame
 *               where the match is unreliable)
 *  Output per captured frame: [in-between frame] then [real frame], each on its own vsync.
 */
class FrameGenRenderer(
    private val outSurface: Surface,
    private var width: Int,
    private var height: Int,
    private val quality: Int,
    private val vsyncMs: Float,
    private val onStats: (src: Int, out: Int, delayMs: Int) -> Unit,
    private val onError: (String) -> Unit
) {
    @Volatile
    var inputSurface: Surface? = null
        private set

    @Volatile
    private var running = false

    @Volatile
    private var failed: String? = null

    private val ready = CountDownLatch(1)
    private val lock = Object()
    private var pending = 0

    @Volatile
    private var wantW = width

    @Volatile
    private var wantH = height

    private var thread: Thread? = null

    fun start() {
        running = true
        thread = Thread({ runLoop() }, "GRFrameGen").also { it.start() }
    }

    /** Waits until the GL side is ready. False if it couldn't start. */
    fun awaitReady(): Boolean = ready.await(4, TimeUnit.SECONDS) && failed == null && inputSurface != null

    fun error(): String? = failed

    fun resize(w: Int, h: Int) {
        wantW = w
        wantH = h
        synchronized(lock) { lock.notifyAll() }
    }

    fun stop() {
        running = false
        synchronized(lock) { lock.notifyAll() }
        try {
            thread?.join(1500)
        } catch (_: Throwable) {
        }
    }

    // ------------------------------------------------------------------ GL objects

    private class Target(val tex: Int, val fbo: Int, val w: Int, val h: Int)

    private var dpy: EGLDisplay = EGL14.EGL_NO_DISPLAY
    private var ctx: EGLContext = EGL14.EGL_NO_CONTEXT
    private var surf: EGLSurface = EGL14.EGL_NO_SURFACE
    private var outW = 0
    private var outH = 0

    private var oesTex = 0
    private var st: SurfaceTexture? = null

    private var progOes = 0
    private var progCopy = 0
    private var progLuma = 0
    private var progMe = 0
    private var progInterp = 0

    private var full = arrayOfNulls<Target>(2)
    private var luma = arrayOfNulls<Target>(2)
    private var mv: Target? = null
    private var cur = 0
    private var lcur = 0

    private val quad: FloatBuffer = ByteBuffer.allocateDirect(8 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f, -1f, 1f, -1f, -1f, 1f, 1f, 1f)); position(0)
    }
    private val ident = FloatArray(16).also { Matrix.setIdentityM(it, 0) }
    private val texMat = FloatArray(16)

    private val vs = """#version 300 es
layout(location=0) in vec2 aPos;
uniform mat4 uTex;
out vec2 vUv;
void main(){
  vec2 uv = aPos*0.5+0.5;
  vUv = (uTex*vec4(uv,0.0,1.0)).xy;
  gl_Position = vec4(aPos,0.0,1.0);
}"""

    private val fsOes = """#version 300 es
#extension GL_OES_EGL_image_external_essl3 : require
precision mediump float;
uniform samplerExternalOES uTexture;
in vec2 vUv;
out vec4 o;
void main(){ o = texture(uTexture, vUv); }"""

    private val fsCopy = """#version 300 es
precision mediump float;
uniform sampler2D uTexture;
in vec2 vUv;
out vec4 o;
void main(){ o = texture(uTexture, vUv); }"""

    private val fsLuma = """#version 300 es
precision mediump float;
uniform sampler2D uTexture;
uniform vec2 uTexel;
in vec2 vUv;
out vec4 o;
float l(vec2 uv){ return dot(texture(uTexture, uv).rgb, vec3(0.299,0.587,0.114)); }
void main(){
  vec2 d = uTexel*2.0;
  float v = (l(vUv+vec2(-d.x,-d.y)) + l(vUv+vec2(d.x,-d.y)) + l(vUv+vec2(-d.x,d.y)) + l(vUv+d))*0.25;
  o = vec4(v,v,v,1.0);
}"""

    private val fsMe = """#version 300 es
precision highp float;
uniform sampler2D uPrev;
uniform sampler2D uCurr;
uniform vec2 uTexel;
uniform int uR;
in vec2 vUv;
out vec4 o;
void main(){
  float best = 1e9;
  ivec2 bv = ivec2(0);
  for (int y=-uR; y<=uR; y++) {
    for (int x=-uR; x<=uR; x++) {
      vec2 v = vec2(float(x), float(y))*uTexel;
      float sad = 0.0;
      for (int j=-1; j<=1; j++) {
        for (int i=-1; i<=1; i++) {
          vec2 q = vec2(float(i), float(j))*uTexel;
          sad += abs(texture(uPrev, vUv - v + q).r - texture(uCurr, vUv + v + q).r);
        }
      }
      sad += 0.012*float(abs(x)+abs(y));
      if (sad < best) { best = sad; bv = ivec2(x,y); }
    }
  }
  float r = float(uR);
  float conf = 1.0 - smoothstep(0.18, 0.9, best);
  o = vec4((float(bv.x)+r)/(2.0*r), (float(bv.y)+r)/(2.0*r), conf, 1.0);
}"""

    private val fsInterp = """#version 300 es
precision highp float;
uniform sampler2D uPrev;
uniform sampler2D uCurr;
uniform sampler2D uMv;
uniform vec2 uTexelLow;
uniform float uR;
uniform int uMode;
in vec2 vUv;
out vec4 o;
void main(){
  vec4 a = texture(uPrev, vUv);
  vec4 b = texture(uCurr, vUv);
  if (uMode == 0) { o = mix(a, b, 0.5); return; }
  vec4 m = texture(uMv, vUv);
  vec2 v = (m.rg*2.0 - 1.0)*uR*uTexelLow;
  vec4 pa = texture(uPrev, vUv - v);
  vec4 pb = texture(uCurr, vUv + v);
  float d = length(pa.rgb - pb.rgb);
  float ok = m.b*(1.0 - smoothstep(0.15, 0.45, d));
  o = mix(b, mix(pa, pb, 0.5), ok);
}"""

    private fun compile(type: Int, src: String): Int {
        val s = GLES30.glCreateShader(type)
        GLES30.glShaderSource(s, src)
        GLES30.glCompileShader(s)
        val ok = IntArray(1)
        GLES30.glGetShaderiv(s, GLES30.GL_COMPILE_STATUS, ok, 0)
        if (ok[0] == 0) {
            val log = GLES30.glGetShaderInfoLog(s)
            GLES30.glDeleteShader(s)
            throw RuntimeException("shader: $log")
        }
        return s
    }

    private fun program(frag: String): Int {
        val v = compile(GLES30.GL_VERTEX_SHADER, vs)
        val f = compile(GLES30.GL_FRAGMENT_SHADER, frag)
        val p = GLES30.glCreateProgram()
        GLES30.glAttachShader(p, v)
        GLES30.glAttachShader(p, f)
        GLES30.glLinkProgram(p)
        val ok = IntArray(1)
        GLES30.glGetProgramiv(p, GLES30.GL_LINK_STATUS, ok, 0)
        if (ok[0] == 0) throw RuntimeException("link: " + GLES30.glGetProgramInfoLog(p))
        return p
    }

    private fun makeTarget(w: Int, h: Int, linear: Boolean = true): Target {
        val t = IntArray(1)
        GLES30.glGenTextures(1, t, 0)
        GLES30.glBindTexture(GLES30.GL_TEXTURE_2D, t[0])
        GLES30.glTexImage2D(GLES30.GL_TEXTURE_2D, 0, GLES30.GL_RGBA, w, h, 0, GLES30.GL_RGBA, GLES30.GL_UNSIGNED_BYTE, null)
        val f = if (linear) GLES30.GL_LINEAR else GLES30.GL_NEAREST
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MIN_FILTER, f)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_MAG_FILTER, f)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
        GLES30.glTexParameteri(GLES30.GL_TEXTURE_2D, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)
        val fb = IntArray(1)
        GLES30.glGenFramebuffers(1, fb, 0)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, fb[0])
        GLES30.glFramebufferTexture2D(GLES30.GL_FRAMEBUFFER, GLES30.GL_COLOR_ATTACHMENT0, GLES30.GL_TEXTURE_2D, t[0], 0)
        val st = GLES30.glCheckFramebufferStatus(GLES30.GL_FRAMEBUFFER)
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, 0)
        if (st != GLES30.GL_FRAMEBUFFER_COMPLETE) throw RuntimeException("framebuffer $st")
        return Target(t[0], fb[0], w, h)
    }

    private fun freeTarget(t: Target?) {
        if (t == null) return
        GLES30.glDeleteFramebuffers(1, intArrayOf(t.fbo), 0)
        GLES30.glDeleteTextures(1, intArrayOf(t.tex), 0)
    }

    private fun allocTargets() {
        full.forEach { freeTarget(it) }
        luma.forEach { freeTarget(it) }
        freeTarget(mv)
        full = arrayOf<Target?>(makeTarget(width, height), makeTarget(width, height))
        val lw = ceil(width / 8.0).toInt().coerceAtLeast(8)
        val lh = ceil(height / 8.0).toInt().coerceAtLeast(8)
        luma = arrayOf<Target?>(makeTarget(lw, lh, false), makeTarget(lw, lh, false))
        mv = makeTarget(lw, lh, true)
        cur = 0
        lcur = 0
    }

    // ------------------------------------------------------------------ drawing

    private fun bind(p: Int) {
        GLES30.glUseProgram(p)
        GLES30.glEnableVertexAttribArray(0)
        GLES30.glVertexAttribPointer(0, 2, GLES30.GL_FLOAT, false, 0, quad)
    }

    private fun tex(unit: Int, id: Int, p: Int, name: String, external: Boolean = false) {
        GLES30.glActiveTexture(GLES30.GL_TEXTURE0 + unit)
        GLES30.glBindTexture(if (external) GLES11Ext.GL_TEXTURE_EXTERNAL_OES else GLES30.GL_TEXTURE_2D, id)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(p, name), unit)
    }

    private fun mat(p: Int, m: FloatArray) {
        GLES30.glUniformMatrix4fv(GLES30.glGetUniformLocation(p, "uTex"), 1, false, m, 0)
    }

    private fun target(t: Target?, w: Int, h: Int) {
        GLES30.glBindFramebuffer(GLES30.GL_FRAMEBUFFER, t?.fbo ?: 0)
        GLES30.glViewport(0, 0, w, h)
    }

    private fun quadDraw() = GLES30.glDrawArrays(GLES30.GL_TRIANGLE_STRIP, 0, 4)

    private fun captureInto(t: Target) {
        target(t, t.w, t.h)
        bind(progOes)
        mat(progOes, texMat)
        tex(0, oesTex, progOes, "uTexture", true)
        quadDraw()
    }

    private fun showFull(t: Target) {
        target(null, outW, outH)
        bind(progCopy)
        mat(progCopy, ident)
        tex(0, t.tex, progCopy, "uTexture")
        quadDraw()
        EGL14.eglSwapBuffers(dpy, surf)
    }

    private fun estimateMotion(prevL: Target, curL: Target) {
        val m = mv!!
        target(m, m.w, m.h)
        bind(progMe)
        mat(progMe, ident)
        tex(0, prevL.tex, progMe, "uPrev")
        tex(1, curL.tex, progMe, "uCurr")
        GLES30.glUniform2f(GLES30.glGetUniformLocation(progMe, "uTexel"), 1f / m.w, 1f / m.h)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progMe, "uR"), if (quality >= 2) 3 else 2)
        quadDraw()
    }

    private fun showInterpolated(prev: Target, curT: Target) {
        target(null, outW, outH)
        bind(progInterp)
        mat(progInterp, ident)
        tex(0, prev.tex, progInterp, "uPrev")
        tex(1, curT.tex, progInterp, "uCurr")
        val m = mv!!
        tex(2, m.tex, progInterp, "uMv")
        GLES30.glUniform2f(GLES30.glGetUniformLocation(progInterp, "uTexelLow"), 1f / m.w, 1f / m.h)
        GLES30.glUniform1f(GLES30.glGetUniformLocation(progInterp, "uR"), if (quality >= 2) 3f else 2f)
        GLES30.glUniform1i(GLES30.glGetUniformLocation(progInterp, "uMode"), if (quality == 0) 0 else 1)
        quadDraw()
        EGL14.eglSwapBuffers(dpy, surf)
    }

    private fun downscaleLuma(src: Target, dst: Target) {
        target(dst, dst.w, dst.h)
        bind(progLuma)
        mat(progLuma, ident)
        tex(0, src.tex, progLuma, "uTexture")
        GLES30.glUniform2f(GLES30.glGetUniformLocation(progLuma, "uTexel"), 1f / src.w, 1f / src.h)
        quadDraw()
    }

    // ------------------------------------------------------------------ thread

    private fun initEgl() {
        dpy = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
        val ver = IntArray(2)
        if (!EGL14.eglInitialize(dpy, ver, 0, ver, 1)) throw RuntimeException("EGL init failed")
        val attribs = intArrayOf(
            EGL14.EGL_RENDERABLE_TYPE, 0x40, // OpenGL ES 3
            EGL14.EGL_RED_SIZE, 8, EGL14.EGL_GREEN_SIZE, 8, EGL14.EGL_BLUE_SIZE, 8, EGL14.EGL_ALPHA_SIZE, 8,
            EGL14.EGL_NONE
        )
        val cfgs = arrayOfNulls<EGLConfig>(1)
        val n = IntArray(1)
        EGL14.eglChooseConfig(dpy, attribs, 0, cfgs, 0, 1, n, 0)
        if (n[0] == 0 || cfgs[0] == null) throw RuntimeException("No OpenGL ES 3 config on this phone")
        ctx = EGL14.eglCreateContext(dpy, cfgs[0], EGL14.EGL_NO_CONTEXT, intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION, 3, EGL14.EGL_NONE), 0)
        surf = EGL14.eglCreateWindowSurface(dpy, cfgs[0], outSurface, intArrayOf(EGL14.EGL_NONE), 0)
        if (!EGL14.eglMakeCurrent(dpy, surf, surf, ctx)) throw RuntimeException("EGL makeCurrent failed")
        EGL14.eglSwapInterval(dpy, 1)
        val sz = IntArray(1)
        EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_WIDTH, sz, 0)
        outW = sz[0]
        EGL14.eglQuerySurface(dpy, surf, EGL14.EGL_HEIGHT, sz, 0)
        outH = sz[0]
        if (outW <= 0 || outH <= 0) {
            outW = width
            outH = height
        }
    }

    private fun runLoop() {
        try {
            initEgl()
            progOes = program(fsOes)
            progCopy = program(fsCopy)
            progLuma = program(fsLuma)
            progMe = program(fsMe)
            progInterp = program(fsInterp)
            GLES30.glDisable(GLES30.GL_BLEND)
            GLES30.glDisable(GLES30.GL_DEPTH_TEST)

            val t = IntArray(1)
            GLES30.glGenTextures(1, t, 0)
            oesTex = t[0]
            GLES30.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, oesTex)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MIN_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_MAG_FILTER, GLES30.GL_LINEAR)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_S, GLES30.GL_CLAMP_TO_EDGE)
            GLES30.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES, GLES30.GL_TEXTURE_WRAP_T, GLES30.GL_CLAMP_TO_EDGE)

            val s = SurfaceTexture(oesTex)
            s.setDefaultBufferSize(width, height)
            s.setOnFrameAvailableListener {
                synchronized(lock) {
                    pending++
                    lock.notifyAll()
                }
            }
            st = s
            allocTargets()
            inputSurface = Surface(s)
        } catch (e: Throwable) {
            failed = e.message ?: e.toString()
            ready.countDown()
            release()
            return
        }
        ready.countDown()

        var haveTwo = false
        var lastArrival = 0L
        var dtMs = 33f
        var srcCount = 0
        var outCount = 0
        var statStart = System.nanoTime()

        try {
            while (running) {
                synchronized(lock) {
                    if (pending == 0 && running) lock.wait(250)
                    if (pending > 0) pending = 1
                }
                if (!running) break

                if (wantW != width || wantH != height) {
                    width = wantW
                    height = wantH
                    st?.setDefaultBufferSize(width, height)
                    allocTargets()
                    haveTwo = false
                }

                val got = synchronized(lock) {
                    val g = pending > 0
                    pending = 0
                    g
                }
                if (!got) continue

                st!!.updateTexImage()
                st!!.getTransformMatrix(texMat)
                val now = System.nanoTime()
                if (lastArrival != 0L) {
                    val d = (now - lastArrival) / 1_000_000f
                    if (d in 1f..200f) dtMs = dtMs * 0.8f + d * 0.2f
                }
                lastArrival = now
                srcCount++

                // new captured frame -> "current"; old current becomes "previous"
                val prevIdx = cur
                cur = 1 - cur
                captureInto(full[cur]!!)
                if (!haveTwo) {
                    // first frame: make previous == current
                    val c = full[cur]!!
                    val p = full[prevIdx]!!
                    target(p, p.w, p.h)
                    bind(progCopy); mat(progCopy, ident); tex(0, c.tex, progCopy, "uTexture"); quadDraw()
                }

                val doInterp = haveTwo && dtMs > vsyncMs * 1.7f
                if (quality > 0) {
                    val prevL = luma[lcur]!!
                    lcur = 1 - lcur
                    val curL = luma[lcur]!!
                    downscaleLuma(full[cur]!!, curL)
                    if (doInterp) estimateMotion(prevL, curL)
                }
                if (doInterp) {
                    showInterpolated(full[prevIdx]!!, full[cur]!!)
                    outCount++
                }
                showFull(full[cur]!!)
                outCount++
                haveTwo = true

                if (now - statStart >= 1_000_000_000L) {
                    onStats(srcCount, outCount, dtMs.toInt())
                    srcCount = 0
                    outCount = 0
                    statStart = now
                }
            }
        } catch (e: Throwable) {
            failed = e.message ?: e.toString()
            onError(failed!!)
        } finally {
            release()
        }
    }

    private fun release() {
        try {
            if (dpy != EGL14.EGL_NO_DISPLAY) {
                full.forEach { freeTarget(it) }
                luma.forEach { freeTarget(it) }
                freeTarget(mv)
                EGL14.eglMakeCurrent(dpy, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_SURFACE, EGL14.EGL_NO_CONTEXT)
                if (surf != EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(dpy, surf)
                if (ctx != EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(dpy, ctx)
                EGL14.eglTerminate(dpy)
                dpy = EGL14.EGL_NO_DISPLAY
            }
        } catch (_: Throwable) {
        }
        try {
            inputSurface?.release()
            st?.release()
        } catch (_: Throwable) {
        }
    }
}

package com.gr.fps

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.view.WindowManager
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** What the user chose for Thermal Guard. */
object GuardPrefs {
    fun prefs(c: Context): SharedPreferences = c.getSharedPreferences("gr_tg", Context.MODE_PRIVATE)

    fun enabled(c: Context) = prefs(c).getBoolean("on", false)
    fun setEnabled(c: Context, v: Boolean) = prefs(c).edit().putBoolean("on", v).apply()

    /** 0 = early, 1 = normal, 2 = late */
    fun sens(c: Context) = prefs(c).getInt("sens", 1)
    fun setSens(c: Context, v: Int) = prefs(c).edit().putInt("sens", v).apply()

    fun reso(c: Context) = prefs(c).getBoolean("reso", false)
    fun setReso(c: Context, v: Boolean) = prefs(c).edit().putBoolean("reso", v).apply()

    fun hz(c: Context) = prefs(c).getBoolean("hz", true)
    fun setHz(c: Context, v: Boolean) = prefs(c).edit().putBoolean("hz", v).apply()

    /** SoC (CPU/GPU) °C, battery °C at which the phone counts as "hot". */
    fun limits(sens: Int): Pair<Int, Int> = when (sens) {
        0 -> 58 to 38
        2 -> 72 to 44
        else -> 65 to 41
    }
}

/** The actions Thermal Guard takes (and how it undoes them). Previous values are kept so nothing is lost. */
object ThermalGuard {
    private const val K_SIZE = "prev_size"
    private const val K_DENS = "prev_dens"
    private const val K_HZ = "prev_hz"

    private val HZ_KEYS = listOf(
        "min_refresh_rate", "peak_refresh_rate", "tran_refresh_mode", "preferred_refresh_rate",
        "refresh_default_rate", "last_tran_refresh_mode_in_refresh_setting", "min_render_frame_rate",
        "peak_render_frame_rate", "max_refresh_rate", "default_refresh_rate", "user_refresh_rate"
    )
    private val FLOAT_KEYS = setOf("min_refresh_rate", "peak_refresh_rate")

    fun pending(c: Context): Boolean {
        val p = GuardPrefs.prefs(c)
        return p.contains(K_SIZE) || p.contains(K_HZ)
    }

    private fun even(x: Int) = x - x % 2

    /** Drops the refresh rate to 60 Hz. Returns a short description, or null if it did nothing. */
    suspend fun lowerHz(c: Context): String? {
        val p = GuardPrefs.prefs(c)
        if (!p.contains(K_HZ)) {
            val parts = ArrayList<String>()
            for (k in HZ_KEYS) {
                val cur = ShizukuHelper.exec("settings get system $k").trim().lines().lastOrNull().orEmpty()
                val missing = cur.isEmpty() || cur == "null" || cur.startsWith("ERR:")
                if (missing && k !in FLOAT_KEYS) continue
                parts += "$k=${if (missing) "null" else cur}"
            }
            p.edit().putString(K_HZ, parts.joinToString(";")).apply()
        }
        val saved = p.getString(K_HZ, "").orEmpty()
        for (part in saved.split(";")) {
            val k = part.substringBefore("=")
            if (k.isEmpty()) continue
            ShizukuHelper.exec("settings put system $k ${if (k in FLOAT_KEYS) "60.0" else "60"}")
        }
        return "screen set to 60 Hz"
    }

    /** Lowers the screen resolution by one preset step. Returns a description, or null if it did nothing. */
    suspend fun lowerRes(c: Context): String? {
        val p = GuardPrefs.prefs(c)
        val d = Optimizer.readDisplay() ?: return null
        val o = ShizukuHelper.exec("wm size; wm density")
        val os = Regex("Override size:\\s*(\\d+)x(\\d+)").find(o)
        val od = Regex("Override density:\\s*(\\d+)").find(o)
        val curW = os?.groupValues?.get(1)?.toInt() ?: d.w
        val curH = os?.groupValues?.get(2)?.toInt() ?: d.h
        val curShort = min(curW, curH)
        val target = listOf(2160, 1440, 1080, 900, 720, 480, 360).firstOrNull { it < curShort * 0.93 } ?: return null
        if (!p.contains(K_SIZE)) {
            p.edit()
                .putString(K_SIZE, if (os != null) "${curW}x$curH" else "reset")
                .putString(K_DENS, od?.groupValues?.get(1) ?: "reset")
                .apply()
        }
        val r = target.toFloat() / d.shortSide
        val w = even((d.w * r).roundToInt())
        val h = even((d.h * r).roundToInt())
        val dens = max(120, (d.density * r).roundToInt())
        ShizukuHelper.exec("wm size ${w}x$h")
        ShizukuHelper.exec("wm density $dens")
        return "resolution ${target}p"
    }

    /** Puts everything Thermal Guard changed back. Safe to call any time. */
    suspend fun restoreNow(c: Context) {
        if (ShizukuHelper.state.value != ShizukuState.READY) return
        val p = GuardPrefs.prefs(c)
        p.getString(K_HZ, null)?.let { saved ->
            for (part in saved.split(";")) {
                val k = part.substringBefore("=")
                val v = part.substringAfter("=", "null")
                if (k.isEmpty()) continue
                ShizukuHelper.exec(
                    if (v == "null") "settings delete system $k" else "settings put system $k $v"
                )
            }
            p.edit().remove(K_HZ).apply()
        }
        if (p.contains(K_SIZE)) {
            val size = p.getString(K_SIZE, "reset").orEmpty()
            val dens = p.getString(K_DENS, "reset").orEmpty()
            ShizukuHelper.exec(if (size == "reset") "wm size reset" else "wm size $size")
            ShizukuHelper.exec(if (dens == "reset") "wm density reset" else "wm density $dens")
            p.edit().remove(K_SIZE).remove(K_DENS).apply()
        }
    }
}

/**
 * Watches temperatures while you play. When the phone gets hot it tells you and (if you allowed it) lowers the
 * refresh rate / resolution so the phone cools down instead of being throttled by Android; when it has cooled
 * down for a while it puts everything back.
 */
class ThermalGuardService : Service() {

    companion object {
        const val ACTION_START = "com.gr.fps.TG_START"
        const val ACTION_STOP = "com.gr.fps.TG_STOP"

        private const val CH = "gr_guard"
        private const val CH_ALERT = "gr_guard_alert"
        private const val ID = 30
        private const val ID_ALERT = 31

        val running = MutableStateFlow(false)
        val status = MutableStateFlow("")

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(
                ctx, Intent(ctx, ThermalGuardService::class.java).setAction(ACTION_START)
            )
        }

        fun stop(ctx: Context) {
            ctx.startService(Intent(ctx, ThermalGuardService::class.java).setAction(ACTION_STOP))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loop: Job? = null
    private var line = "starting…"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> begin()
            ACTION_STOP -> shutdown()
            else -> if (!running.value) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun channels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Thermal Guard", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_ALERT, "Phone is hot", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun canNotify() =
        Build.VERSION.SDK_INT < 33 ||
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun notification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 301,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val stop = PendingIntent.getService(
            this, 302, Intent(this, ThermalGuardService::class.java).setAction(ACTION_STOP), flags
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("Thermal Guard")
            .setContentText(line)
            .setOngoing(true)
            .setShowWhen(false)
            .setOnlyAlertOnce(true)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stop), "Stop", stop).build())
            .build()
    }

    private fun post() {
        getSystemService(NotificationManager::class.java).notify(ID, notification())
    }

    private fun alert(title: String, text: String) {
        if (!canNotify()) return
        val open = PendingIntent.getActivity(
            this, 303, Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, CH_ALERT)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(Notification.BigTextStyle().bigText(text))
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ID_ALERT, n)
    }

    private fun currentHz(): Float = try {
        @Suppress("DEPRECATION")
        getSystemService(WindowManager::class.java).defaultDisplay.refreshRate
    } catch (_: Throwable) {
        60f
    }

    private fun begin() {
        if (running.value) return
        channels()
        try {
            ServiceCompat.startForeground(this, ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } catch (e: Exception) {
            stopSelf()
            return
        }
        running.value = true
        loop = scope.launch { watch() }
    }

    private suspend fun watch() {
        var hotCount = 0
        var coolSince = 0L
        var steps = 0
        var resSteps = 0
        var lastAction = 0L

        while (scope.isActive && running.value) {
            val s = try {
                SysProbe.sample(applicationContext)
            } catch (_: Throwable) {
                null
            }
            if (s != null) {
                val soc = listOfNotNull(s.cpuTemp, s.gpuTemp).maxOrNull()
                val bat = s.batTemp
                val st = s.thermalStatus ?: 0
                val (socLim, batLim) = GuardPrefs.limits(GuardPrefs.sens(applicationContext))

                val hot = (soc != null && soc >= socLim) || (bat != null && bat >= batLim) || st >= 2
                val warm = !hot && ((soc != null && soc >= socLim - 6) || (bat != null && bat >= batLim - 2) || st == 1)
                val cool = (soc == null || soc <= socLim - 8) && (bat == null || bat <= batLim - 3) && st <= 1

                val now = System.currentTimeMillis()
                val temps = buildString {
                    bat?.let { append("battery ${it.roundToInt()}°C") }
                    soc?.let { if (isNotEmpty()) append(" • "); append("chip ${it.roundToInt()}°C") }
                    if (isEmpty()) append("no temperature readings")
                }
                val state = when {
                    steps > 0 -> "COOLING (lowered)"
                    hot -> "HOT"
                    warm -> "warm"
                    else -> "OK"
                }
                line = "$temps • $state"
                status.value = line
                post()

                val canAct = ShizukuHelper.state.value == ShizukuState.READY
                if (hot) {
                    hotCount++
                    coolSince = 0
                    if (hotCount >= 2) {
                        if (steps == 0) {
                            val done = ArrayList<String>()
                            if (canAct && GuardPrefs.hz(applicationContext) && currentHz() > 65f) {
                                ThermalGuard.lowerHz(applicationContext)?.let { done += it }
                            }
                            if (canAct && GuardPrefs.reso(applicationContext)) {
                                ThermalGuard.lowerRes(applicationContext)?.let { done += it; resSteps++ }
                            }
                            steps = 1
                            lastAction = now
                            alert(
                                "Phone is hot — $temps",
                                if (done.isEmpty()) "Take a short break, take off the case, or lower the in-game graphics."
                                else "GR FPS lowered: " + done.joinToString(", ") + ". It goes back by itself when the phone has cooled."
                            )
                        } else if (canAct && GuardPrefs.reso(applicationContext) && resSteps < 2 && now - lastAction > 60_000) {
                            ThermalGuard.lowerRes(applicationContext)?.let {
                                resSteps++
                                lastAction = now
                                alert("Still hot — $temps", "GR FPS lowered the $it further.")
                            }
                        }
                    }
                } else {
                    hotCount = 0
                    if (steps > 0) {
                        if (cool) {
                            if (coolSince == 0L) coolSince = now
                            if (now - coolSince >= 45_000) {
                                ThermalGuard.restoreNow(applicationContext)
                                steps = 0
                                resSteps = 0
                                coolSince = 0
                                alert("Phone cooled down ✔", "Your screen settings are back to normal.")
                            }
                        } else {
                            coolSince = 0
                        }
                    }
                }
            }
            delay(3000)
        }
    }

    private fun shutdown() {
        if (!running.value) {
            stopSelf()
            return
        }
        running.value = false
        status.value = ""
        loop?.cancel()
        scope.launch {
            try {
                ThermalGuard.restoreNow(applicationContext)
            } catch (_: Throwable) {
            }
            withContext(Dispatchers.Main) {
                ServiceCompat.stopForeground(this@ThermalGuardService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        running.value = false
        loop?.cancel()
        super.onDestroy()
    }
}

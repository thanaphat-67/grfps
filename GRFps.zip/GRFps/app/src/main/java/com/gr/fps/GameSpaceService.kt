package com.gr.fps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Icon
import android.media.MediaScannerConnection
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Toast
import androidx.compose.ui.platform.ComposeView
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.gr.fps.ui.GameSpacePanel
import com.gr.fps.ui.GrFpsTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

object GsPrefs {
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("gr_gs", Context.MODE_PRIVATE)
    fun enabled(c: Context) = p(c).getBoolean("on", false)
    fun setEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("on", v).apply()
    fun tabY(c: Context) = p(c).getInt("tab_y", -1)
    fun setTabY(c: Context, v: Int) = p(c).edit().putInt("tab_y", v).apply()
}

/** What the Game Space window can ask the service to do. */
interface GsHost {
    val ctx: Context
    fun close()
    fun screenshot()
    fun startRecording()
}

/** The small neon tab on the left edge of the screen. */
private class TabView(ctx: Context) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF39FF14.toInt()
    }
    private val arrow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        color = 0xFF39FF14.toInt()
        strokeCap = Paint.Cap.ROUND
    }

    override fun onDraw(canvas: Canvas) {
        val d = resources.displayMetrics.density
        val w = width.toFloat()
        val h = height.toFloat()
        fill.shader = LinearGradient(0f, 0f, w, 0f, 0xCC0B1F12.toInt(), 0xEE123B1C.toInt(), Shader.TileMode.CLAMP)
        stroke.strokeWidth = 1.5f * d
        arrow.strokeWidth = 2.2f * d
        val r = 10f * d
        val rect = RectF(-r, 1f * d, w - 1f * d, h - 1f * d)
        canvas.drawRoundRect(rect, r, r, fill)
        canvas.drawRoundRect(rect, r, r, stroke)
        val p = Path()
        val cx = w * 0.5f
        val cy = h * 0.5f
        p.moveTo(cx - 3f * d, cy - 7f * d)
        p.lineTo(cx + 3f * d, cy)
        p.lineTo(cx - 3f * d, cy + 7f * d)
        canvas.drawPath(p, arrow)
    }
}

/**
 * Game Space: a small tab on the left edge. Tap it (or slide it right) to open a neon tools window
 * on top of any game; every button there works at once, no APPLY needed.
 */
class GameSpaceService : Service(), LifecycleOwner, SavedStateRegistryOwner, ViewModelStoreOwner, GsHost {

    companion object {
        const val ACTION_OFF = "com.gr.fps.GS_OFF"
        private const val CH = "gr_gamespace"
        private const val ID = 40

        val running = MutableStateFlow(false)

        fun start(ctx: Context) {
            ContextCompat.startForegroundService(ctx, Intent(ctx, GameSpaceService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, GameSpaceService::class.java))
        }
    }

    private val registry = LifecycleRegistry(this)
    private val savedState = SavedStateRegistryController.create(this)
    private val vmStore = ViewModelStore()

    override val lifecycle: Lifecycle get() = registry
    override val savedStateRegistry: SavedStateRegistry get() = savedState.savedStateRegistry
    override val viewModelStore: ViewModelStore get() = vmStore
    override val ctx: Context get() = this

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var wm: WindowManager? = null
    private var tab: TabView? = null
    private var tabLp: WindowManager.LayoutParams? = null
    private var panel: ComposeView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        savedState.performAttach()
        savedState.performRestore(null)
        registry.currentState = Lifecycle.State.RESUMED
        ShizukuHelper.init()
        ActiveStore.load(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_OFF) {
            GsPrefs.setEnabled(this, false)
            ActiveStore.events.tryEmit("gs")
            stopSelf()
            return START_NOT_STICKY
        }
        val type = if (Build.VERSION.SDK_INT >= 34) ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE else 0
        ServiceCompat.startForeground(this, ID, notification(), type)
        if (tab == null) addTab()
        running.value = true
        return START_NOT_STICKY
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Game Space", NotificationManager.IMPORTANCE_LOW))
        val off = PendingIntent.getService(
            this, ID,
            Intent(this, GameSpaceService::class.java).setAction(ACTION_OFF),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val open = PendingIntent.getActivity(
            this, ID,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("GR FPS Game Space is on")
            .setContentText("Tap the green tab on the left edge of the screen")
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_bolt), "Turn off", off).build())
            .setOngoing(true)
            .build()
    }

    private fun screenH(): Int = resources.displayMetrics.heightPixels

    private fun addTab() {
        val manager = getSystemService(WindowManager::class.java)
        val d = resources.displayMetrics.density
        val h = (84 * d).toInt()
        val lp = WindowManager.LayoutParams(
            (22 * d).toInt(), h,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 0
            val saved = GsPrefs.tabY(this@GameSpaceService)
            y = if (saved >= 0) saved else (screenH() / 2 - h / 2)
        }
        val v = TabView(this)
        v.setOnTouchListener(object : View.OnTouchListener {
            var downX = 0f
            var downY = 0f
            var startY = 0
            var moved = false

            override fun onTouch(view: View, e: MotionEvent): Boolean {
                when (e.actionMasked) {
                    MotionEvent.ACTION_DOWN -> {
                        downX = e.rawX
                        downY = e.rawY
                        startY = lp.y
                        moved = false
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = e.rawX - downX
                        val dy = e.rawY - downY
                        if (dx > 30 * d && abs(dx) > abs(dy)) {
                            showPanel()
                            return true
                        }
                        if (abs(dy) > 10 * d) {
                            moved = true
                            lp.y = (startY + dy).toInt().coerceIn(0, (screenH() - h).coerceAtLeast(0))
                            manager.updateViewLayout(v, lp)
                        }
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!moved && abs(e.rawX - downX) < 10 * d) showPanel()
                        else GsPrefs.setTabY(this@GameSpaceService, lp.y)
                    }
                }
                return true
            }
        })
        manager.addView(v, lp)
        wm = manager
        tab = v
        tabLp = lp
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val lp = tabLp ?: return
        val v = tab ?: return
        lp.y = lp.y.coerceIn(0, (screenH() - lp.height).coerceAtLeast(0))
        try {
            wm?.updateViewLayout(v, lp)
        } catch (_: Throwable) {
        }
    }

    private fun showPanel() {
        if (panel != null) return
        val manager = wm ?: return
        tab?.visibility = View.GONE
        val cv = ComposeView(this).apply {
            setViewTreeLifecycleOwner(this@GameSpaceService)
            setViewTreeSavedStateRegistryOwner(this@GameSpaceService)
            setViewTreeViewModelStoreOwner(this@GameSpaceService)
            setContent { GrFpsTheme { GameSpacePanel(this@GameSpaceService) } }
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        try {
            manager.addView(cv, lp)
            panel = cv
        } catch (e: Throwable) {
            tab?.visibility = View.VISIBLE
            Toast.makeText(this, "Game Space couldn't open: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    private fun hidePanel() {
        val cv = panel ?: return
        panel = null
        try {
            cv.disposeComposition()
            wm?.removeView(cv)
        } catch (_: Throwable) {
        }
        tab?.visibility = View.VISIBLE
    }

    override fun close() {
        // may be called from a click inside the panel: remove it after that click is finished
        panel?.post { hidePanel() }
    }

    override fun screenshot() {
        if (ShizukuHelper.state.value != ShizukuState.READY) {
            GsOps.say("✘ Connect Shizuku first (open the GR FPS app)")
            return
        }
        panel?.post {
            hidePanel()
            tab?.visibility = View.INVISIBLE
            scope.launch {
                delay(450)   // let the panel disappear before the screen is captured
                val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val dir = "/sdcard/Pictures/GRFPS"
                val file = "$dir/GRFPS_$stamp.png"
                val out = ShizukuHelper.exec("mkdir -p $dir && screencap -p $file && ls -l $file", 15_000)
                val ok = out.contains("GRFPS_$stamp") && !out.contains("ERR") && !out.contains("No such") &&
                    !out.contains("rror")
                tab?.visibility = View.VISIBLE
                if (ok) {
                    withContext(Dispatchers.IO) {
                        MediaScannerConnection.scanFile(applicationContext, arrayOf(file), arrayOf("image/png"), null)
                    }
                    GsOps.say("✔ Screenshot saved: Pictures/GRFPS/GRFPS_$stamp.png")
                    Toast.makeText(applicationContext, "Screenshot saved", Toast.LENGTH_SHORT).show()
                } else {
                    GsOps.say("✘ Screenshot failed: ${out.take(120)}")
                    Toast.makeText(applicationContext, "Screenshot failed", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    override fun startRecording() {
        panel?.post { hidePanel() }
        try {
            startActivity(
                Intent(this, CaptureRequestActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (e: Throwable) {
            GsOps.say("✘ Couldn't start the recorder: ${e.message}")
        }
    }

    override fun onDestroy() {
        hidePanel()
        try {
            tab?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        tab = null
        running.value = false
        scope.cancel()
        registry.currentState = Lifecycle.State.DESTROYED
        vmStore.clear()
        ShizukuHelper.destroy()
        super.onDestroy()
    }
}

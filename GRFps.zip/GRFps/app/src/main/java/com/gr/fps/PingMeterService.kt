package com.gr.fps

import android.content.Context
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.Socket
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

/**
 * Ping meter: every second it opens a TCP connection to the chosen server and times how long the server takes to
 * answer. Shows the latest ping, average, jitter (how much it jumps around) and how many tries got no answer.
 */
class PingMeterService : BaseOverlayService() {

    companion object {
        val running = MutableStateFlow(false)

        /** (label, host, port) for the built-in choices. */
        val PRESETS = listOf(
            Triple("Cloudflare", "1.1.1.1", 443),
            Triple("Google", "8.8.8.8", 443)
        )

        /** Splits "host" or "host:port" (port defaults to 443). */
        fun parseCustom(text: String): Pair<String, Int>? {
            val t = text.trim().removePrefix("https://").removePrefix("http://").substringBefore("/")
            if (t.isEmpty()) return null
            val host = t.substringBeforeLast(":", t)
            val port = if (t.contains(":")) t.substringAfterLast(":").toIntOrNull() else 443
            if (host.isEmpty() || port == null || port !in 1..65535) return null
            return host to port
        }
    }

    override val notifId = 5
    override val channelId = "gr_fps_ping"
    override val title = "GRFlow ping meter is running"
    override val scaleKey = "ping"
    override val stopAction = "com.gr.fps.STOP_PING"
    override val startY = 700
    override val tickMs = 1000L

    private var box: LinearLayout? = null
    private var l1: TextView? = null
    private var l2: TextView? = null
    private var l3: TextView? = null

    private val window = ArrayDeque<Int?>()       // last 30 tries: ms, or null = no answer
    private var cachedHost = ""
    private var cachedAddr: InetAddress? = null

    override fun createContent(ctx: Context): View {
        val root = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xAA000000.toInt())
        }
        val a = overlayText(ctx, true)
        val b = overlayText(ctx, true)
        val c = overlayText(ctx, true)
        a.text = "PING --"
        root.addView(a)
        root.addView(b)
        root.addView(c)
        box = root
        l1 = a
        l2 = b
        l3 = c
        return root
    }

    override fun applyScale(scale: Float) {
        val r = box ?: return
        val p = dpOf(this, 8f * scale).toInt()
        r.setPadding(p, p, p, p)
        l1?.textSize = 16f * scale
        l2?.textSize = 13f * scale
        l3?.textSize = 13f * scale
        r.requestLayout()
    }

    override fun setRunning(v: Boolean) {
        running.value = v
    }

    override fun onStarted() {
        window.clear()
    }

    private fun target(): Triple<String, String, Int> {
        val choice = UiPrefs.pmTarget(this)
        if (choice in PRESETS.indices) {
            val p = PRESETS[choice]
            return Triple(p.second, p.second, p.third)
        }
        val c = parseCustom(UiPrefs.pmHost(this))
        return if (c != null) Triple(c.first, c.first, c.second) else Triple("1.1.1.1", "1.1.1.1", 443)
    }

    private fun measure(host: String, port: Int): Int? {
        return try {
            var addr = cachedAddr
            if (host != cachedHost || addr == null) {
                addr = InetAddress.getByName(host)
                cachedAddr = addr
                cachedHost = host
            }
            val t0 = System.nanoTime()
            Socket().use { s ->
                s.connect(InetSocketAddress(addr, port), 1000)
            }
            val ms = ((System.nanoTime() - t0) / 1_000_000.0).roundToInt()
            ms.coerceAtLeast(1)
        } catch (_: Throwable) {
            cachedAddr = null   // re-resolve next time (the network may have changed)
            null
        }
    }

    override suspend fun onTick() {
        val (label, host, port) = target()
        val ms = withContext(Dispatchers.IO) { measure(host, port) }
        window.addLast(ms)
        while (window.size > 30) window.removeFirst()

        val ok = window.filterNotNull()
        val loss = if (window.isEmpty()) 0 else ((window.size - ok.size) * 100f / window.size).roundToInt()
        val avg = if (ok.isEmpty()) null else ok.average().roundToInt()
        val jitter = if (ok.size < 2) null else
            ok.zipWithNext { a, b -> abs(b - a) }.average().roundToInt()

        withContext(Dispatchers.Main) {
            if (ms == null) {
                l1?.text = "PING --"
                l1?.setTextColor(0xFFFF5252.toInt())
            } else {
                l1?.text = "PING $ms ms"
                l1?.setTextColor(
                    when {
                        ms < 60 -> 0xFF39FF14.toInt()
                        ms < 120 -> 0xFFFFEB3B.toInt()
                        else -> 0xFFFF5252.toInt()
                    }
                )
            }
            l2?.text = "AVG ${avg ?: "--"}   JITTER ${jitter ?: "--"}"
            l3?.text = String.format(Locale.US, "LOSS %d%%   %s", loss, if (label.length > 18) label.take(18) + "…" else label)
        }
    }
}

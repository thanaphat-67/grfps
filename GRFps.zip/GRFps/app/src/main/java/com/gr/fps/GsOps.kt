package com.gr.fps

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

/** What the Game Space buttons do. Lives outside the window, so closing the panel never cuts an action in half. */
object GsOps {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    /** Key of the action running right now (null = idle). Only one action runs at a time, so nothing is applied twice. */
    var busy by mutableStateOf<String?>(null); private set

    /** Result of the latest action (✔ / ✘ lines). */
    var status by mutableStateOf(""); private set

    fun say(msg: String) {
        status = msg
    }

    private fun shizukuOk(): Boolean {
        if (ShizukuHelper.state.value == ShizukuState.READY) return true
        status = "✘ Connect Shizuku first (open the GRFlow app)"
        return false
    }

    private fun run(ctx: Context, key: String, block: suspend (Context) -> String) {
        if (busy != null) return
        val app = ctx.applicationContext
        busy = key
        scope.launch {
            try {
                status = withTimeoutOrNull(90_000) { block(app) } ?: "✘ Took too long and was stopped"
            } catch (e: Throwable) {
                status = "✘ ${e.message ?: "error"}"
            } finally {
                busy = null
            }
        }
    }

    private fun summary(log: List<String>): String {
        val l = log.filter { it.startsWith("✔") || it.startsWith("✘") || it.startsWith("↩") }
        return (if (l.isEmpty()) log else l).joinToString("\n").ifEmpty { "Done" }
    }

    fun isOn(a: Active, f: String): Boolean = when (f) {
        "hz" -> a.hz > 0
        "dns" -> a.dns.isNotEmpty()
        "dnd" -> a.dnd
        "headsUp" -> a.headsUp
        "awake" -> a.awake
        "saver" -> a.saver
        "gameMode" -> a.gameMode
        "scans" -> a.scans
        "fixedPerf" -> a.fixedPerf
        else -> false
    }

    /** Tap on a switch-type tile: ON -> turn it off, OFF -> turn it on. */
    fun toggle(ctx: Context, feature: String, cfg: BoostConfig) {
        if (busy != null || !shizukuOk()) return
        run(ctx, feature) { c ->
            ActiveStore.load(c)
            if (isOn(ActiveStore.state.value, feature)) Optimizer.undo(c, feature)
            else summary(Optimizer.apply(c, cfg))
        }
    }

    /** FPS Lock page: same Hz again = turn off, otherwise lock to the chosen Hz. */
    fun lockHz(ctx: Context, hz: Int) {
        if (busy != null || !shizukuOk()) return
        run(ctx, "hz") { c ->
            ActiveStore.load(c)
            if (ActiveStore.state.value.hz == hz) Optimizer.undo(c, "hz")
            else summary(Optimizer.apply(c, BoostConfig(refreshRate = hz)))
        }
    }

    fun lowPing(ctx: Context, d: DnsChoice) {
        if (busy != null || !shizukuOk()) return
        run(ctx, "dns") { c ->
            ActiveStore.load(c)
            if (ActiveStore.state.value.dns == d.name) Optimizer.undo(c, "dns")
            else summary(Optimizer.apply(c, BoostConfig(dns = d)))
        }
    }

    private fun availMb(c: Context): Long {
        val mi = ActivityManager.MemoryInfo()
        c.getSystemService(ActivityManager::class.java).getMemoryInfo(mi)
        return mi.availMem / (1024 * 1024)
    }

    fun freeRam(ctx: Context) {
        if (busy != null || !shizukuOk()) return
        run(ctx, "ram") { c ->
            val before = availMb(c)
            val out = ShizukuHelper.exec("am kill-all")
            delay(800)
            val after = availMb(c)
            when {
                out.startsWith("ERR") -> "✘ Free RAM failed: $out"
                after > before -> "✔ Free RAM: $before MB → $after MB"
                else -> "✔ Background apps closed. $after MB free (there was little left to free)"
            }
        }
    }

    fun trimCaches(ctx: Context) {
        if (busy != null || !shizukuOk()) return
        run(ctx, "trim") {
            val out = ShizukuHelper.exec("(pm trim-caches 999G >/dev/null 2>&1 &)")
            if (out.startsWith("ERR")) "✘ Trim caches failed: $out" else "✔ Cache trim started (runs in the background)"
        }
    }

    /** FPS Meter / Pro / Temp / Ping overlays: tap = show, tap again = hide. */
    fun overlay(ctx: Context, cls: Class<*>, running: Boolean, needShizuku: Boolean) {
        if (running) {
            stopOverlay(ctx, cls)
            return
        }
        if (needShizuku && !shizukuOk()) return
        startOverlay(ctx, cls)
    }

    fun guard(ctx: Context, on: Boolean) {
        val c = ctx.applicationContext
        GuardPrefs.setEnabled(c, on)
        if (on) ThermalGuardService.start(c) else ThermalGuardService.stop(c)
        ActiveStore.events.tryEmit("guard")
    }

    fun recorder(ctx: Context, action: String) {
        ctx.startService(Intent(ctx, RecorderService::class.java).setAction(action))
    }
}

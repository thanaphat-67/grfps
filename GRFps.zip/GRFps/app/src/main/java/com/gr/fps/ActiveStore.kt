package com.gr.fps

import android.content.Context
import android.provider.Settings
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow

/** What GR FPS has switched ON right now (shared by the main app and Game Space). */
data class Active(
    val hz: Int = 0,
    val dns: String = "",
    val dnd: Boolean = false,
    val headsUp: Boolean = false,
    val awake: Boolean = false,
    val saver: Boolean = false,
    val gameMode: Boolean = false,
    val scans: Boolean = false,
    val fixedPerf: Boolean = false
) {
    val focusAny: Boolean get() = dnd || headsUp || awake || saver
}

/**
 * Remembers which functions are ON, so the main app and Game Space always agree
 * and nothing gets switched on twice. Cleared by RESET.
 */
object ActiveStore {
    val state = MutableStateFlow(Active())

    /** Fires the name of a feature whenever it changes ("hz", "dns", "dnd", ... or "all"). */
    val events = MutableSharedFlow<String>(extraBufferCapacity = 64)

    private var loaded = false
    private fun p(c: Context) = c.applicationContext.getSharedPreferences("gr_active", Context.MODE_PRIVATE)

    @Synchronized
    fun load(c: Context) {
        if (loaded) return
        loaded = true
        val sp = p(c)
        var a = Active(
            hz = sp.getInt("hz", 0),
            dns = sp.getString("dns", "") ?: "",
            dnd = sp.getBoolean("dnd", false),
            headsUp = sp.getBoolean("headsUp", false),
            awake = sp.getBoolean("awake", false),
            saver = sp.getBoolean("saver", false),
            gameMode = sp.getBoolean("gameMode", false),
            scans = sp.getBoolean("scans", false),
            fixedPerf = sp.getBoolean("fixedPerf", false)
        )
        // Fixed performance mode does not survive a reboot
        val boot = try {
            Settings.Global.getInt(c.contentResolver, "boot_count", -1)
        } catch (_: Throwable) {
            -1
        }
        if (boot != sp.getInt("boot", -2)) {
            if (a.fixedPerf) {
                a = a.copy(fixedPerf = false)
                BackupStore.clearFlag(c, "fixedperf")
            }
            sp.edit().putInt("boot", boot).putBoolean("fixedPerf", false).apply()
        }
        state.value = a
    }

    private fun save(c: Context, a: Active) {
        p(c).edit()
            .putInt("hz", a.hz).putString("dns", a.dns)
            .putBoolean("dnd", a.dnd).putBoolean("headsUp", a.headsUp)
            .putBoolean("awake", a.awake).putBoolean("saver", a.saver)
            .putBoolean("gameMode", a.gameMode).putBoolean("scans", a.scans)
            .putBoolean("fixedPerf", a.fixedPerf).apply()
    }

    @Synchronized
    fun update(c: Context, feature: String, block: (Active) -> Active) {
        load(c)
        val a = block(state.value)
        state.value = a
        save(c, a)
        events.tryEmit(feature)
    }

    @Synchronized
    fun clearAll(c: Context) {
        load(c)
        state.value = Active()
        save(c, Active())
        events.tryEmit("all")
    }

    // ---- last values the user picked in Game Space / the app ----
    fun lastHz(c: Context): Int = p(c).getInt("last_hz", 0)
    fun setLastHz(c: Context, v: Int) = p(c).edit().putInt("last_hz", v).apply()
    fun lastDns(c: Context): String = p(c).getString("last_dns", "") ?: ""
    fun setLastDns(c: Context, v: String) = p(c).edit().putString("last_dns", v).apply()
}

package com.gr.fps

import android.app.ActivityManager
import android.app.Application
import android.text.format.Formatter
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch

class MainViewModel(app: Application) : AndroidViewModel(app) {

    var level by mutableStateOf<Level?>(Level.MEDIUM); private set
    var config by mutableStateOf(Optimizer.configFor(Level.MEDIUM)); private set
    var busy by mutableStateOf(false); private set
    var log by mutableStateOf<List<String>>(emptyList()); private set
    var hasBackup by mutableStateOf(BackupStore.has(app)); private set
    var pending by mutableStateOf<BoostConfig?>(null); private set
    var confirmReset by mutableStateOf(false)
    var ramText by mutableStateOf("")

    init { refreshRam() }

    fun selectLevel(l: Level) {
        level = l
        config = Optimizer.configFor(l)
    }

    fun edit(new: BoostConfig) {
        config = new
        level = Level.values().firstOrNull { Optimizer.configFor(it) == new }
    }

    /** Opens the "Apply?" confirmation. Nothing changes until the user confirms. */
    fun requestApply(cfg: BoostConfig = config) {
        pending = cfg
    }

    fun dismissPending() {
        pending = null
    }

    fun confirmApply() {
        val cfg = pending ?: return
        pending = null
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            busy = true
            log = Optimizer.apply(ctx, cfg)
            hasBackup = BackupStore.has(ctx)
            refreshRam()
            busy = false
            Notifier.show(ctx, "Boost applied")
        }
    }

    fun confirmResetNow() {
        confirmReset = false
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            busy = true
            log = Optimizer.reset(ctx)
            hasBackup = BackupStore.has(ctx)
            refreshRam()
            busy = false
        }
    }

    fun refreshRam() {
        val ctx = getApplication<Application>()
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        ramText = "RAM free ${Formatter.formatFileSize(ctx, mi.availMem)} / ${Formatter.formatFileSize(ctx, mi.totalMem)}"
    }
}

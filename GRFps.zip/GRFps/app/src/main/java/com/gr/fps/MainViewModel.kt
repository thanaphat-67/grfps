package com.gr.fps

import android.app.ActivityManager
import android.app.Application
import android.text.format.Formatter
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withTimeoutOrNull

class MainViewModel(app: Application) : AndroidViewModel(app) {

    var level by mutableStateOf<Level?>(Level.MEDIUM); private set
    var config by mutableStateOf(Optimizer.configFor(Level.MEDIUM)); private set
    var busy by mutableStateOf(false); private set
    var log by mutableStateOf<List<String>>(emptyList()); private set
    var hasBackup by mutableStateOf(BackupStore.has(app)); private set
    var pending by mutableStateOf<BoostConfig?>(null); private set
    var confirmReset by mutableStateOf(false)
    var ramText by mutableStateOf("")

    /** Short edge of the real panel in pixels (0 = not known yet). */
    var nativeShort by mutableIntStateOf(0); private set
    var nativeText by mutableStateOf(""); private set

    /** > 0 while the "Keep this resolution?" countdown is showing. */
    var keepSeconds by mutableIntStateOf(0); private set
    private var keepJob: Job? = null

    init { refreshRam() }

    fun selectLevel(l: Level) {
        level = l
        config = Optimizer.configFor(l)
    }

    fun edit(new: BoostConfig) {
        config = new
        level = Level.values().firstOrNull { Optimizer.configFor(it) == new }
    }

    /** Opens the "Apply?" confirmation. Nothing changes until the user confirms. */
    fun requestApply(cfg: BoostConfig = config) {
        pending = cfg
    }

    fun dismissPending() {
        pending = null
    }

    fun confirmApply() {
        val cfg = pending ?: return
        pending = null
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            busy = true
            try {
                log = withTimeoutOrNull(90_000) { Optimizer.apply(ctx, cfg) }
                    ?: listOf("✘ Took too long and was stopped. Tap RESET if anything feels off.")
            } finally {
                hasBackup = BackupStore.has(ctx)
                refreshRam()
                busy = false
            }
            Notifier.show(ctx, "Boost applied")
            if (log.any { it.startsWith("✔ Resolution") }) startKeepCountdown()
        }
    }

    fun confirmResetNow() {
        confirmReset = false
        keepJob?.cancel()
        keepSeconds = 0
        val ctx = getApplication<Application>()
        viewModelScope.launch {
            busy = true
            try {
                log = withTimeoutOrNull(90_000) { Optimizer.reset(ctx) }
                    ?: listOf("✘ Reset took too long and was stopped. Try again.")
            } finally {
                hasBackup = BackupStore.has(ctx)
                refreshRam()
                busy = false
            }
        }
    }

    // ---- resolution safety net: revert by itself unless the user taps KEEP ----

    private fun startKeepCountdown() {
        keepJob?.cancel()
        keepJob = viewModelScope.launch {
            for (s in 15 downTo 1) {
                keepSeconds = s
                delay(1000)
            }
            keepSeconds = 0
            doRevert()
        }
    }

    private suspend fun doRevert() {
        Optimizer.restoreResolution(getApplication())
        log = log + "↩ Resolution reverted to the original"
    }

    fun keepResolution() {
        keepJob?.cancel()
        keepSeconds = 0
    }

    fun revertResolutionNow() {
        keepJob?.cancel()
        keepSeconds = 0
        viewModelScope.launch { doRevert() }
    }

    fun refreshDisplay() {
        if (ShizukuHelper.state.value != ShizukuState.READY) return
        viewModelScope.launch {
            Optimizer.readDisplay()?.let {
                nativeShort = it.shortSide
                nativeText = "Screen ${it.w}×${it.h}  •  native ${it.shortSide}p"
            }
        }
    }

    fun refreshRam() {
        val ctx = getApplication<Application>()
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        ramText = "RAM free ${Formatter.formatFileSize(ctx, mi.availMem)} / ${Formatter.formatFileSize(ctx, mi.totalMem)}"
    }
}

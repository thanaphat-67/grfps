package com.gr.fps

import android.app.ActivityManager
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import android.hardware.display.DisplayManager
import android.text.format.Formatter
import android.view.Display
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.InetSocketAddress
import java.net.Socket
import kotlin.math.roundToInt

data class AppEntry(val pkg: String, val label: String, val isGame: Boolean)

class MainViewModel(private val app: Application) : AndroidViewModel(app) {

    var level by mutableStateOf<Level?>(Level.MEDIUM); private set
    var config by mutableStateOf(Optimizer.configFor(Level.MEDIUM)); private set
    var busy by mutableStateOf(false); private set
    var log by mutableStateOf<List<String>>(emptyList()); private set
    var hasBackup by mutableStateOf(BackupStore.has(app)); private set
    var pending by mutableStateOf<BoostConfig?>(null); private set
    var confirmReset by mutableStateOf(false)
    var ramText by mutableStateOf("")

    /** Short edge of the real panel in pixels (0 = not known yet). */
    var nativeShort by mutableIntStateOf(0); private set
    var nativeText by mutableStateOf(""); private set

    /** Refresh rates (Hz) the panel really supports; empty = couldn't tell. */
    var supportedRates by mutableStateOf<Set<Int>>(emptySet()); private set

    /** Phone declares Vulkan support (checked without Shizuku). */
    var vulkanOk by mutableStateOf(false); private set
    var angleOk by mutableStateOf(false); private set

    /** > 0 while the "Keep this resolution?" countdown is showing. */
    var keepSeconds by mutableIntStateOf(0); private set
    private var keepJob: Job? = null

    // ---- overlay sizes ----
    var scaleFps by mutableFloatStateOf(UiPrefs.scale(app, "fps")); private set
    var scaleDetail by mutableFloatStateOf(UiPrefs.scale(app, "detail")); private set
    var scaleThermal by mutableFloatStateOf(UiPrefs.scale(app, "thermal")); private set

    // ---- game / app picker ----
    var selectedApp by mutableStateOf<AppEntry?>(null); private set
    var launchAfter by mutableStateOf(UiPrefs.launchAfter(app)); private set
    var apps by mutableStateOf<List<AppEntry>>(emptyList()); private set
    var appsLoading by mutableStateOf(false); private set

    // ---- low ping ----
    var pings by mutableStateOf<Map<DnsChoice, Int?>>(emptyMap()); private set
    var pingBusy by mutableStateOf(false); private set

    // ---- screen recorder ----
    var recEnabled by mutableStateOf(RecPrefs.enabled(app)); private set
    var recRes by mutableIntStateOf(RecPrefs.res(app)); private set
    var recFps by mutableIntStateOf(RecPrefs.fps(app)); private set
    var recMic by mutableStateOf(RecPrefs.mic(app)); private set
    var recInternal by mutableStateOf(RecPrefs.internal(app)); private set
    var recLandscape by mutableStateOf(RecPrefs.landscape(app)); private set
    var recCaps by mutableStateOf<RecCaps?>(null); private set

    init {
        refreshRam()
        vulkanOk = app.packageManager.hasSystemFeature("android.hardware.vulkan.version")
        try {
            val dm = app.getSystemService(DisplayManager::class.java)
            val modes = dm.getDisplay(Display.DEFAULT_DISPLAY).supportedModes
            supportedRates = modes.map { it.refreshRate.roundToInt() }.filter { it in 20..300 }.toSet()
        } catch (_: Throwable) {
        }

        // restore the selected game
        val pkg = UiPrefs.appPkg(app)
        if (pkg != null && app.packageManager.getLaunchIntentForPackage(pkg) != null) {
            selectedApp = AppEntry(pkg, UiPrefs.appLabel(app) ?: pkg, UiPrefs.appIsGame(app))
        }

        viewModelScope.launch {
            recCaps = withContext(Dispatchers.Default) {
                try {
                    RecCaps.probe(app)
                } catch (_: Throwable) {
                    null
                }
            }
        }
    }

    fun selectLevel(l: Level) {
        level = l
        config = Optimizer.configFor(l)
    }

    fun edit(new: BoostConfig) {
        config = new
        level = Level.values().firstOrNull { Optimizer.configFor(it) == new }
    }

    // ------------------------------------------------------------------ apply / reset

    /** Opens the "Apply?" confirmation. Nothing changes until the user confirms. */
    fun requestApply(cfg: BoostConfig = config) {
        pending = cfg
    }

    fun dismissPending() {
        pending = null
    }

    fun confirmApply() {
        val cfg = pending ?: return
        pending = null
        val sel = selectedApp
        val play = launchAfter && sel != null
        viewModelScope.launch {
            busy = true
            try {
                log = withTimeoutOrNull(90_000) { Optimizer.apply(app, cfg, sel?.pkg) }
                    ?: listOf("✘ Took too long and was stopped. Tap RESET if anything feels off.")
            } finally {
                hasBackup = BackupStore.has(app)
                refreshRam()
                busy = false
            }

            val ok = log.count { it.startsWith("✔") }
            val bad = log.count { it.startsWith("✘") }
            val title = if (bad == 0) "Boost successful ✔" else "Boost done"
            val text = buildString {
                append("$ok applied")
                if (bad > 0) append(" • $bad skipped")
                if (play && sel != null) append(" • opening ${sel.label}")
            }
            Notifier.show(app, title, text, if (play) sel?.pkg else null)

            if (play && sel != null) {
                launchApp(sel.pkg)
            } else if (log.any { it.startsWith("✔ Resolution") }) {
                startKeepCountdown()
            }
        }
    }

    private fun launchApp(pkg: String) {
        try {
            val i: Intent? = app.packageManager.getLaunchIntentForPackage(pkg)
            if (i != null) {
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                app.startActivity(i)
            }
        } catch (_: Throwable) {
        }
    }

    fun confirmResetNow() {
        confirmReset = false
        keepJob?.cancel()
        keepSeconds = 0
        viewModelScope.launch {
            busy = true
            try {
                log = withTimeoutOrNull(90_000) { Optimizer.reset(app) }
                    ?: listOf("✘ Reset took too long and was stopped. Try again.")
            } finally {
                hasBackup = BackupStore.has(app)
                refreshRam()
                busy = false
            }
        }
    }

    // ---- resolution safety net: revert by itself unless the user taps KEEP ----

    private fun startKeepCountdown() {
        keepJob?.cancel()
        keepJob = viewModelScope.launch {
            for (s in 15 downTo 1) {
                keepSeconds = s
                delay(1000)
            }
            keepSeconds = 0
            doRevert()
        }
    }

    private suspend fun doRevert() {
        Optimizer.restoreResolution(app)
        log = log + "↩ Resolution reverted to the original"
    }

    fun keepResolution() {
        keepJob?.cancel()
        keepSeconds = 0
    }

    fun revertResolutionNow() {
        keepJob?.cancel()
        keepSeconds = 0
        viewModelScope.launch { doRevert() }
    }

    fun refreshDisplay() {
        if (ShizukuHelper.state.value != ShizukuState.READY) return
        viewModelScope.launch {
            angleOk = Optimizer.angleAvailable()
            Optimizer.readDisplay()?.let {
                nativeShort = it.shortSide
                nativeText = "Screen ${it.w}×${it.h}  •  native ${it.shortSide}p"
            }
        }
    }

    fun refreshRam() {
        val am = app.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        ramText = "RAM free ${Formatter.formatFileSize(app, mi.availMem)} / ${Formatter.formatFileSize(app, mi.totalMem)}"
    }

    // ------------------------------------------------------------------ overlay sizes

    fun setScale(key: String, v: Float) {
        val s = (v * 10).roundToInt() / 10f
        UiPrefs.setScale(app, key, s)
        when (key) {
            "fps" -> scaleFps = s
            "detail" -> scaleDetail = s
            "thermal" -> scaleThermal = s
        }
    }

    // ------------------------------------------------------------------ game / app picker

    fun loadApps() {
        if (apps.isNotEmpty() || appsLoading) return
        appsLoading = true
        viewModelScope.launch {
            val list = withContext(Dispatchers.Default) {
                val pm = app.packageManager
                val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
                pm.queryIntentActivities(intent, 0)
                    .mapNotNull { ri ->
                        val ai = ri.activityInfo.applicationInfo
                        if (ai.packageName == app.packageName) null
                        else AppEntry(ai.packageName, ri.loadLabel(pm).toString(), Optimizer.isGame(ai))
                    }
                    .distinctBy { it.pkg }
                    .sortedWith(compareByDescending<AppEntry> { it.isGame }.thenBy { it.label.lowercase() })
            }
            apps = list
            appsLoading = false
        }
    }

    fun selectApp(e: AppEntry?) {
        selectedApp = e
        UiPrefs.setApp(app, e?.pkg, e?.label, e?.isGame ?: false)
    }

    fun setLaunchAfter(v: Boolean) {
        launchAfter = v
        UiPrefs.setLaunchAfter(app, v)
    }

    // ------------------------------------------------------------------ low ping

    /** Measures how fast each DNS server answers, then picks the fastest one. */
    fun testPing() {
        if (pingBusy) return
        pingBusy = true
        viewModelScope.launch {
            val res = withContext(Dispatchers.IO) {
                DnsChoice.values().associateWith { tcpPing(it.ip) }
            }
            pings = res
            pingBusy = false
            val best = res.filterValues { it != null }.minByOrNull { it.value ?: Int.MAX_VALUE }?.key
            if (best != null) edit(config.copy(dns = best))
        }
    }

    private fun tcpPing(ip: String): Int? {
        val times = ArrayList<Long>()
        repeat(3) {
            val t0 = System.nanoTime()
            try {
                Socket().use { s ->
                    s.connect(InetSocketAddress(ip, 853), 1500)
                    times.add((System.nanoTime() - t0) / 1_000_000)
                }
            } catch (_: Throwable) {
            }
        }
        return if (times.isEmpty()) null else times.average().roundToInt()
    }

    // ------------------------------------------------------------------ screen recorder

    fun setRecEnabled(v: Boolean) {
        recEnabled = v
        RecPrefs.setEnabled(app, v)
        if (v) RecorderService.showReady(app) else RecorderService.hideReady(app)
    }

    fun setRecRes(v: Int) {
        recRes = v
        RecPrefs.setRes(app, v)
        RecorderService.refreshReady(app)
    }

    fun setRecFps(v: Int) {
        recFps = v
        RecPrefs.setFps(app, v)
        RecorderService.refreshReady(app)
    }

    fun setRecMic(v: Boolean) {
        recMic = v
        RecPrefs.setMic(app, v)
        RecorderService.refreshReady(app)
    }

    fun setRecInternal(v: Boolean) {
        recInternal = v
        RecPrefs.setInternal(app, v)
        RecorderService.refreshReady(app)
    }

    fun setRecLandscape(v: Boolean) {
        recLandscape = v
        RecPrefs.setLandscape(app, v)
    }
}

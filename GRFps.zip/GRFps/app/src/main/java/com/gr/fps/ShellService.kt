package com.gr.fps

import kotlin.system.exitProcess

/**
 * Runs inside the Shizuku user-service process (shell / adb privileges).
 * Executes a shell command and returns its combined output.
 */
class ShellService : IShellService.Stub() {

    override fun destroy() {
        exitProcess(0)
    }

    override fun exec(command: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("sh", "-c", command))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            (out + err).trim()
        } catch (e: Exception) {
            "ERR: ${e.message}"
        }
    }
}

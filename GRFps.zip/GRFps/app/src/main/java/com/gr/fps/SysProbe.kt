package com.gr.fps

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.BatteryManager
import kotlin.math.max

data class SysStats(
    val cpuTotal: Int?,
    val cpuMaxCore: Int?,
    val clockPct: Int?,
    val curMhz: Int?,
    val gpu: Int?,
    val cpuTemp: Float?,
    val gpuTemp: Float?,
    val batTemp: Float?,
    val thermalStatus: Int?,
    val ramFreeMb: Long,
    val ramTotalMb: Long,
    val verdict: String,
    val level: Int            // 0 = fine, 1 = warning, 2 = bad
)

/**
 * Reads real CPU / GPU load, clocks and temperatures (via Shizuku) and says what is holding the phone back.
 * Anything the phone doesn't expose is reported as unknown, never invented.
 */
object SysProbe {
    private var prev: Map<String, LongArray> = emptyMap()
    private var tick = 0
    private var cpuT: Float? = null
    private var gpuT: Float? = null
    private var status: Int? = null

    fun reset() {
        prev = emptyMap()
        tick = 0
        cpuT = null
        gpuT = null
        status = null
    }

    private const val FAST =
        "grep '^cpu' /proc/stat; " +
            "echo '#FREQ'; for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/scaling_cur_freq; do cat \$f 2>/dev/null; done; " +
            "echo '#MAX'; for f in /sys/devices/system/cpu/cpu[0-9]*/cpufreq/cpuinfo_max_freq; do cat \$f 2>/dev/null; done; " +
            "echo '#GPU'; for f in /sys/class/kgsl/kgsl-3d0/gpu_busy_percentage /sys/class/kgsl/kgsl-3d0/devfreq/gpu_load " +
            "/sys/kernel/gpu/gpu_busy /sys/class/kgsl/kgsl-3d0/gpubusy; do if [ -r \$f ]; then cat \$f 2>/dev/null; break; fi; done; " +
            "for f in /sys/class/devfreq/*mali*/load; do if [ -r \$f ]; then cat \$f 2>/dev/null; break; fi; done"

    private const val SLOW =
        "dumpsys thermalservice 2>/dev/null | grep -E 'Temperature\\{|Thermal Status'; " +
            "echo '#ZONES'; for z in /sys/class/thermal/thermal_zone*; do " +
            "echo \"\$(cat \$z/type 2>/dev/null) \$(cat \$z/temp 2>/dev/null)\"; done"

    suspend fun sample(ctx: Context): SysStats {
        val ready = ShizukuHelper.state.value == ShizukuState.READY
        var cpuTotal: Int? = null
        var cpuMax: Int? = null
        var clockPct: Int? = null
        var curMhz: Int? = null
        var gpu: Int? = null

        if (ready) {
            val fast = ShizukuHelper.exec(FAST, 4_000)
            val cpuLines = HashMap<String, LongArray>()
            val cur = ArrayList<Long>()
            val max = ArrayList<Long>()
            val gpuLines = ArrayList<String>()
            var mode = 0
            for (raw in fast.lines()) {
                val line = raw.trim()
                when {
                    line == "#FREQ" -> mode = 1
                    line == "#MAX" -> mode = 2
                    line == "#GPU" -> mode = 3
                    line.isEmpty() -> {}
                    mode == 0 && line.startsWith("cpu") -> {
                        val parts = line.split(Regex("\\s+"))
                        val nums = parts.drop(1).mapNotNull { it.toLongOrNull() }
                        if (nums.size >= 4) cpuLines[parts[0]] = nums.toLongArray()
                    }
                    mode == 1 -> line.toLongOrNull()?.let { cur.add(it) }
                    mode == 2 -> line.toLongOrNull()?.let { max.add(it) }
                    mode == 3 -> gpuLines.add(line)
                }
            }

            fun usage(key: String): Int? {
                val now = cpuLines[key] ?: return null
                val old = prev[key] ?: return null
                val total = now.sum() - old.sum()
                if (total <= 0) return null
                val idle = (now[3] + now.getOrElse(4) { 0L }) - (old[3] + old.getOrElse(4) { 0L })
                return (100.0 * (1.0 - idle.toDouble() / total)).toInt().coerceIn(0, 100)
            }
            cpuTotal = usage("cpu")
            cpuMax = cpuLines.keys.filter { it != "cpu" }.mapNotNull { usage(it) }.maxOrNull()
            prev = cpuLines

            if (cur.isNotEmpty() && max.isNotEmpty() && max.sum() > 0) {
                clockPct = (cur.sum() * 100 / max.sum()).toInt().coerceIn(0, 100)
                curMhz = (cur.max() / 1000).toInt()
            }

            gpuLines.firstOrNull()?.let { line ->
                val two = Regex("^(\\d+)\\s+(\\d+)$").find(line)
                gpu = if (two != null) {
                    val busy = two.groupValues[1].toLong()
                    val tot = two.groupValues[2].toLong()
                    if (tot > 0) (busy * 100 / tot).toInt().coerceIn(0, 100) else null
                } else {
                    Regex("\\d+").find(line)?.value?.toIntOrNull()?.coerceIn(0, 100)
                }
            }

            if (tick % 3 == 0) readThermal()
            tick++
        }

        val batTemp = batteryTemp(ctx)
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        val freeMb = mi.availMem / (1024 * 1024)
        val totalMb = mi.totalMem / (1024 * 1024)
        val lowRam = mi.lowMemory || (totalMb > 0 && freeMb * 100 / totalMb < 10)

        val (verdict, level) = judge(
            ready, cpuTotal, cpuMax, clockPct, gpu, cpuT, gpuT, batTemp, status, lowRam
        )
        return SysStats(
            cpuTotal, cpuMax, clockPct, curMhz, gpu, cpuT, gpuT, batTemp, status,
            freeMb, totalMb, verdict, level
        )
    }

    private suspend fun readThermal() {
        val out = ShizukuHelper.exec(SLOW, 6_000)
        var cpu: Float? = null
        var gpu: Float? = null
        var zones = false
        for (raw in out.lines()) {
            val line = raw.trim()
            if (line == "#ZONES") {
                zones = true
                continue
            }
            if (!zones) {
                Regex("Thermal Status:\\s*(\\d+)").find(line)?.let { status = it.groupValues[1].toIntOrNull() }
                val m = Regex("mValue=([-0-9.]+),\\s*mType=(\\d+)").find(line)
                if (m != null) {
                    val v = m.groupValues[1].toFloatOrNull()
                    if (v != null && v > 0f) {
                        when (m.groupValues[2]) {
                            "0" -> cpu = max(cpu ?: v, v)
                            "1" -> gpu = max(gpu ?: v, v)
                        }
                    }
                }
            } else {
                // fallback: "<type> <temp>"
                val parts = line.split(" ")
                if (parts.size >= 2) {
                    val name = parts[0].lowercase()
                    var v = parts[1].toFloatOrNull() ?: continue
                    if (v > 1000f) v /= 1000f
                    if (v <= 0f || v > 150f) continue
                    if (cpu == null && Regex("cpu|soc|cluster|big|little|tsens").containsMatchIn(name)) cpu = v
                    if (gpu == null && name.contains("gpu")) gpu = v
                }
            }
        }
        cpuT = cpu
        gpuT = gpu
    }

    private fun batteryTemp(ctx: Context): Float? {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return null
        val t = i.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) null else t / 10f
    }

    private fun judge(
        ready: Boolean, cpuTotal: Int?, cpuMax: Int?, clockPct: Int?, gpu: Int?,
        cpuT: Float?, gpuT: Float?, batT: Float?, status: Int?, lowRam: Boolean
    ): Pair<String, Int> {
        val issues = ArrayList<String>()
        var level = 0

        val cpuHeavy = (cpuTotal ?: 0) >= 75 || (cpuMax ?: 0) >= 92
        val clockLow = clockPct != null && cpuHeavy && clockPct < 55
        val tempHigh = (cpuT ?: 0f) >= 45f || (gpuT ?: 0f) >= 45f || (batT ?: 0f) >= 41f

        if ((status ?: 0) >= 2 || (clockLow && tempHigh)) {
            issues += "THERMAL THROTTLE"
            level = 2
        } else if (clockLow) {
            issues += "CPU CLOCK LIMITED"
            level = max(level, 1)
        } else if ((batT ?: 0f) >= 43f) {
            issues += "PHONE HOT"
            level = max(level, 1)
        }
        if (lowRam) {
            issues += "RAM LOW"
            level = max(level, 1)
        }
        if ((cpuMax ?: 0) >= 92 || (cpuTotal ?: 0) >= 90) {
            issues += if ((cpuTotal ?: 0) < 70) "CPU BOTTLENECK (1 core maxed)" else "CPU BOTTLENECK"
            level = 2
        }
        if ((gpu ?: 0) >= 92) {
            issues += "GPU BOTTLENECK"
            level = 2
        }

        if (issues.isEmpty()) {
            return if (!ready) "Connect Shizuku for CPU/GPU info" to 0
            else "NO BOTTLENECK" to 0
        }
        return issues.take(2).joinToString(" + ") to level
    }
}

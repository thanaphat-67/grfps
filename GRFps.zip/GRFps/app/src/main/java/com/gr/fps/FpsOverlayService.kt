package com.gr.fps

import android.content.Context
import android.view.View
import android.widget.TextView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext

/** Simple FPS counter. */
class FpsOverlayService : BaseOverlayService() {

    companion object {
        val running = MutableStateFlow(false)
    }

    override val notifId = 2
    override val channelId = "gr_fps_meter"
    override val title = "GR FPS meter is running"
    override val scaleKey = "fps"
    override val stopAction = "com.gr.fps.STOP_FPS"
    override val startY = 120
    override val tickMs = 500L

    private var tv: TextView? = null

    override fun createContent(ctx: Context): View {
        val t = overlayText(ctx)
        t.text = "-- FPS"
        t.setBackgroundColor(0xAA000000.toInt())
        tv = t
        return t
    }

    override fun applyScale(scale: Float) {
        val t = tv ?: return
        t.textSize = 16f * scale
        val h = dpOf(this, 9f * scale).toInt()
        val v = dpOf(this, 4f * scale).toInt()
        t.setPadding(h, v, h, v)
    }

    override fun onStarted() = FpsHub.acquire()
    override fun onStopped() = FpsHub.release()
    override fun setRunning(v: Boolean) {
        running.value = v
    }

    override suspend fun onTick() {
        val ready = ShizukuHelper.state.value == ShizukuState.READY
        val s = FpsHub.stats.value
        val text = when {
            !ready -> "Shizuku?"
            s == null -> "-- FPS"
            else -> "${s.fps} FPS"
        }
        val color = when {
            s == null || !ready -> 0xFFFFFFFF.toInt()
            s.fps >= 50 -> 0xFF39FF14.toInt()
            s.fps >= 30 -> 0xFFFFEB3B.toInt()
            else -> 0xFFFF5252.toInt()
        }
        withContext(Dispatchers.Main) {
            tv?.text = text
            tv?.setTextColor(color)
        }
    }
}

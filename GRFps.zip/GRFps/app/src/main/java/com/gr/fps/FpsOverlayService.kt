package com.gr.fps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Floating FPS counter drawn on top of any app. Drag it to move it. */
class FpsOverlayService : Service() {

    companion object {
        val running = MutableStateFlow(false)
        private const val ACTION_STOP = "com.gr.fps.STOP_FPS"
        private const val CHANNEL = "gr_fps_meter"
        private const val NOTIF_ID = 2

        fun start(ctx: Context) {
            ctx.startForegroundService(Intent(ctx, FpsOverlayService::class.java))
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, FpsOverlayService::class.java))
        }
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var wm: WindowManager? = null
    private var view: TextView? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
        if (view == null) addOverlay()
        if (job == null) startLoop()
        running.value = true
        return START_NOT_STICKY
    }

    private fun addOverlay() {
        val manager = getSystemService(WindowManager::class.java)
        val tv = TextView(this).apply {
            text = "-- FPS"
            setTextColor(0xFF39FF14.toInt())
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setPadding(26, 10, 26, 10)
            setBackgroundColor(0xAA000000.toInt())
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 40
            y = 120
        }

        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = lp.x; startY = lp.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = startX + (e.rawX - touchX).toInt()
                    lp.y = startY + (e.rawY - touchY).toInt()
                    manager.updateViewLayout(tv, lp)
                    true
                }
                else -> false
            }
        }
        manager.addView(tv, lp)
        wm = manager
        view = tv
    }

    private fun startLoop() {
        job = scope.launch {
            while (isActive) {
                val ready = ShizukuHelper.state.value == ShizukuState.READY
                val fps = if (ready) FpsProbe.sample() else null
                val text = when {
                    !ready -> "Shizuku?"
                    fps == null -> "-- FPS"
                    else -> "$fps FPS"
                }
                val color = when {
                    fps == null -> 0xFFFFFFFF.toInt()
                    fps >= 50 -> 0xFF39FF14.toInt()
                    fps >= 30 -> 0xFFFFEB3B.toInt()
                    else -> 0xFFFF5252.toInt()
                }
                withContext(Dispatchers.Main) {
                    view?.text = text
                    view?.setTextColor(color)
                }
                delay(1000)
            }
        }
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "FPS meter", NotificationManager.IMPORTANCE_LOW))
        val stopIntent = PendingIntent.getService(
            this, 0,
            Intent(this, FpsOverlayService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val stopAction = Notification.Action.Builder(
            Icon.createWithResource(this, R.drawable.ic_bolt), "Stop", stopIntent
        ).build()
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("GR FPS meter is running")
            .setContentText("Tap Stop to hide the FPS counter")
            .addAction(stopAction)
            .setOngoing(true)
            .build()
    }

    override fun onDestroy() {
        job?.cancel()
        scope.cancel()
        try {
            view?.let { wm?.removeView(it) }
        } catch (_: Throwable) {
        }
        view = null
        running.value = false
        super.onDestroy()
    }
}

package com.gr.fps

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat

/**
 * Invisible helper: asks for the microphone / screen-capture permission, then starts the recorder.
 * Android shows its own "start recording?" popup every time; that can't be skipped.
 */
class CaptureRequestActivity : ComponentActivity() {

    private var audioOk = false

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, RecorderService::class.java)
                    .setAction(RecorderService.ACTION_START)
                    .putExtra(RecorderService.EXTRA_CODE, r.resultCode)
                    .putExtra(RecorderService.EXTRA_DATA, data)
                    .putExtra(RecorderService.EXTRA_AUDIO_OK, audioOk)
                ContextCompat.startForegroundService(this, i)
            }
            finish()
        }

    private val audioLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            audioOk = granted
            askProjection()
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (RecorderService.state.value != RecState.IDLE) {
            finish()
            return
        }
        val needAudio = RecPrefs.mic(this) || RecPrefs.internal(this)
        if (needAudio) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                audioOk = true
                askProjection()
            } else {
                audioLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        } else {
            askProjection()
        }
    }

    private fun askProjection() {
        val mpm = getSystemService(MediaProjectionManager::class.java)
        projectionLauncher.launch(mpm.createScreenCaptureIntent())
    }
}

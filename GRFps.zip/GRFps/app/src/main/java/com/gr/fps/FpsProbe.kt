package com.gr.fps

/**
 * Real FPS of whatever app is on screen.
 *
 * Android's compositor (SurfaceFlinger) keeps the presentation time of the last ~128 frames of every
 * layer. We find the layer of the focused app and count how many frames were really shown during the
 * last second. Nothing is estimated or faked: if the phone doesn't expose this, sample() returns null.
 */
object FpsProbe {
    private var pkg: String? = null
    private var layer: String? = null
    private var tick = 0

    /** @return frames per second, 0 if the screen is static, null if it can't be measured. */
    suspend fun sample(): Int? {
        if (tick++ % 3 == 0 || layer == null) refreshTarget()
        val l = layer ?: return null
        val out = ShizukuHelper.exec("dumpsys SurfaceFlinger --latency '$l'", 5_000)
        val now = System.nanoTime()
        return parse(out, now)
    }

    private suspend fun refreshTarget() {
        val focus = ShizukuHelper.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", 5_000)
        val p = Regex("""u\d+\s+([A-Za-z0-9_.]+)/""").find(focus)?.groupValues?.get(1)
        if (p != pkg) {
            pkg = p
            layer = null
        }
        if (p != null && layer == null) {
            val all = ShizukuHelper.exec("dumpsys SurfaceFlinger --list", 5_000)
                .lines().filter { it.contains(p) }
            // Games draw on a SurfaceView; normal apps on their main window layer.
            layer = all.firstOrNull { it.contains("SurfaceView") && it.contains("BLAST") }
                ?: all.firstOrNull { it.contains("SurfaceView") && !it.contains("Background") }
                ?: all.firstOrNull { it.contains("$p/") && it.endsWith("#0") }
        }
    }

    private fun parse(out: String, nowNs: Long): Int? {
        // line 0 = refresh period; then rows of: desiredPresent  actualPresent  frameReady
        val times = out.lines().drop(1).mapNotNull { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 3) parts[1].toLongOrNull() else null
        }.filter { it > 0 && it != Long.MAX_VALUE }
        if (times.size < 2) return null

        val newest = times.max()
        if (nowNs - newest > 1_500_000_000L) return 0   // nothing drawn for 1.5s -> static screen

        val window = times.filter { it >= newest - 1_000_000_000L }
        if (window.size < 2) return 0
        val span = window.max() - window.min()
        if (span <= 0) return null
        return ((window.size - 1) * 1_000_000_000.0 / span).toInt()
    }
}

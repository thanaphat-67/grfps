package com.gr.fps

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.ceil
import kotlin.math.max

/** Real frame statistics of the app currently on screen. */
data class FrameStats(
    val fps: Int,              // frames shown during the last second
    val avg: Int,              // average fps over the last ~10 s
    val low1: Int,             // "1% low": fps of the slowest 1% of frames
    val frameMs: List<Float>,  // last frame times in ms (for the graph)
    val avgMs: Float,          // average frame time
    val stutters: Int,         // frames that took more than 2x the average
    val pkg: String?
)

/**
 * Android's compositor (SurfaceFlinger) keeps the presentation time of the last ~128 frames of every
 * layer. We find the layer of the focused app and read those timestamps. Nothing is estimated or faked:
 * if the phone doesn't expose this, sample() returns null.
 */
object FpsProbe {
    private var pkg: String? = null
    private var layer: String? = null
    private var tick = 0
    private val history = ArrayDeque<Long>()

    fun reset() {
        pkg = null
        layer = null
        tick = 0
        history.clear()
    }

    suspend fun sample(): FrameStats? {
        if (tick++ % 3 == 0 || layer == null) refreshTarget()
        val l = layer ?: return null
        val out = ShizukuHelper.exec("dumpsys SurfaceFlinger --latency '$l'", 5_000)
        val times = parseTimes(out) ?: return null
        return ingest(times, System.nanoTime())
    }

    private suspend fun refreshTarget() {
        val focus = ShizukuHelper.exec("dumpsys window | grep -E 'mCurrentFocus|mFocusedApp'", 5_000)
        val p = Regex("""u\d+\s+([A-Za-z0-9_.]+)/""").find(focus)?.groupValues?.get(1)
        if (p != pkg) {
            pkg = p
            layer = null
            history.clear()
        }
        if (p != null && layer == null) {
            val all = ShizukuHelper.exec("dumpsys SurfaceFlinger --list", 5_000)
                .lines().filter { it.contains(p) }
            // Games draw on a SurfaceView; normal apps on their main window layer.
            layer = all.firstOrNull { it.contains("SurfaceView") && it.contains("BLAST") }
                ?: all.firstOrNull { it.contains("SurfaceView") && !it.contains("Background") }
                ?: all.firstOrNull { it.contains("$p/") && it.endsWith("#0") }
        }
    }

    private fun parseTimes(out: String): List<Long>? {
        // line 0 = refresh period; then rows of: desiredPresent  actualPresent  frameReady
        val times = out.lines().drop(1).mapNotNull { line ->
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size >= 3) parts[1].toLongOrNull() else null
        }.filter { it > 0 && it != Long.MAX_VALUE }
        return if (times.size < 2) null else times
    }

    private fun ingest(times: List<Long>, nowNs: Long): FrameStats? {
        var cur = history.lastOrNull() ?: Long.MIN_VALUE
        for (t in times.sorted()) {
            if (t > cur) {
                history.addLast(t)
                cur = t
            }
        }
        if (history.size < 2) return null
        val newest = history.last()
        while (history.isNotEmpty() && newest - history.first() > 10_000_000_000L) history.removeFirst()

        // nothing drawn for 1.5 s -> static screen
        if (nowNs - newest > 1_500_000_000L) return FrameStats(0, 0, 0, emptyList(), 0f, 0, pkg)

        val recent = history.filter { it >= newest - 1_000_000_000L }
        val fps = if (recent.size >= 2) {
            val span = recent.last() - recent.first()
            if (span > 0) ((recent.size - 1) * 1_000_000_000.0 / span).toInt() else 0
        } else 0

        val arr = history.toLongArray()
        val iv = ArrayList<Float>(arr.size)
        for (i in 1 until arr.size) {
            val d = (arr[i] - arr[i - 1]) / 1_000_000f
            if (d < 1000f) iv.add(d)
        }
        if (iv.isEmpty()) return FrameStats(fps, fps, fps, emptyList(), 0f, 0, pkg)

        val mean = iv.average().toFloat()
        val avg = if (mean > 0f) (1000f / mean).toInt() else 0
        val worstN = max(1, ceil(iv.size * 0.01).toInt())
        val worstMean = iv.sortedDescending().take(worstN).average().toFloat()
        val low1 = if (worstMean > 0f) (1000f / worstMean).toInt() else 0
        val stutters = iv.count { it > mean * 2f }
        return FrameStats(fps, avg, low1, iv.takeLast(60), mean, stutters, pkg)
    }
}

/** One shared poller; the three FPS-related overlays just subscribe to it. */
object FpsHub {
    val stats = MutableStateFlow<FrameStats?>(null)

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private var users = 0

    @Synchronized
    fun acquire() {
        users++
        if (job == null) {
            job = scope.launch {
                FpsProbe.reset()
                while (isActive) {
                    stats.value = try {
                        if (ShizukuHelper.state.value == ShizukuState.READY) FpsProbe.sample() else null
                    } catch (_: Throwable) {
                        null
                    }
                    delay(1000)
                }
            }
        }
    }

    @Synchronized
    fun release() {
        users = (users - 1).coerceAtLeast(0)
        if (users == 0) {
            job?.cancel()
            job = null
            stats.value = null
        }
    }
}

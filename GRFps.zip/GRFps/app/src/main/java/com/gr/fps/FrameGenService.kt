package com.gr.fps

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.content.res.Configuration
import android.graphics.PixelFormat
import android.graphics.drawable.Icon
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.WindowManager
import android.widget.Toast
import androidx.core.app.ServiceCompat
import androidx.core.content.IntentCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext

/**
 * Android blocks touches that pass through another app's overlay. The frame-generation overlay is full-screen
 * and must let touches through to the game, so while it runs we switch that check off (needs Shizuku) and put
 * the original value back afterwards.
 */
object FgTouch {
    private const val KEY = "fg_touch_orig"

    private fun p(c: Context) = UiPrefs.prefs(c)

    suspend fun disableBlock(c: Context): Boolean {
        if (ShizukuHelper.state.value != ShizukuState.READY) return false
        if (!p(c).contains(KEY)) {
            val o = ShizukuHelper.exec("settings get global block_untrusted_touches").trim()
                .lines().lastOrNull().orEmpty().ifEmpty { "null" }
            p(c).edit().putString(KEY, o).apply()
        }
        ShizukuHelper.exec("settings put global block_untrusted_touches 0")
        return true
    }

    fun pending(c: Context) = p(c).contains(KEY)

    suspend fun restore(c: Context) {
        val o = p(c).getString(KEY, null) ?: return
        if (ShizukuHelper.state.value != ShizukuState.READY) return
        ShizukuHelper.exec(
            if (o == "null") "settings delete global block_untrusted_touches"
            else "settings put global block_untrusted_touches $o"
        )
        p(c).edit().remove(KEY).apply()
    }
}

/**
 * Frame generation: captures the chosen app's window (Android 14 "A single app" mode, so our own overlay is
 * not captured), builds in-between frames on the GPU and shows the result in a full-screen overlay.
 */
class FrameGenService : Service() {

    companion object {
        const val ACTION_START = "com.gr.fps.FG_START"
        const val ACTION_STOP = "com.gr.fps.FG_STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"

        private const val CH = "gr_fg"
        private const val ID = 20

        val running = MutableStateFlow(false)
        val stats = MutableStateFlow("")
    }

    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private var projection: MediaProjection? = null
    private var renderer: FrameGenRenderer? = null
    private var vd: VirtualDisplay? = null
    private var view: SurfaceView? = null
    private var wm: WindowManager? = null
    private var stopping = false
    private var line = "starting…"
    private var dpi = 400

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> handleStart(intent)
            ACTION_STOP -> stopAll()
            else -> if (!running.value) stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun channel() {
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel(CH, "Frame generation", NotificationManager.IMPORTANCE_LOW))
    }

    private fun notification(): Notification {
        val flags = PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        val open = PendingIntent.getActivity(
            this, 201,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
            flags
        )
        val stop = PendingIntent.getService(
            this, 202, Intent(this, FrameGenService::class.java).setAction(ACTION_STOP), flags
        )
        return Notification.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_bolt)
            .setContentTitle("GR FPS Frame Generation")
            .setContentText(line)
            .setOngoing(true)
            .setShowWhen(false)
            .setContentIntent(open)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, R.drawable.ic_stop), "Stop", stop).build())
            .build()
    }

    private fun post() {
        getSystemService(NotificationManager::class.java).notify(ID, notification())
    }

    private fun screenSize(): Pair<Int, Int> {
        val w = getSystemService(WindowManager::class.java)
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = w.currentWindowMetrics.bounds
            b.width() to b.height()
        } else {
            val m = android.util.DisplayMetrics()
            @Suppress("DEPRECATION")
            w.defaultDisplay.getRealMetrics(m)
            m.widthPixels to m.heightPixels
        }
    }

    private fun refreshHz(): Float {
        return try {
            @Suppress("DEPRECATION")
            val r = getSystemService(WindowManager::class.java).defaultDisplay.refreshRate
            if (r in 30f..240f) r else 60f
        } catch (_: Throwable) {
            60f
        }
    }

    private fun fail(msg: String) {
        main.post { Toast.makeText(applicationContext, msg, Toast.LENGTH_LONG).show() }
        stopAll()
    }

    private fun handleStart(intent: Intent) {
        if (running.value) return
        channel()
        try {
            ServiceCompat.startForeground(this, ID, notification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } catch (e: Exception) {
            fail("Couldn't start: ${e.message}")
            return
        }
        val code = intent.getIntExtra(EXTRA_CODE, 0)
        val data = IntentCompat.getParcelableExtra(intent, EXTRA_DATA, Intent::class.java)
        if (data == null) {
            fail("Screen capture wasn't allowed")
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            fail("Allow \"Display over other apps\" first")
            return
        }
        running.value = true

        scope.launch {
            val touchOk = FgTouch.disableBlock(applicationContext)
            withContext(Dispatchers.Main) {
                if (!touchOk) {
                    fail("Connect Shizuku first (needed so touches reach the game)")
                } else {
                    begin(code, data)
                }
            }
        }
    }

    private fun begin(code: Int, data: Intent) {
        if (stopping) return
        val mp: MediaProjection? = try {
            getSystemService(MediaProjectionManager::class.java).getMediaProjection(code, data)
        } catch (e: Exception) {
            null
        }
        if (mp == null) {
            fail("Couldn't start screen capture")
            return
        }
        projection = mp
        mp.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                main.post { stopAll() }
            }
        }, main)

        val (w, h) = screenSize()
        dpi = resources.displayMetrics.densityDpi
        val quality = UiPrefs.fgQuality(this)
        val vsyncMs = 1000f / refreshHz()

        val sv = SurfaceView(this)
        view = sv
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.OPAQUE
        )
        if (Build.VERSION.SDK_INT >= 30) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
        } else if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
        }
        lp.title = "GRFrameGen"

        sv.holder.addCallback(object : SurfaceHolder.Callback {
            override fun surfaceCreated(holder: SurfaceHolder) {
                startRenderer(holder, w, h, quality, vsyncMs)
            }

            override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

            override fun surfaceDestroyed(holder: SurfaceHolder) {
                if (!stopping && running.value) main.post { stopAll() }
            }
        })

        try {
            wm = getSystemService(WindowManager::class.java)
            wm!!.addView(sv, lp)
        } catch (e: Exception) {
            fail("Couldn't show the overlay: ${e.message}")
            return
        }
        line = "choose the game in the Android popup, then play"
        post()
    }

    private fun startRenderer(holder: SurfaceHolder, w: Int, h: Int, quality: Int, vsyncMs: Float) {
        if (stopping || renderer != null) return
        val r = FrameGenRenderer(
            holder.surface, w, h, quality, vsyncMs,
            onStats = { src, out, delay ->
                main.post {
                    line = "$src → $out fps  •  extra delay ≈ $delay ms"
                    stats.value = line
                    if (!stopping) post()
                }
            },
            onError = { msg -> fail("Frame generation stopped: $msg") }
        )
        renderer = r
        r.start()
        if (!r.awaitReady()) {
            fail("This phone can't run frame generation: ${r.error() ?: "OpenGL ES 3 not available"}")
            return
        }
        try {
            vd = projection?.createVirtualDisplay(
                "GRFrameGen", w, h, dpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                r.inputSurface, null, main
            )
        } catch (e: Exception) {
            fail("Couldn't capture the screen: ${e.message}")
            return
        }
        if (vd == null) {
            fail("Couldn't capture the screen")
            return
        }
        line = "running — waiting for the first frames"
        post()

        // open the chosen game, if there is one
        val pkg = UiPrefs.appPkg(this)
        if (pkg != null) {
            try {
                packageManager.getLaunchIntentForPackage(pkg)?.let {
                    it.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    startActivity(it)
                }
            } catch (_: Throwable) {
            }
        }
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        val r = renderer ?: return
        val d = vd ?: return
        val (w, h) = screenSize()
        try {
            r.resize(w, h)
            d.resize(w, h, dpi)
        } catch (_: Throwable) {
        }
    }

    private fun stopAll() {
        if (stopping) return
        stopping = true
        running.value = false
        stats.value = ""
        try {
            vd?.release()
        } catch (_: Throwable) {
        }
        vd = null
        try {
            renderer?.stop()
        } catch (_: Throwable) {
        }
        renderer = null
        try {
            view?.let { wm?.removeViewImmediate(it) }
        } catch (_: Throwable) {
        }
        view = null
        try {
            projection?.stop()
        } catch (_: Throwable) {
        }
        projection = null
        scope.launch {
            try {
                FgTouch.restore(applicationContext)
            } catch (_: Throwable) {
            }
            withContext(Dispatchers.Main) {
                ServiceCompat.stopForeground(this@FrameGenService, ServiceCompat.STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
    }

    override fun onDestroy() {
        if (!stopping) {
            stopping = true
            running.value = false
            try { vd?.release() } catch (_: Throwable) {}
            try { renderer?.stop() } catch (_: Throwable) {}
            try { view?.let { wm?.removeViewImmediate(it) } } catch (_: Throwable) {}
            try { projection?.stop() } catch (_: Throwable) {}
        }
        super.onDestroy()
    }
}

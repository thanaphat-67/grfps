package com.gr.fps

import android.content.Context
import android.content.pm.ApplicationInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.net.InetAddress
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class Level(val label: String, val score: Int, val blurb: String) {
    VERY_LOW("Very Low", 20, "Light touch: slightly faster animations."),
    LOW("Low", 40, "Faster animations + free up RAM."),
    MEDIUM("Medium", 60, "RAM + background scans off + screen capped at 1080p."),
    HIGH("High", 80, "Adds Game Mode: Performance + screen 900p."),
    VERY_HIGH("Very High", 100, "Adds fixed performance mode (may get warm) + screen 720p.")
}

/** What to change. null / false = leave that part of the phone untouched. */
data class BoostConfig(
    val animScale: Float? = null,
    val killBackground: Boolean = false,
    val trimCache: Boolean = false,
    /** Lock the screen refresh rate to this many Hz. null = don't touch. */
    val refreshRate: Int? = null,
    /** Force the graphics API. null = don't touch. */
    val gfx: GfxApi? = null,
    /** Faster DNS for online games. null = don't touch. */
    val dns: DnsChoice? = null,
    val gameMode: Boolean = false,
    val disableScans: Boolean = false,
    val fixedPerf: Boolean = false,
    val dexopt: Boolean = false,
    /** Target screen resolution as short-edge pixels (360, 480, 720 ...). null = don't touch. */
    val resolution: Int? = null
)

enum class GfxApi(val label: String) { GLES("OpenGL ES"), VULKAN("Vulkan") }

/** Private-DNS (DNS-over-TLS) servers: host name used by Android + IP used for the speed test. */
enum class DnsChoice(val label: String, val host: String, val ip: String) {
    CLOUDFLARE("Cloudflare", "one.one.one.one", "1.1.1.1"),
    GOOGLE("Google", "dns.google", "8.8.8.8"),
    QUAD9("Quad9", "dns.quad9.net", "9.9.9.9")
}

data class DisplayInfo(val w: Int, val h: Int, val density: Int) {
    val shortSide: Int get() = min(w, h)
}

object Optimizer {

    /** Extra well-known games, used in addition to auto-detection. */
    private val KNOWN_GAMES = listOf(
        "com.miHoYo.GenshinImpact", "com.mihoyo.yuanshen",
        "com.HoYoverse.hkrpgoversea", "com.miHoYo.hkrpg",
        "com.kurogame.wutheringwaves.global", "com.kurogame.mingchao"
    )

    /** Settings we may touch (namespace:key). Their original values are backed up. */
    private val TRACKED = listOf(
        "global:window_animation_scale",
        "global:transition_animation_scale",
        "global:animator_duration_scale",
        "global:wifi_scan_always_enabled",
        "global:ble_scan_always_enabled",
        "system:min_refresh_rate",
        "system:peak_refresh_rate"
    )

    fun configFor(level: Level): BoostConfig = when (level) {
        Level.VERY_LOW -> BoostConfig(animScale = 0.75f)
        Level.LOW -> BoostConfig(animScale = 0.5f, killBackground = true)
        Level.MEDIUM -> BoostConfig(
            animScale = 0.5f, killBackground = true, disableScans = true, resolution = 1080
        )
        Level.HIGH -> BoostConfig(
            animScale = 0.5f, killBackground = true, disableScans = true,
            gameMode = true, resolution = 900
        )
        Level.VERY_HIGH -> BoostConfig(
            animScale = 0.35f, killBackground = true, disableScans = true,
            gameMode = true, fixedPerf = true, resolution = 720
        )
    }

    fun describe(c: BoostConfig): List<String> = buildList {
        c.animScale?.let { add("Animation speed ${fmt(it)}x") }
        if (c.killBackground) add("Free RAM (close background apps)")
        if (c.trimCache) add("Trim app caches")
        c.refreshRate?.let { add("Lock screen refresh rate to ${it}Hz") }
        c.gfx?.let { add("Graphics driver: ${it.label}") }
        c.dns?.let { add("Low ping: private DNS ${it.label}") }
        if (c.gameMode) add("Game Mode: Performance (all installed games)")
        if (c.disableScans) add("Stop background Wi-Fi/BLE scans")
        if (c.fixedPerf) add("Fixed performance mode")
        if (c.dexopt) add("Optimize apps (dexopt)")
        c.resolution?.let { add("Screen resolution ${it}p (whole phone gets blurrier)") }
        if (isEmpty()) add("Nothing selected")
    }

    private fun fmt(f: Float) = String.format(Locale.US, "%.2f", f)

    private fun isBad(out: String) =
        out.contains("ERR:") || out.contains("Exception") || out.contains("Unknown command") ||
            out.contains("failed", true) ||
            out.contains("not found", true) || out.contains("Error", true)

    private suspend fun step(log: MutableList<String>, label: String, vararg cmds: String) {
        var bad = false
        var slow = false
        for (cmd in cmds) {
            val out = ShizukuHelper.exec(cmd)
            if (out.contains("ERR: timeout")) slow = true else if (isBad(out)) bad = true
        }
        log += when {
            slow -> "✘ $label (took too long, skipped)"
            bad -> "✘ $label (not supported on this phone)"
            else -> "✔ $label"
        }
    }

    /** Every installed game (by Android's own "game" category) plus a few known titles. */
    fun detectGames(ctx: Context): List<String> {
        val apps = ctx.packageManager.getInstalledApplications(0)
        val installed = apps.map { it.packageName }.toSet()
        @Suppress("DEPRECATION")
        val detected = apps.filter {
            it.packageName != ctx.packageName &&
                (it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
        }.map { it.packageName }
        return (detected + KNOWN_GAMES.filter { it in installed }).distinct()
    }

    /** Physical screen size/density (what the panel really is, ignoring any override). */
    suspend fun readDisplay(): DisplayInfo? {
        val out = ShizukuHelper.exec("wm size; wm density")
        val size = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(out) ?: return null
        val dens = Regex("Physical density:\\s*(\\d+)").find(out) ?: return null
        return DisplayInfo(
            size.groupValues[1].toInt(),
            size.groupValues[2].toInt(),
            dens.groupValues[1].toInt()
        )
    }

    private fun even(x: Int) = x - x % 2

    /** True when the phone ships ANGLE (OpenGL ES running on top of Vulkan). */
    suspend fun angleAvailable(): Boolean {
        val out = ShizukuHelper.exec(
            "ls /system/lib64/egl/libGLESv2_angle.so /vendor/lib64/egl/libGLESv2_angle.so 2>/dev/null; pm list packages com.android.angle"
        )
        return out.contains("libGLESv2_angle") || out.contains("package:com.android.angle")
    }

    private suspend fun applyGraphics(ctx: Context, api: GfxApi, log: MutableList<String>) {
        if (!BackupStore.flag(ctx, "gfxsaved")) {
            val prop = ShizukuHelper.exec("getprop debug.hwui.renderer").trim()
            val angle = ShizukuHelper.exec("settings get global angle_gl_driver_all_angle").trim().ifEmpty { "null" }
            BackupStore.save(ctx, mapOf("prop_renderer" to prop, "angle_all" to angle))
            BackupStore.setFlag(ctx, "gfxsaved")
        }
        val want = if (api == GfxApi.VULKAN) "skiavk" else "skiagl"
        ShizukuHelper.exec("setprop debug.hwui.renderer $want")
        val got = ShizukuHelper.exec("getprop debug.hwui.renderer").trim()
        log += if (got == want) {
            "✔ App UI renderer: ${api.label}"
        } else {
            "✘ ${api.label}: this phone blocked the change"
        }

        if (api == GfxApi.VULKAN) {
            if (angleAvailable()) {
                ShizukuHelper.exec("settings put global angle_gl_driver_all_angle 1")
                log += "✔ OpenGL ES apps routed through Vulkan (ANGLE)"
            } else {
                log += "ℹ Vulkan is on for the app/system UI. This phone has no ANGLE (Android's OpenGL→Vulkan translator), so games drawn with OpenGL ES can't be forced onto Vulkan; games with a Vulkan option in their own settings can use it there"
            }
        } else {
            ShizukuHelper.exec("settings put global angle_gl_driver_all_angle 0")
        }
        log += "ℹ Close and reopen apps/games for the driver change to apply"
    }

    /** True for apps Android itself categorises as games. */
    @Suppress("DEPRECATION")
    fun isGame(ai: ApplicationInfo): Boolean =
        ai.category == ApplicationInfo.CATEGORY_GAME || (ai.flags and ApplicationInfo.FLAG_IS_GAME) != 0

    private suspend fun applyDns(ctx: Context, d: DnsChoice, log: MutableList<String>) {
        if (!BackupStore.flag(ctx, "dnssaved")) {
            val mode = ShizukuHelper.exec("settings get global private_dns_mode").trim().ifEmpty { "null" }
            val host = ShizukuHelper.exec("settings get global private_dns_specifier").trim().ifEmpty { "null" }
            BackupStore.save(ctx, mapOf("dns_mode" to mode, "dns_host" to host))
            BackupStore.setFlag(ctx, "dnssaved")
        }
        ShizukuHelper.exec("settings put global private_dns_specifier ${d.host}")
        ShizukuHelper.exec("settings put global private_dns_mode hostname")
        delay(2000)
        // Safety check: if names can't be resolved any more, undo it so the phone keeps internet.
        val ok = withTimeoutOrNull(5000) {
            withContext(Dispatchers.IO) {
                runCatching { InetAddress.getByName("connectivitycheck.gstatic.com") }.isSuccess
            }
        } == true
        if (ok) {
            log += "✔ Low ping: private DNS ${d.label}"
        } else {
            restoreDns(ctx)
            log += "✘ Low ping: ${d.label} doesn't work on this network, reverted"
        }
    }

    private suspend fun restoreDns(ctx: Context) {
        val saved = BackupStore.load(ctx)
        val mode = saved["dns_mode"] ?: "null"
        val host = saved["dns_host"] ?: "null"
        ShizukuHelper.exec(
            if (host == "null") "settings delete global private_dns_specifier"
            else "settings put global private_dns_specifier $host"
        )
        ShizukuHelper.exec(
            if (mode == "null") "settings delete global private_dns_mode"
            else "settings put global private_dns_mode $mode"
        )
    }

    suspend fun apply(ctx: Context, cfg: BoostConfig, extraGame: String? = null): List<String> {
        val log = mutableListOf<String>()

        // Always safe, no special permission: clear GR FPS's own cache
        ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }

        if (ShizukuHelper.state.value != ShizukuState.READY) {
            log += "✔ Cleared GR FPS cache"
            log += "✘ System tuning skipped — connect Shizuku to unlock it"
            return log
        }

        // Snapshot the ORIGINAL values once, so Reset can restore them
        if (!BackupStore.has(ctx)) {
            val snap = mutableMapOf<String, String>()
            for (k in TRACKED) {
                val (ns, key) = k.split(":")
                val out = ShizukuHelper.exec("settings get $ns $key").trim()
                if (out.startsWith("ERR:")) {
                    return log + "✘ Couldn't read current settings — aborted so nothing is changed"
                }
                snap[k] = out.lines().lastOrNull().orEmpty().ifEmpty { "null" }
            }
            BackupStore.save(ctx, snap)
        }

        cfg.animScale?.let {
            val v = fmt(it)
            step(
                log, "Animation speed ${v}x",
                "settings put global window_animation_scale $v",
                "settings put global transition_animation_scale $v",
                "settings put global animator_duration_scale $v"
            )
        }
        if (cfg.killBackground) step(log, "Freed RAM", "am kill-all")
        if (cfg.trimCache) step(log, "Cache trim started (runs in background)", "(pm trim-caches 999G >/dev/null 2>&1 &)")
        cfg.refreshRate?.let { hz ->
            val v = "$hz.0"
            ShizukuHelper.exec("settings put system min_refresh_rate $v")
            ShizukuHelper.exec("settings put system peak_refresh_rate $v")
            val min = ShizukuHelper.exec("settings get system min_refresh_rate").trim()
            val peak = ShizukuHelper.exec("settings get system peak_refresh_rate").trim()
            log += if (min == v && peak == v) {
                "✔ Refresh rate locked to ${hz}Hz (check with the FPS meter)"
            } else {
                "✘ Refresh rate: this phone didn't accept the setting"
            }
        }
        cfg.gfx?.let { api -> applyGraphics(ctx, api, log) }
        cfg.dns?.let { d -> applyDns(ctx, d, log) }
        if (cfg.disableScans) step(
            log, "Background scans off",
            "settings put global wifi_scan_always_enabled 0",
            "settings put global ble_scan_always_enabled 0"
        )
        if (cfg.gameMode) {
            val games = (detectGames(ctx) + listOfNotNull(extraGame)).distinct()
            if (games.isEmpty()) {
                log += "ℹ No games found to set Game Mode on"
            } else {
                val list = games.joinToString(" ")
                ShizukuHelper.exec(
                    "for p in $list; do cmd game set --mode performance --user 0 \$p 2>/dev/null || cmd game mode performance \$p 2>/dev/null; done",
                    40_000
                )
                BackupStore.addGames(ctx, games)
                log += "✔ Game Mode: Performance requested for ${games.size} games"
            }
        }
        if (cfg.fixedPerf) {
            step(log, "Fixed performance mode", "cmd power set-fixed-performance-mode-enabled true")
            BackupStore.setFlag(ctx, "fixedperf")
        }
        if (cfg.dexopt) step(log, "App dexopt started (runs in background)", "(cmd package bg-dexopt-job >/dev/null 2>&1 &)")

        // Resolution goes last: changing it makes the whole UI redraw
        cfg.resolution?.let { target ->
            val info = readDisplay()
            if (info == null) {
                log += "✘ Resolution: couldn't read the screen size"
            } else {
                if (!BackupStore.flag(ctx, "wmsaved")) {
                    val o = ShizukuHelper.exec("wm size; wm density")
                    val os = Regex("Override size:\\s*(\\d+x\\d+)").find(o)?.groupValues?.get(1) ?: "reset"
                    val od = Regex("Override density:\\s*(\\d+)").find(o)?.groupValues?.get(1) ?: "reset"
                    BackupStore.save(ctx, mapOf("wm_size" to os, "wm_density" to od))
                    BackupStore.setFlag(ctx, "wmsaved")
                }
                // always start from the real panel so an earlier override can't interfere
                ShizukuHelper.exec("wm size reset")
                ShizukuHelper.exec("wm density reset")
                if (target >= info.shortSide) {
                    log += "✔ Screen at native resolution (${info.shortSide}p)"
                } else {
                    val r = target.toFloat() / info.shortSide
                    val w = even((info.w * r).roundToInt())
                    val h = even((info.h * r).roundToInt())
                    val d = max(120, (info.density * r).roundToInt())
                    ShizukuHelper.exec("wm size ${w}x$h")
                    ShizukuHelper.exec("wm density $d")
                    BackupStore.setFlag(ctx, "res")
                    val now = ShizukuHelper.exec("wm size; wm density")
                    val gotSize = Regex("Override size:\\s*(\\d+x\\d+)").find(now)?.groupValues?.get(1)
                    log += if (gotSize == "${w}x$h") {
                        "✔ Resolution ${w}x$h (${target}p), density $d"
                    } else {
                        "✘ Resolution: asked for ${w}x$h but the phone reports ${gotSize ?: "no change"}"
                    }
                }
            }
        }

        return log
    }

    /** Put the screen size/density back to what they were before GR FPS touched them. */
    suspend fun restoreResolution(ctx: Context) {
        val saved = BackupStore.load(ctx)
        val size = saved["wm_size"] ?: "reset"
        val dens = saved["wm_density"] ?: "reset"
        ShizukuHelper.exec(if (size == "reset") "wm size reset" else "wm size $size")
        ShizukuHelper.exec(if (dens == "reset") "wm density reset" else "wm density $dens")
    }

    suspend fun reset(ctx: Context): List<String> {
        val log = mutableListOf<String>()
        if (ShizukuHelper.state.value != ShizukuState.READY) {
            return log + "✘ Connect Shizuku to reset system settings"
        }
        val saved = BackupStore.load(ctx)
        if (saved.isEmpty()) return log + "Nothing to reset"

        var n = 0
        for ((k, v) in saved) {
            if (!k.contains(":")) continue
            val (ns, key) = k.split(":")
            val cmd = if (v == "null") "settings delete $ns $key" else "settings put $ns $key $v"
            ShizukuHelper.exec(cmd)
            n++
        }
        log += "✔ Restored $n settings to original values"

        val games = BackupStore.games(ctx)
        if (games.isNotEmpty()) {
            ShizukuHelper.exec("for p in ${games.joinToString(" ")}; do cmd game reset \$p 2>/dev/null; done", 40_000)
            log += "✔ Game Mode reset"
        }
        if (BackupStore.flag(ctx, "fixedperf")) {
            ShizukuHelper.exec("cmd power set-fixed-performance-mode-enabled false")
            log += "✔ Fixed performance mode off"
        }
        if (BackupStore.flag(ctx, "gfxsaved")) {
            val prop = saved["prop_renderer"].orEmpty()
            ShizukuHelper.exec("setprop debug.hwui.renderer '$prop'")
            val angle = saved["angle_all"] ?: "null"
            ShizukuHelper.exec(
                if (angle == "null") "settings delete global angle_gl_driver_all_angle"
                else "settings put global angle_gl_driver_all_angle $angle"
            )
            log += "✔ Graphics driver restored"
        }
        if (BackupStore.flag(ctx, "dnssaved")) {
            restoreDns(ctx)
            log += "✔ DNS restored"
        }
        if (BackupStore.flag(ctx, "res")) {
            restoreResolution(ctx)
            log += "✔ Screen resolution restored"
        }
        BackupStore.clear(ctx)
        log += "ℹ Closed apps and cleared caches can't be restored"
        return log
    }
}

package com.gr.fps

import android.content.Context
import android.content.pm.ApplicationInfo
import java.util.Locale
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

enum class Level(val label: String, val score: Int, val blurb: String) {
    VERY_LOW("Very Low", 20, "Light touch: slightly faster animations."),
    LOW("Low", 40, "Faster animations + free up RAM."),
    MEDIUM("Medium", 60, "RAM + background scans off + screen capped at 1080p."),
    HIGH("High", 80, "Adds Game Mode: Performance + screen 900p."),
    VERY_HIGH("Very High", 100, "Adds fixed performance mode (may get warm) + screen 720p.")
}

/** What to change. null / false = leave that part of the phone untouched. */
data class BoostConfig(
    val animScale: Float? = null,
    val killBackground: Boolean = false,
    val trimCache: Boolean = false,
    val maxRefreshRate: Boolean = false,
    val gameMode: Boolean = false,
    val disableScans: Boolean = false,
    val fixedPerf: Boolean = false,
    val dexopt: Boolean = false,
    /** Target screen resolution as short-edge pixels (360, 480, 720 ...). null = don't touch. */
    val resolution: Int? = null
)

data class DisplayInfo(val w: Int, val h: Int, val density: Int) {
    val shortSide: Int get() = min(w, h)
}

object Optimizer {

    /** Extra well-known games, used in addition to auto-detection. */
    private val KNOWN_GAMES = listOf(
        "com.miHoYo.GenshinImpact", "com.mihoyo.yuanshen",
        "com.HoYoverse.hkrpgoversea", "com.miHoYo.hkrpg",
        "com.kurogame.wutheringwaves.global", "com.kurogame.mingchao"
    )

    /** Settings we may touch (namespace:key). Their original values are backed up. */
    private val TRACKED = listOf(
        "global:window_animation_scale",
        "global:transition_animation_scale",
        "global:animator_duration_scale",
        "global:wifi_scan_always_enabled",
        "global:ble_scan_always_enabled",
        "system:min_refresh_rate",
        "system:peak_refresh_rate"
    )

    fun configFor(level: Level): BoostConfig = when (level) {
        Level.VERY_LOW -> BoostConfig(animScale = 0.75f)
        Level.LOW -> BoostConfig(animScale = 0.5f, killBackground = true)
        Level.MEDIUM -> BoostConfig(
            animScale = 0.5f, killBackground = true, disableScans = true, resolution = 1080
        )
        Level.HIGH -> BoostConfig(
            animScale = 0.5f, killBackground = true, disableScans = true,
            gameMode = true, resolution = 900
        )
        Level.VERY_HIGH -> BoostConfig(
            animScale = 0.35f, killBackground = true, disableScans = true,
            gameMode = true, fixedPerf = true, resolution = 720
        )
    }

    fun describe(c: BoostConfig): List<String> = buildList {
        c.animScale?.let { add("Animation speed ${fmt(it)}x") }
        if (c.killBackground) add("Free RAM (close background apps)")
        if (c.trimCache) add("Trim app caches")
        if (c.maxRefreshRate) add("Force max refresh rate")
        if (c.gameMode) add("Game Mode: Performance (all installed games)")
        if (c.disableScans) add("Stop background Wi-Fi/BLE scans")
        if (c.fixedPerf) add("Fixed performance mode")
        if (c.dexopt) add("Optimize apps (dexopt)")
        c.resolution?.let { add("Screen resolution ${it}p (whole phone gets blurrier)") }
        if (isEmpty()) add("Nothing selected")
    }

    private fun fmt(f: Float) = String.format(Locale.US, "%.2f", f)

    private fun isBad(out: String) =
        out.contains("ERR:") || out.contains("Exception") || out.contains("Unknown command") ||
            out.contains("not found", true) || out.contains("Error", true)

    private suspend fun step(log: MutableList<String>, label: String, vararg cmds: String) {
        var bad = false
        var slow = false
        for (cmd in cmds) {
            val out = ShizukuHelper.exec(cmd)
            if (out.contains("ERR: timeout")) slow = true else if (isBad(out)) bad = true
        }
        log += when {
            slow -> "✘ $label (took too long, skipped)"
            bad -> "✘ $label (not supported on this phone)"
            else -> "✔ $label"
        }
    }

    /** Every installed game (by Android's own "game" category) plus a few known titles. */
    fun detectGames(ctx: Context): List<String> {
        val apps = ctx.packageManager.getInstalledApplications(0)
        val installed = apps.map { it.packageName }.toSet()
        @Suppress("DEPRECATION")
        val detected = apps.filter {
            it.packageName != ctx.packageName &&
                (it.category == ApplicationInfo.CATEGORY_GAME || (it.flags and ApplicationInfo.FLAG_IS_GAME) != 0)
        }.map { it.packageName }
        return (detected + KNOWN_GAMES.filter { it in installed }).distinct()
    }

    /** Physical screen size/density (what the panel really is, ignoring any override). */
    suspend fun readDisplay(): DisplayInfo? {
        val out = ShizukuHelper.exec("wm size; wm density")
        val size = Regex("Physical size:\\s*(\\d+)x(\\d+)").find(out) ?: return null
        val dens = Regex("Physical density:\\s*(\\d+)").find(out) ?: return null
        return DisplayInfo(
            size.groupValues[1].toInt(),
            size.groupValues[2].toInt(),
            dens.groupValues[1].toInt()
        )
    }

    private fun even(x: Int) = x - x % 2

    suspend fun apply(ctx: Context, cfg: BoostConfig): List<String> {
        val log = mutableListOf<String>()

        // Always safe, no special permission: clear GR FPS's own cache
        ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }

        if (ShizukuHelper.state.value != ShizukuState.READY) {
            log += "✔ Cleared GR FPS cache"
            log += "✘ System tuning skipped — connect Shizuku to unlock it"
            return log
        }

        // Snapshot the ORIGINAL values once, so Reset can restore them
        if (!BackupStore.has(ctx)) {
            val snap = mutableMapOf<String, String>()
            for (k in TRACKED) {
                val (ns, key) = k.split(":")
                val out = ShizukuHelper.exec("settings get $ns $key").trim()
                if (out.startsWith("ERR:")) {
                    return log + "✘ Couldn't read current settings — aborted so nothing is changed"
                }
                snap[k] = out.lines().lastOrNull().orEmpty().ifEmpty { "null" }
            }
            BackupStore.save(ctx, snap)
        }

        cfg.animScale?.let {
            val v = fmt(it)
            step(
                log, "Animation speed ${v}x",
                "settings put global window_animation_scale $v",
                "settings put global transition_animation_scale $v",
                "settings put global animator_duration_scale $v"
            )
        }
        if (cfg.killBackground) step(log, "Freed RAM", "am kill-all")
        if (cfg.trimCache) step(log, "Cache trim started (runs in background)", "(pm trim-caches 999G >/dev/null 2>&1 &)")
        if (cfg.maxRefreshRate) step(
            log, "Max refresh rate",
            "settings put system min_refresh_rate 120.0",
            "settings put system peak_refresh_rate 120.0"
        )
        if (cfg.disableScans) step(
            log, "Background scans off",
            "settings put global wifi_scan_always_enabled 0",
            "settings put global ble_scan_always_enabled 0"
        )
        if (cfg.gameMode) {
            val games = detectGames(ctx)
            if (games.isEmpty()) {
                log += "ℹ No games found to set Game Mode on"
            } else {
                val list = games.joinToString(" ")
                ShizukuHelper.exec(
                    "for p in $list; do cmd game set --mode performance --user 0 \$p 2>/dev/null || cmd game mode performance \$p 2>/dev/null; done",
                    40_000
                )
                BackupStore.addGames(ctx, games)
                log += "✔ Game Mode: Performance requested for ${games.size} games"
            }
        }
        if (cfg.fixedPerf) {
            step(log, "Fixed performance mode", "cmd power set-fixed-performance-mode-enabled true")
            BackupStore.setFlag(ctx, "fixedperf")
        }
        if (cfg.dexopt) step(log, "App dexopt started (runs in background)", "(cmd package bg-dexopt-job >/dev/null 2>&1 &)")

        // Resolution goes last: changing it makes the whole UI redraw
        cfg.resolution?.let { target ->
            val info = readDisplay()
            if (info == null) {
                log += "✘ Resolution: couldn't read the screen size"
            } else {
                if (!BackupStore.flag(ctx, "wmsaved")) {
                    val o = ShizukuHelper.exec("wm size; wm density")
                    val os = Regex("Override size:\\s*(\\d+x\\d+)").find(o)?.groupValues?.get(1) ?: "reset"
                    val od = Regex("Override density:\\s*(\\d+)").find(o)?.groupValues?.get(1) ?: "reset"
                    BackupStore.save(ctx, mapOf("wm_size" to os, "wm_density" to od))
                    BackupStore.setFlag(ctx, "wmsaved")
                }
                if (target >= info.shortSide) {
                    ShizukuHelper.exec("wm size reset")
                    ShizukuHelper.exec("wm density reset")
                    log += "✔ Screen at native resolution (${info.shortSide}p)"
                } else {
                    val r = target.toFloat() / info.shortSide
                    val w = even((info.w * r).roundToInt())
                    val h = even((info.h * r).roundToInt())
                    val d = max(120, (info.density * r).roundToInt())
                    ShizukuHelper.exec("wm size ${w}x$h")
                    ShizukuHelper.exec("wm density $d")
                    BackupStore.setFlag(ctx, "res")
                    log += "✔ Resolution ${w}x$h (${target}p)"
                }
            }
        }

        return log
    }

    /** Put the screen size/density back to what they were before GR FPS touched them. */
    suspend fun restoreResolution(ctx: Context) {
        val saved = BackupStore.load(ctx)
        val size = saved["wm_size"] ?: "reset"
        val dens = saved["wm_density"] ?: "reset"
        ShizukuHelper.exec(if (size == "reset") "wm size reset" else "wm size $size")
        ShizukuHelper.exec(if (dens == "reset") "wm density reset" else "wm density $dens")
    }

    suspend fun reset(ctx: Context): List<String> {
        val log = mutableListOf<String>()
        if (ShizukuHelper.state.value != ShizukuState.READY) {
            return log + "✘ Connect Shizuku to reset system settings"
        }
        val saved = BackupStore.load(ctx)
        if (saved.isEmpty()) return log + "Nothing to reset"

        var n = 0
        for ((k, v) in saved) {
            if (!k.contains(":")) continue
            val (ns, key) = k.split(":")
            val cmd = if (v == "null") "settings delete $ns $key" else "settings put $ns $key $v"
            ShizukuHelper.exec(cmd)
            n++
        }
        log += "✔ Restored $n settings to original values"

        val games = BackupStore.games(ctx)
        if (games.isNotEmpty()) {
            ShizukuHelper.exec("for p in ${games.joinToString(" ")}; do cmd game reset \$p 2>/dev/null; done", 40_000)
            log += "✔ Game Mode reset"
        }
        if (BackupStore.flag(ctx, "fixedperf")) {
            ShizukuHelper.exec("cmd power set-fixed-performance-mode-enabled false")
            log += "✔ Fixed performance mode off"
        }
        if (BackupStore.flag(ctx, "res")) {
            restoreResolution(ctx)
            log += "✔ Screen resolution restored"
        }
        BackupStore.clear(ctx)
        log += "ℹ Closed apps and cleared caches can't be restored"
        return log
    }
}

package com.gr.fps

import android.content.Context
import java.util.Locale

enum class Level(val label: String, val score: Int, val blurb: String) {
    VERY_LOW("Very Low", 20, "Light touch: slightly faster animations."),
    LOW("Low", 40, "Faster animations + free up RAM."),
    MEDIUM("Medium", 60, "Balanced: RAM, caches and background scans."),
    HIGH("High", 80, "Adds max refresh rate + Game Mode: Performance."),
    VERY_HIGH("Very High", 100, "Everything on: performance mode + app dexopt.")
}

/** What to change. null / false = leave that part of the phone untouched. */
data class BoostConfig(
    val animScale: Float? = null,
    val killBackground: Boolean = false,
    val trimCache: Boolean = false,
    val maxRefreshRate: Boolean = false,
    val gameMode: Boolean = false,
    val disableScans: Boolean = false,
    val fixedPerf: Boolean = false,
    val dexopt: Boolean = false
)

object Optimizer {

    /** Common gacha-game package names (global + CN builds). Unknown ones are simply ignored. */
    private val GAMES = listOf(
        "com.miHoYo.GenshinImpact", "com.mihoyo.yuanshen",
        "com.HoYoverse.hkrpgoversea", "com.miHoYo.hkrpg",
        "com.kurogame.wutheringwaves.global", "com.kurogame.mingchao"
    )

    /** Settings we may touch (namespace:key). Their original values are backed up. */
    private val TRACKED = listOf(
        "global:window_animation_scale",
        "global:transition_animation_scale",
        "global:animator_duration_scale",
        "global:wifi_scan_always_enabled",
        "global:ble_scan_always_enabled",
        "system:min_refresh_rate",
        "system:peak_refresh_rate"
    )

    fun configFor(level: Level): BoostConfig = when (level) {
        Level.VERY_LOW -> BoostConfig(animScale = 0.75f)
        Level.LOW -> BoostConfig(animScale = 0.5f, killBackground = true)
        Level.MEDIUM -> BoostConfig(animScale = 0.5f, killBackground = true, trimCache = true, disableScans = true)
        Level.HIGH -> BoostConfig(
            animScale = 0.35f, killBackground = true, trimCache = true,
            maxRefreshRate = true, gameMode = true, disableScans = true
        )
        Level.VERY_HIGH -> BoostConfig(
            animScale = 0.25f, killBackground = true, trimCache = true,
            maxRefreshRate = true, gameMode = true, disableScans = true,
            fixedPerf = true, dexopt = true
        )
    }

    fun describe(c: BoostConfig): List<String> = buildList {
        c.animScale?.let { add("Animation speed ${String.format(Locale.US, "%.2f", it)}x") }
        if (c.killBackground) add("Free RAM (close background apps)")
        if (c.trimCache) add("Trim app caches")
        if (c.maxRefreshRate) add("Force max refresh rate")
        if (c.gameMode) add("Game Mode: Performance (Genshin / HSR / WuWa)")
        if (c.disableScans) add("Stop background Wi-Fi/BLE scans")
        if (c.fixedPerf) add("Fixed performance mode")
        if (c.dexopt) add("Optimize apps (dexopt)")
        if (isEmpty()) add("Nothing selected")
    }

    private fun fmt(f: Float) = String.format(Locale.US, "%.2f", f)

    private fun isBad(out: String) =
        out.contains("ERR:") || out.contains("Exception") || out.contains("Unknown command") ||
            out.contains("not found", true) || out.contains("Error", true)

    private suspend fun step(log: MutableList<String>, label: String, vararg cmds: String) {
        var bad = false
        for (cmd in cmds) if (isBad(ShizukuHelper.exec(cmd))) bad = true
        log += if (bad) "✘ $label (not supported on this phone)" else "✔ $label"
    }

    suspend fun apply(ctx: Context, cfg: BoostConfig): List<String> {
        val log = mutableListOf<String>()

        // Always safe, no special permission: clear GR FPS's own cache
        ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }

        if (ShizukuHelper.state.value != ShizukuState.READY) {
            log += "✔ Cleared GR FPS cache"
            log += "✘ System tuning skipped — connect Shizuku to unlock it"
            return log
        }

        // Snapshot the ORIGINAL values once, so Reset can restore them
        if (!BackupStore.has(ctx)) {
            val snap = mutableMapOf<String, String>()
            for (k in TRACKED) {
                val (ns, key) = k.split(":")
                val out = ShizukuHelper.exec("settings get $ns $key").trim()
                if (out.startsWith("ERR:")) {
                    return log + "✘ Couldn't read current settings — aborted so nothing is changed"
                }
                snap[k] = out.lines().lastOrNull().orEmpty().ifEmpty { "null" }
            }
            BackupStore.save(ctx, snap)
        }

        cfg.animScale?.let {
            val v = fmt(it)
            step(
                log, "Animation speed ${v}x",
                "settings put global window_animation_scale $v",
                "settings put global transition_animation_scale $v",
                "settings put global animator_duration_scale $v"
            )
        }
        if (cfg.killBackground) step(log, "Freed RAM", "am kill-all")
        if (cfg.trimCache) step(log, "Trimmed app caches", "pm trim-caches 999G")
        if (cfg.maxRefreshRate) step(
            log, "Max refresh rate",
            "settings put system min_refresh_rate 120.0",
            "settings put system peak_refresh_rate 120.0"
        )
        if (cfg.disableScans) step(
            log, "Background scans off",
            "settings put global wifi_scan_always_enabled 0",
            "settings put global ble_scan_always_enabled 0"
        )
        if (cfg.gameMode) {
            for (pkg in GAMES) {
                ShizukuHelper.exec(
                    "cmd game set --mode performance --user 0 $pkg 2>/dev/null || cmd game mode performance $pkg 2>/dev/null"
                )
            }
            BackupStore.setFlag(ctx, "game")
            log += "✔ Game Mode: Performance requested for installed games"
        }
        if (cfg.fixedPerf) {
            step(log, "Fixed performance mode", "cmd power set-fixed-performance-mode-enabled true")
            BackupStore.setFlag(ctx, "fixedperf")
        }
        if (cfg.dexopt) step(log, "App dexopt started (runs in background)", "cmd package bg-dexopt-job")

        return log
    }

    suspend fun reset(ctx: Context): List<String> {
        val log = mutableListOf<String>()
        if (ShizukuHelper.state.value != ShizukuState.READY) {
            return log + "✘ Connect Shizuku to reset system settings"
        }
        val saved = BackupStore.load(ctx)
        if (saved.isEmpty()) return log + "Nothing to reset"

        for ((k, v) in saved) {
            val (ns, key) = k.split(":")
            val cmd = if (v == "null") "settings delete $ns $key" else "settings put $ns $key $v"
            ShizukuHelper.exec(cmd)
        }
        log += "✔ Restored ${saved.size} settings to original values"

        if (BackupStore.flag(ctx, "game")) {
            for (pkg in GAMES) ShizukuHelper.exec("cmd game reset $pkg 2>/dev/null")
            log += "✔ Game Mode reset"
        }
        if (BackupStore.flag(ctx, "fixedperf")) {
            ShizukuHelper.exec("cmd power set-fixed-performance-mode-enabled false")
            log += "✔ Fixed performance mode off"
        }
        BackupStore.clear(ctx)
        log += "ℹ Closed apps and cleared caches can't be restored"
        return log
    }
}

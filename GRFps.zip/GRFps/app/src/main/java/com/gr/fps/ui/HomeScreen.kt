package com.gr.fps.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Animation
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.runtime.collectAsState
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.gr.fps.BoostConfig
import com.gr.fps.MainViewModel
import com.gr.fps.Optimizer
import com.gr.fps.ShizukuHelper
import com.gr.fps.ShizukuState
import java.util.Locale

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val shizuku by ShizukuHelper.state.collectAsState()
    var tick by remember { mutableIntStateOf(0) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        tick++
        ShizukuHelper.refresh()
        vm.refreshRam()
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val batteryOk = remember(tick) {
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }

    val cfg = vm.config

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Column(
                Modifier
                    .background(Bg)
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                if (vm.busy) {
                    LinearProgressIndicator(
                        color = Neon,
                        trackColor = Divider,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NeonButton(
                        "APPLY", Icons.Rounded.Bolt, { vm.requestApply() },
                        Modifier.weight(1f), filled = true, enabled = !vm.busy
                    )
                    NeonButton(
                        "RESET", Icons.Rounded.RestartAlt, { vm.confirmReset = true },
                        Modifier.weight(1f), filled = false, enabled = !vm.busy && vm.hasBackup
                    )
                }
            }
        }
    ) { pad ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = pad.calculateTopPadding() + 8.dp,
                bottom = pad.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------- Header ----------
            item {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bolt, null, tint = Neon, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "GR FPS", color = Neon, fontSize = 32.sp,
                            fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic
                        )
                    }
                    Text("Boost FPS  •  Smoother Gameplay", color = TextDim, fontSize = 13.sp)
                }
            }

            // ---------- Gauge ----------
            item {
                NeonCard {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.width(260.dp).height(135.dp)) {
                            BoostGauge(vm.level?.score ?: 70)
                        }
                        BigScore(vm.level?.score ?: 70)
                        Text(
                            "BOOST LEVEL • ${vm.level?.label?.uppercase() ?: "CUSTOM"}",
                            color = TextMain, fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 1.sp
                        )
                        Text(vm.level?.blurb ?: "Your own combination of options.", color = TextDim, fontSize = 12.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(4.dp))
                        Text(vm.ramText, color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // ---------- Quick actions ----------
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionTile("Optimize\nSettings", Icons.Rounded.Settings, { vm.requestApply() }, Modifier.weight(1f))
                    ActionTile("Clear\nCache", Icons.Rounded.DeleteSweep, {
                        vm.requestApply(BoostConfig(trimCache = true))
                    }, Modifier.weight(1f))
                    ActionTile("Reduce\nLag", Icons.Rounded.Memory, {
                        vm.requestApply(BoostConfig(killBackground = true, disableScans = true))
                    }, Modifier.weight(1f))
                    ActionTile("Max\nPerformance", Icons.Rounded.RocketLaunch, {
                        vm.selectLevel(com.gr.fps.Level.VERY_HIGH)
                        vm.requestApply()
                    }, Modifier.weight(1f))
                }
            }

            // ---------- Auto mode ----------
            item {
                NeonCard {
                    SectionTitle("Auto Mode")
                    LevelSelector(vm.level) { vm.selectLevel(it) }
                }
            }

            // ---------- Manual options ----------
            item {
                NeonCard {
                    SectionTitle("Manual Options")

                    SettingRow(
                        Icons.Rounded.Animation, "Faster animations",
                        "Window / transition / animator scale",
                        cfg.animScale != null
                    ) { vm.edit(cfg.copy(animScale = if (it) 0.5f else null)) }
                    cfg.animScale?.let {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            NeonSlider(it) { v -> vm.edit(cfg.copy(animScale = v)) }
                        }
                        Text(
                            "Speed: ${String.format(Locale.US, "%.2f", it)}x  (lower = faster)",
                            color = TextDim, fontSize = 11.sp
                        )
                    }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.Memory, "Free RAM",
                        "Close cached background apps", cfg.killBackground
                    ) { vm.edit(cfg.copy(killBackground = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.DeleteSweep, "Trim app caches",
                        "Clear cache of all apps", cfg.trimCache
                    ) { vm.edit(cfg.copy(trimCache = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.Refresh, "Max refresh rate",
                        "Force the highest screen Hz (if supported)", cfg.maxRefreshRate
                    ) { vm.edit(cfg.copy(maxRefreshRate = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.SportsEsports, "Game Mode: Performance",
                        "Genshin Impact, Honkai: Star Rail, Wuthering Waves", cfg.gameMode
                    ) { vm.edit(cfg.copy(gameMode = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.WifiOff, "Stop background scans",
                        "Wi-Fi / Bluetooth always-scan off", cfg.disableScans
                    ) { vm.edit(cfg.copy(disableScans = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.Speed, "Fixed performance mode",
                        "Keeps CPU/GPU clocks high (Android 12+ devices that support it)", cfg.fixedPerf
                    ) { vm.edit(cfg.copy(fixedPerf = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.Apps, "Optimize apps (dexopt)",
                        "Pre-compile apps for faster launch", cfg.dexopt
                    ) { vm.edit(cfg.copy(dexopt = it)) }
                }
            }

            // ---------- Permissions / Shizuku ----------
            item {
                NeonCard {
                    SectionTitle("Permissions & Shizuku")
                    PermissionRow(
                        Icons.Rounded.Shield, "Shizuku access",
                        when (shizuku) {
                            ShizukuState.READY -> "Connected — full tuning unlocked"
                            ShizukuState.CONNECTING -> "Connecting…"
                            ShizukuState.NO_PERMISSION -> "Running — tap Allow to let GR FPS use it"
                            ShizukuState.NOT_RUNNING -> "Not running — install / start Shizuku first"
                        },
                        shizuku == ShizukuState.READY,
                        if (shizuku == ShizukuState.NOT_RUNNING) "OPEN" else "ALLOW"
                    ) {
                        if (shizuku == ShizukuState.NOT_RUNNING) ShizukuHelper.openShizuku(ctx)
                        else ShizukuHelper.requestPermission(ctx)
                    }
                    HorizontalDivider(color = Divider)
                    PermissionRow(
                        Icons.Rounded.BatteryChargingFull, "Ignore battery optimization",
                        "Keeps GR FPS from being killed in the background", batteryOk, "ALLOW"
                    ) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    HorizontalDivider(color = Divider)
                    PermissionRow(
                        Icons.Rounded.Notifications, "Notifications",
                        "Tell you when a boost finishes", notifOk, "ALLOW"
                    ) {
                        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }
            }

            // ---------- Result log ----------
            if (vm.log.isNotEmpty()) {
                item {
                    NeonCard {
                        SectionTitle("Last result")
                        vm.log.forEach {
                            Text(
                                it,
                                color = if (it.startsWith("✔")) Neon else if (it.startsWith("✘")) Color(0xFFFFB300) else TextDim,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    "GR FPS reduces system overhead to make your phone smoother. It can't turn a very weak chip into a flagship, " +
                        "so expect the biggest gains on heavy games when you also lower in-game graphics.",
                    color = TextDim, fontSize = 11.sp, lineHeight = 15.sp
                )
            }
        }
    }

    // ---------- Dialogs ----------
    vm.pending?.let { p ->
        AlertDialog(
            onDismissRequest = vm::dismissPending,
            containerColor = CardTop,
            shape = TechShape,
            title = { Text("Apply boost?", color = Neon, fontWeight = FontWeight.Black) },
            text = {
                Column {
                    Text("These changes will be applied:", color = TextDim, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Optimizer.describe(p).forEach { Text("• $it", color = TextMain, fontSize = 13.sp) }
                    Spacer(Modifier.height(8.dp))
                    Text("Your original values are saved first. Use RESET to restore them.", color = TextDim, fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = vm::confirmApply) { Text("APPLY", color = Neon, fontWeight = FontWeight.Black) }
            },
            dismissButton = {
                TextButton(onClick = vm::dismissPending) { Text("CANCEL", color = TextDim) }
            }
        )
    }

    if (vm.confirmReset) {
        AlertDialog(
            onDismissRequest = { vm.confirmReset = false },
            containerColor = CardTop,
            shape = TechShape,
            title = { Text("Reset everything?", color = Neon, fontWeight = FontWeight.Black) },
            text = {
                Text(
                    "All settings GR FPS changed will go back to what they were before. " +
                        "Apps that were closed and caches that were cleared can't be restored.",
                    color = TextMain, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = vm::confirmResetNow) { Text("RESET", color = Neon, fontWeight = FontWeight.Black) }
            },
            dismissButton = {
                TextButton(onClick = { vm.confirmReset = false }) { Text("CANCEL", color = TextDim) }
            }
        )
    }
}

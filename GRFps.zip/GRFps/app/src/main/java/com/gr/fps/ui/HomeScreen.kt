package com.gr.fps.ui

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Animation
import androidx.compose.material.icons.rounded.Apps
import androidx.compose.material.icons.rounded.BatteryChargingFull
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Insights
import androidx.compose.material.icons.rounded.Memory
import androidx.compose.material.icons.rounded.Notifications
import androidx.compose.material.icons.rounded.RestartAlt
import androidx.compose.material.icons.rounded.RocketLaunch
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Shield
import androidx.compose.material.icons.rounded.SportsEsports
import androidx.compose.material.icons.rounded.Speed
import androidx.compose.material.icons.rounded.Thermostat
import androidx.compose.material.icons.rounded.Visibility
import androidx.compose.material.icons.rounded.WifiOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LifecycleEventEffect
import com.gr.fps.BoostConfig
import com.gr.fps.CaptureRequestActivity
import com.gr.fps.FpsDetailService
import com.gr.fps.FrameGenRequestActivity
import com.gr.fps.FrameGenService
import com.gr.fps.FpsOverlayService
import com.gr.fps.Level
import com.gr.fps.MainViewModel
import com.gr.fps.Optimizer
import com.gr.fps.RecorderService
import com.gr.fps.ShizukuHelper
import com.gr.fps.ShizukuState
import com.gr.fps.ThermalOverlayService
import com.gr.fps.startOverlay
import com.gr.fps.stopOverlay
import java.util.Locale

private fun openOverlaySettings(ctx: Context) {
    ctx.startActivity(
        Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    )
}

@Composable
fun HomeScreen(vm: MainViewModel) {
    val ctx = LocalContext.current
    val shizuku by ShizukuHelper.state.collectAsState()
    val shizukuDetail by ShizukuHelper.detail.collectAsState()
    var tick by remember { mutableIntStateOf(0) }

    LifecycleEventEffect(Lifecycle.Event.ON_RESUME) {
        tick++
        ShizukuHelper.refresh()
        vm.refreshRam()
        vm.refreshDisplay()
        if (vm.recEnabled) RecorderService.refreshReady(ctx)
    }
    LaunchedEffect(shizuku) {
        if (shizuku == ShizukuState.READY) vm.refreshDisplay()
    }

    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    val batteryOk = remember(tick) {
        ctx.getSystemService(PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    }
    val notifOk = remember(tick) {
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    }
    val overlayOk = remember(tick) { Settings.canDrawOverlays(ctx) }

    val fpsRunning by FpsOverlayService.running.collectAsState()
    val detailRunning by FpsDetailService.running.collectAsState()
    val thermalRunning by ThermalOverlayService.running.collectAsState()
    val recState by RecorderService.state.collectAsState()
    val fgRunning by FrameGenService.running.collectAsState()
    val fgStats by FrameGenService.stats.collectAsState()

    val cfg = vm.config
    val playMode = vm.selectedApp != null && vm.launchAfter

    fun toggleOverlay(on: Boolean, cls: Class<*>, needShizuku: Boolean) {
        when {
            !on -> stopOverlay(ctx, cls)
            !overlayOk -> {
                Toast.makeText(ctx, "Allow \"Display over other apps\" first", Toast.LENGTH_LONG).show()
                openOverlaySettings(ctx)
            }
            needShizuku && shizuku != ShizukuState.READY ->
                Toast.makeText(ctx, "Connect Shizuku first", Toast.LENGTH_LONG).show()
            else -> startOverlay(ctx, cls)
        }
    }

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            Column(
                Modifier
                    .background(Bg)
                    .navigationBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 10.dp)
            ) {
                if (vm.busy) {
                    LinearProgressIndicator(
                        color = Neon,
                        trackColor = Divider,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp)
                    )
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    NeonButton(
                        if (playMode) "APPLY & PLAY" else "APPLY",
                        Icons.Rounded.Bolt, { vm.requestApply() },
                        Modifier.weight(1f), filled = true, enabled = !vm.busy
                    )
                    NeonButton(
                        "RESET", Icons.Rounded.RestartAlt, { vm.confirmReset = true },
                        Modifier.weight(1f), filled = false, enabled = vm.hasBackup
                    )
                }
            }
        }
    ) { pad ->
        LazyColumn(
            contentPadding = PaddingValues(
                start = 16.dp, end = 16.dp,
                top = pad.calculateTopPadding() + 8.dp,
                bottom = pad.calculateBottomPadding() + 16.dp
            ),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // ---------- Header ----------
            item {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Bolt, null, tint = Neon, modifier = Modifier.size(34.dp))
                        Spacer(Modifier.width(6.dp))
                        Text(
                            "GR FPS", color = Neon, fontSize = 32.sp,
                            fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic
                        )
                    }
                    Text("Boost FPS  •  Smoother Gameplay", color = TextDim, fontSize = 13.sp)
                }
            }

            // ---------- Gauge ----------
            item {
                NeonCard {
                    Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.width(260.dp).height(135.dp)) {
                            BoostGauge(vm.level?.score ?: 70)
                        }
                        BigScore(vm.level?.score ?: 70)
                        Text(
                            "BOOST LEVEL • ${vm.level?.label?.uppercase() ?: "CUSTOM"}",
                            color = TextMain, fontWeight = FontWeight.Black, fontSize = 13.sp, letterSpacing = 1.sp
                        )
                        Text(vm.level?.blurb ?: "Your own combination of options.", color = TextDim, fontSize = 12.sp, textAlign = TextAlign.Center)
                        Spacer(Modifier.height(4.dp))
                        Text(vm.ramText, color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            // ---------- Quick actions ----------
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ActionTile("Optimize\nSettings", Icons.Rounded.Settings, { vm.requestApply() }, Modifier.weight(1f))
                    ActionTile("Clear\nCache", Icons.Rounded.DeleteSweep, {
                        vm.requestApply(BoostConfig(trimCache = true))
                    }, Modifier.weight(1f))
                    ActionTile("Reduce\nLag", Icons.Rounded.Memory, {
                        vm.requestApply(BoostConfig(killBackground = true, disableScans = true))
                    }, Modifier.weight(1f))
                    ActionTile("Max\nPerformance", Icons.Rounded.RocketLaunch, {
                        vm.selectLevel(Level.VERY_HIGH)
                        vm.requestApply()
                    }, Modifier.weight(1f))
                }
            }

            // ---------- Game / app picker ----------
            item { GamePickerCard(vm) }

            // ---------- Auto mode ----------
            item {
                NeonCard {
                    SectionTitle("Auto Mode")
                    LevelSelector(vm.level) { vm.selectLevel(it) }
                }
            }

            // ---------- Screen resolution ----------
            item {
                NeonCard {
                    SectionTitle("Screen Resolution")
                    if (vm.nativeText.isNotEmpty()) {
                        Text(
                            vm.nativeText, color = Neon, fontSize = 12.sp,
                            fontWeight = FontWeight.Bold, modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    ResolutionPicker(cfg.resolution, vm.nativeShort) { vm.edit(cfg.copy(resolution = it)) }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Lower = smoother games, but the whole phone looks blurrier. After APPLY you get 15 seconds to tap KEEP, otherwise it goes back by itself. " +
                            "(With \"Boost & play\" there's no countdown, since you're in the game; use RESET to go back.)",
                        color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
                    )
                }
            }

            // ---------- FPS lock ----------
            item {
                NeonCard {
                    SectionTitle("FPS Lock (Refresh Rate)")
                    if (vm.supportedRates.isNotEmpty()) {
                        Text(
                            "Your screen supports: " + vm.supportedRates.sorted().joinToString(" / ") + " Hz",
                            color = Neon, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 8.dp)
                        )
                    }
                    RatePicker(cfg.refreshRate, vm.supportedRates) { vm.edit(cfg.copy(refreshRate = it)) }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Locks the SCREEN to this Hz for every app. A game that only draws 60 frames will still show 60 FPS " +
                            "(the screen just repeats frames), so use the FPS meter to see what the game really does. " +
                            "Higher Hz uses more battery. Greyed-out numbers aren't supported by your screen.",
                        color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
                    )
                }
            }

            // ---------- Graphics driver ----------
            item {
                NeonCard {
                    SectionTitle("Game Graphics Driver")
                    GfxPicker(cfg.gfx, vm.vulkanOk) { vm.edit(cfg.copy(gfx = it)) }
                    Spacer(Modifier.height(8.dp))
                    Text(
                        (if (vm.vulkanOk) "" else "This phone doesn't support Vulkan, so Vulkan is disabled.\n") +
                            "Switches the renderer Android uses for apps (apps must be reopened). " +
                            (if (vm.angleOk) "OpenGL ES apps are also routed through Vulkan on this phone. " else "") +
                            "Games that let you pick Vulkan/OpenGL inside their own settings keep using what they choose. " +
                            "It can make some apps crash or look wrong; RESET puts it back.",
                        color = TextDim, fontSize = 11.sp, lineHeight = 14.sp
                    )
                }
            }

            // ---------- Low ping ----------
            item { LowPingCard(vm) }

            // ---------- Manual options ----------
            item {
                NeonCard {
                    SectionTitle("Manual Options")

                    SettingRow(
                        Icons.Rounded.Animation, "Faster animations",
                        "Window / transition / animator scale",
                        cfg.animScale != null
                    ) { vm.edit(cfg.copy(animScale = if (it) 0.5f else null)) }
                    cfg.animScale?.let {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            NeonSlider(it) { v -> vm.edit(cfg.copy(animScale = v)) }
                        }
                        Text(
                            "Speed: ${String.format(Locale.US, "%.2f", it)}x  (lower = faster)",
                            color = TextDim, fontSize = 11.sp
                        )
                    }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.Memory, "Free RAM",
                        "Close cached background apps", cfg.killBackground
                    ) { vm.edit(cfg.copy(killBackground = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.DeleteSweep, "Trim app caches",
                        "Clears all app caches (apps open slower once afterwards)", cfg.trimCache
                    ) { vm.edit(cfg.copy(trimCache = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.SportsEsports, "Game Mode: Performance",
                        "Asks Android to favor speed in every installed game", cfg.gameMode
                    ) { vm.edit(cfg.copy(gameMode = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.WifiOff, "Stop background scans",
                        "Wi-Fi / Bluetooth always-scan off", cfg.disableScans
                    ) { vm.edit(cfg.copy(disableScans = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.Speed, "Fixed performance mode",
                        "Keeps CPU/GPU clocks high (Android 12+ devices that support it)", cfg.fixedPerf
                    ) { vm.edit(cfg.copy(fixedPerf = it)) }
                    HorizontalDivider(color = Divider)
                    SettingRow(
                        Icons.Rounded.Apps, "Optimize apps (dexopt)",
                        "Heavy: phone lags for several minutes. Only use while charging", cfg.dexopt
                    ) { vm.edit(cfg.copy(dexopt = it)) }
                }
            }

            // ---------- FPS meter ----------
            item {
                OverlayCard(
                    title = "FPS Meter",
                    icon = Icons.Rounded.Visibility,
                    name = "Show FPS overlay",
                    desc = "Real frames per second of the app on screen. Drag the box to move it.",
                    running = fpsRunning,
                    scale = vm.scaleFps,
                    note = "Counted from frames the screen really showed (via Shizuku), nothing is faked. Some phones block this and will show \"--\".",
                    onToggle = { toggleOverlay(it, FpsOverlayService::class.java, true) },
                    onScale = { vm.setScale("fps", it) }
                )
            }

            // ---------- FPS meter Pro ----------
            item {
                OverlayCard(
                    title = "FPS Meter Pro",
                    icon = Icons.Rounded.Insights,
                    name = "Show detailed FPS overlay",
                    desc = "FPS, average, 1% low, stutter count and a frame-time graph.",
                    running = detailRunning,
                    scale = vm.scaleDetail,
                    note = "1% low shows how bad the slowest frames are: a high average with a low 1% low feels stuttery. " +
                        "Graph bars: green = steady, yellow = slow, red = stutter.",
                    onToggle = { toggleOverlay(it, FpsDetailService::class.java, true) },
                    onScale = { vm.setScale("detail", it) }
                )
            }

            // ---------- Temperature & bottleneck ----------
            item {
                OverlayCard(
                    title = "Temp & Bottleneck",
                    icon = Icons.Rounded.Thermostat,
                    name = "Show temperature / bottleneck overlay",
                    desc = "CPU & GPU load, clock speed, temperatures, RAM, and what is holding your phone back.",
                    running = thermalRunning,
                    scale = vm.scaleThermal,
                    note = "Read from the phone's real sensors. Some phones hide GPU load or CPU temperature; those show \"--\" or \"n/a\". " +
                        "Without Shizuku only battery temperature and RAM are shown.",
                    onToggle = { toggleOverlay(it, ThermalOverlayService::class.java, false) },
                    onScale = { vm.setScale("thermal", it) }
                )
            }

            // ---------- Screen recorder ----------
            item {
                RecorderCard(
                    vm, recState,
                    onStart = { ctx.startActivity(Intent(ctx, CaptureRequestActivity::class.java)) },
                    onStop = {
                        ctx.startService(
                            Intent(ctx, RecorderService::class.java).setAction(RecorderService.ACTION_STOP)
                        )
                    }
                )
            }

            // ---------- Frame generation ----------
            item {
                FrameGenCard(
                    vm, fgRunning, fgStats,
                    onStart = { ctx.startActivity(Intent(ctx, FrameGenRequestActivity::class.java)) },
                    onStop = {
                        ctx.startService(
                            Intent(ctx, FrameGenService::class.java).setAction(FrameGenService.ACTION_STOP)
                        )
                    }
                )
            }

            // ---------- Permissions / Shizuku ----------
            item {
                NeonCard {
                    SectionTitle("Permissions & Shizuku")
                    PermissionRow(
                        Icons.Rounded.Shield, "Shizuku access",
                        when (shizuku) {
                            ShizukuState.READY -> "Connected — full tuning unlocked"
                            ShizukuState.CONNECTING -> "Connecting… $shizukuDetail"
                            ShizukuState.NO_PERMISSION -> "Running — tap Allow to let GR FPS use it"
                            ShizukuState.NOT_RUNNING -> "Not running — install / start Shizuku first"
                        },
                        shizuku == ShizukuState.READY,
                        when (shizuku) {
                            ShizukuState.NOT_RUNNING -> "OPEN"
                            ShizukuState.CONNECTING -> "RETRY"
                            else -> "ALLOW"
                        }
                    ) {
                        when (shizuku) {
                            ShizukuState.NOT_RUNNING -> ShizukuHelper.openShizuku(ctx)
                            ShizukuState.CONNECTING -> ShizukuHelper.retry()
                            else -> ShizukuHelper.requestPermission(ctx)
                        }
                    }
                    HorizontalDivider(color = Divider)
                    PermissionRow(
                        Icons.Rounded.BatteryChargingFull, "Ignore battery optimization",
                        "Keeps GR FPS from being killed in the background", batteryOk, "ALLOW"
                    ) {
                        ctx.startActivity(
                            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                        )
                    }
                    HorizontalDivider(color = Divider)
                    PermissionRow(
                        Icons.Rounded.Notifications, "Notifications",
                        "Boost results and the recorder buttons", notifOk, "ALLOW"
                    ) {
                        if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                    HorizontalDivider(color = Divider)
                    PermissionRow(
                        Icons.Rounded.Visibility, "Display over other apps",
                        "Needed to show the FPS / monitor boxes on top of games", overlayOk, "ALLOW"
                    ) { openOverlaySettings(ctx) }
                }
            }

            // ---------- Result log ----------
            if (vm.log.isNotEmpty()) {
                item {
                    NeonCard {
                        SectionTitle("Last result")
                        vm.log.forEach {
                            Text(
                                it,
                                color = if (it.startsWith("✔")) Neon else if (it.startsWith("✘")) Color(0xFFFFB300) else TextDim,
                                fontSize = 12.sp,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    "GR FPS reduces system overhead to make your phone smoother. It can't turn a very weak chip into a flagship, " +
                        "so expect the biggest gains on heavy games when you also lower in-game graphics.",
                    color = TextDim, fontSize = 11.sp, lineHeight = 15.sp
                )
            }
        }
    }

    // ---------- Dialogs ----------
    vm.pending?.let { p ->
        AlertDialog(
            onDismissRequest = vm::dismissPending,
            containerColor = CardTop,
            shape = TechShape,
            title = { Text("Apply boost?", color = Neon, fontWeight = FontWeight.Black) },
            text = {
                Column {
                    Text("These changes will be applied:", color = TextDim, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Optimizer.describe(p).forEach { Text("• $it", color = TextMain, fontSize = 13.sp) }
                    vm.selectedApp?.takeIf { vm.launchAfter }?.let {
                        Spacer(Modifier.height(4.dp))
                        Text("• Then open ${it.label}", color = Neon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(8.dp))
                    Text("Your original values are saved first. Use RESET to restore them.", color = TextDim, fontSize = 11.sp)
                }
            },
            confirmButton = {
                TextButton(onClick = vm::confirmApply) {
                    Text(if (playMode) "APPLY & PLAY" else "APPLY", color = Neon, fontWeight = FontWeight.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = vm::dismissPending) { Text("CANCEL", color = TextDim) }
            }
        )
    }

    if (vm.keepSeconds > 0) {
        AlertDialog(
            onDismissRequest = {},
            containerColor = CardTop,
            shape = TechShape,
            title = { Text("Keep this resolution?", color = Neon, fontWeight = FontWeight.Black) },
            text = {
                Text(
                    "Going back to the original automatically in ${vm.keepSeconds}s unless you tap KEEP.",
                    color = TextMain, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = vm::keepResolution) { Text("KEEP", color = Neon, fontWeight = FontWeight.Black) }
            },
            dismissButton = {
                TextButton(onClick = vm::revertResolutionNow) { Text("REVERT NOW", color = TextDim) }
            }
        )
    }

    if (vm.confirmReset) {
        AlertDialog(
            onDismissRequest = { vm.confirmReset = false },
            containerColor = CardTop,
            shape = TechShape,
            title = { Text("Reset everything?", color = Neon, fontWeight = FontWeight.Black) },
            text = {
                Text(
                    "All settings GR FPS changed will go back to what they were before. " +
                        "Apps that were closed and caches that were cleared can't be restored.",
                    color = TextMain, fontSize = 13.sp
                )
            },
            confirmButton = {
                TextButton(onClick = vm::confirmResetNow) { Text("RESET", color = Neon, fontWeight = FontWeight.Black) }
            },
            dismissButton = {
                TextButton(onClick = { vm.confirmReset = false }) { Text("CANCEL", color = TextDim) }
            }
        )
    }
}

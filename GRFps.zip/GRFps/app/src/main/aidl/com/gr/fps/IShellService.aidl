package com.gr.fps;

interface IShellService {
    // Reserved transaction code used by Shizuku to stop the user service
    void destroy() = 16777114;

    String exec(String command) = 1;
}
